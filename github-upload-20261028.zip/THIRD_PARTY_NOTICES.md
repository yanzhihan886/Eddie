# Third-party notices

## SheetJS Community Edition 0.20.3

The locally bundled file `vendor/xlsx.full.min.js` is SheetJS Community Edition, distributed under the Apache License, Version 2.0. It is included in this project so that spreadsheet parsing and report generation do not load a remote script or transmit workbook contents to a CDN.

Copyright (C) 2012-present SheetJS LLC. See `vendor/LICENSE-Apache-2.0.txt` for the full license text.

Project: <https://sheetjs.com/>  
Documentation: <https://docs.sheetjs.com/>

## xlsx-js-style 1.2.0

The locally bundled `vendor/xlsx-style.bundle.js` generates styled Excel reports without sending data to a server. It is used only for writing reports; SheetJS Community Edition 0.20.3 remains responsible for reading uploaded spreadsheets. Distributed under the Apache License, Version 2.0; see `vendor/LICENSE-xlsx-js-style.txt`.

Project: <https://github.com/gitbrent/xlsx-js-style>

## Flag images

The original SVG files in `flags/` are obtained from Wikimedia Commons and are included locally without redrawing or cropping. The source pages contain each file's authorship and licensing information:

- <https://commons.wikimedia.org/wiki/File:Flag_of_the_People%27s_Republic_of_China.svg>
- <https://commons.wikimedia.org/wiki/File:Flag_of_the_United_States.svg>
- <https://commons.wikimedia.org/wiki/File:Flag_of_France.svg>
- <https://commons.wikimedia.org/wiki/File:Flag_of_Russia.svg>
- <https://commons.wikimedia.org/wiki/File:Flag_of_Spain.svg>
- <https://commons.wikimedia.org/wiki/File:Flag_of_Saudi_Arabia.svg>
