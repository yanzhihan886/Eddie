import { classifyFeeType, productSummary } from "./domain.mjs";

// Only attach a deduction to a product when the imported record identifies a
// single SKU. Ambiguous and cross-period records remain at store level.
export function buildProfitInsights(data, summary, marginThresholdPercent = 10) {
  const threshold = Number.isFinite(Number(marginThresholdPercent))
    ? Math.max(0, Math.min(50, Number(marginThresholdPercent))) : 10;
  const rows = productSummary(data, summary).map((product) => ({
    ...product, refundFen: 0, feeFen: 0, expenseFen: 0,
    shippingFen: 0, commissionFen: 0, promotionFen: 0,
  }));
  const byProduct = new Map(rows.map((row) => [`${row.storeId}|${row.skuId}`, row]));
  const orderByKey = new Map(data.orders.map((order) => [`${order.storeId}|${order.platformOrderId}`, order]));
  const itemsByOrder = new Map();
  for (const item of data.orderItems) {
    const key = `${item.storeId}|${item.platformOrderId}`;
    if (!itemsByOrder.has(key)) itemsByOrder.set(key, []);
    itemsByOrder.get(key).push(item);
  }
  const inRange = (row, dateKey) => summary.storeIds.includes(row.storeId)
    && row[dateKey] >= summary.start && row[dateKey] <= summary.end;
  const unmatched = { refundFen: 0, feeFen: 0, expenseFen: 0, count: 0 };
  function findProduct(record) {
    if (record.platformOrderId) {
      const order = orderByKey.get(`${record.storeId}|${record.platformOrderId}`);
      if (!order || order.statusClass !== "valid" || order.orderedAt < summary.start || order.orderedAt > summary.end) return null;
    }
    if (record.skuId) return byProduct.get(`${record.storeId}|${record.skuId}`) || null;
    if (!record.platformOrderId) return null;
    let items = itemsByOrder.get(`${record.storeId}|${record.platformOrderId}`) || [];
    if (record.platformItemId) items = items.filter((item) => item.platformItemId === record.platformItemId);
    const skus = [...new Set(items.map((item) => item.skuId).filter(Boolean))];
    return skus.length === 1 ? byProduct.get(`${record.storeId}|${skus[0]}`) || null : null;
  }
  function apply(record, field) {
    const amount = Number(record.amountFen || 0);
    const product = findProduct(record);
    if (!product) { unmatched[field] += amount; unmatched.count += 1; return; }
    product[field] += amount;
    const kind = classifyFeeType(record.feeType || record.expenseType || "");
    if (kind === 'shipping') product.shippingFen += amount;
    if (kind === 'commission') product.commissionFen += amount;
    if (kind === 'promotion') product.promotionFen += amount;
  }
  for (const row of data.refunds.filter((r) => r.confirmed && inRange(r, "completedAt"))) apply(row, "refundFen");
  for (const row of data.platformFees.filter((r) => inRange(r, "feeDate"))) apply(row, "feeFen");
  for (const row of data.otherExpenses.filter((r) => inRange(r, "expenseDate"))) apply(row, "expenseFen");
  for (const row of rows) {
    row.allocatedDeductionsFen = row.refundFen + row.feeFen + row.expenseFen;
    row.profitFen = row.salesFen - row.costFen - row.allocatedDeductionsFen;
    const netSales = row.salesFen - row.refundFen;
    row.margin = netSales > 0 ? row.profitFen / netSales : null;
    row.target = row.missingCost ? "costs" : "records";
    row.action = row.missingCost ? "补填成本" : "查看商品订单";
    if (row.missingCost) {
      row.reason = "缺少进货价，暂时无法判断";
      row.suggestion = "先补上进货价，再判断是否亏损。";
    } else if (row.refundFen > 0 && row.refundFen >= row.feeFen + row.expenseFen) {
      row.reason = "可能与已匹配退款有关";
      row.suggestion = "查看对应退款，核对商品和金额。";
    } else if (row.costFen >= row.salesFen * 0.75) {
      row.reason = "可能是进货成本占比偏高";
      row.suggestion = "核对进货价和售价，再决定是否调整。";
    } else if (row.shippingFen || row.commissionFen || row.promotionFen) {
      row.reason = "可能与已匹配的费用有关";
      row.suggestion = "查看订单和费用明细，再决定如何处理。";
    } else {
      row.reason = "已匹配成本和费用超过销售额";
      row.suggestion = "核对进货价、退款和费用后再决定是否调价。";
    }
  }
  const knownCost = rows.filter((row) => !row.missingCost);
  const lossProducts = knownCost.filter((row) => row.profitFen < 0).sort((a, b) => a.profitFen - b.profitFen);
  const thinProducts = knownCost.filter((row) => row.profitFen >= 0 && row.margin !== null && row.margin < threshold / 100)
    .sort((a, b) => a.margin - b.margin);
  const uncertainProducts = rows.filter((row) => row.missingCost).sort((a, b) => b.salesFen - a.salesFen);
  return {
    products: rows.sort((a, b) => b.salesFen - a.salesFen), lossProducts, thinProducts, uncertainProducts,
    totalLossFen: lossProducts.reduce((sum, row) => sum + Math.abs(row.profitFen), 0), lossCount: lossProducts.length,
    thresholdPercent: threshold, unallocated: unmatched,
    unallocatedFen: unmatched.refundFen + unmatched.feeFen + unmatched.expenseFen,
  };
}
