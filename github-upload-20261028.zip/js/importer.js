import { REPORTS, classifyOrderStatus, dedupeCandidates, isRefundConfirmed, isSettlementConfirmed, multiplyFenByMilli, normalizeDate, parseMoneyFen, parseQuantityMilli, stableRecordKey } from "./domain.js";
import { ensureSpreadsheetLibrary } from "./spreadsheet-loader.js";
import { getByIndex, readAll, writeRecords } from "./db.js";

export const MAX_FILE_BYTES = 20 * 1024 * 1024;
export const MAX_DATA_ROWS = 50000;

function detectDelimiter(text) {
  const candidates = [',', ';', '\t'];
  const lines = String(text).replace(/^\uFEFF/, '').split(/\r\n|\n|\r/).filter(Boolean).slice(0, 8);
  const counts = candidates.map((delimiter) => {
    let total = 0;
    for (const line of lines) {
      let quoted = false, count = 0;
      for (let i = 0; i < line.length; i += 1) {
        if (line[i] === '"' && line[i + 1] === '"' && quoted) { i += 1; continue; }
        if (line[i] === '"') quoted = !quoted;
        else if (line[i] === delimiter && !quoted) count += 1;
      }
      total += count;
    }
    return total;
  });
  const best = Math.max(...counts);
  return best ? candidates[counts.indexOf(best)] : ',';
}

export function parseCsv(text, selectedDelimiter = '') {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const input = String(text).replace(/^\uFEFF/, "");
  const delimiter = selectedDelimiter || detectDelimiter(input);
  for (let i = 0; i < input.length; i += 1) {
    const ch = input[i];
    if (quoted) {
      if (ch === '"' && input[i + 1] === '"') { field += '"'; i += 1; }
      else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"' && field === "") quoted = true;
    else if (ch === delimiter) { row.push(field); field = ""; }
    else if (ch === "\n" || ch === "\r") {
      row.push(field); field = "";
      if (row.some((cell) => String(cell).trim() !== "")) rows.push(row);
      row = [];
      if (ch === "\r" && input[i + 1] === "\n") i += 1;
    } else field += ch;
    if (rows.length > MAX_DATA_ROWS + 1) throw new Error(`文件超过 ${MAX_DATA_ROWS.toLocaleString()} 行限制。`);
  }
  row.push(field);
  if (row.some((cell) => String(cell).trim() !== "")) rows.push(row);
  if (quoted) throw new Error("CSV 文件中有未闭合的引号，请检查源文件。");
  return rows;
}

function decodeCsv(buffer, encoding = 'auto') {
  if (encoding !== 'auto') return new TextDecoder(encoding, { fatal: false }).decode(buffer);
  try { return new TextDecoder('utf-8', { fatal: true }).decode(buffer); }
  catch {
    const candidates = ['gb18030', 'windows-1251', 'windows-1256', 'windows-1252'];
    const samples = candidates.map((name) => {
      try { return [name, new TextDecoder(name, { fatal: false }).decode(buffer)]; }
      catch { return [name, '']; }
    });
    const score = (text, pattern) => (text.match(pattern) || []).length;
    const ranked = samples.map(([name, text]) => {
      const letters = Math.max(1, score(text, /[\p{L}]/gu));
      const script = name === 'gb18030' ? score(text, /[\u3400-\u9fff]/g)
        : name === 'windows-1251' ? score(text, /[\u0400-\u04ff]/g)
          : name === 'windows-1256' ? score(text, /[\u0600-\u06ff]/g) : 0;
      return { name, text, confidence: script / letters };
    }).sort((a, b) => b.confidence - a.confidence);
    return ranked[0].confidence >= 0.12 ? ranked[0].text : ranked.find((item) => item.name === 'windows-1252').text;
  }
}

export async function sha256(buffer) {
  if (!globalThis.crypto?.subtle) throw new Error("当前网址无法安全检查文件。请使用 HTTPS 网址打开后重试；文件还没有导入。");
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function readTabularFile(file, { encoding = 'auto' } = {}) {
  if (!file) throw new Error("请先选择文件。");
  if (file.size > MAX_FILE_BYTES) throw new Error("单个文件不能超过 20 MB。请拆分后再导入。");
  const buffer = await file.arrayBuffer();
  const extension = file.name.split(".").pop()?.toLowerCase();
  let matrix;
  if (extension === "csv" || extension === "tsv" || extension === "txt") {
    matrix = parseCsv(decodeCsv(buffer, encoding), extension === 'tsv' ? '\t' : '');
  } else if (["xlsx", "xlsm", "xls"].includes(extension)) {
    await ensureSpreadsheetLibrary("read");
    const workbook = XLSX.read(buffer, { type: "array", cellDates: false, dense: true, sheetRows: MAX_DATA_ROWS + 1 });
    const sheetName = workbook.SheetNames[0];
    if (!sheetName) throw new Error("Excel 文件没有可读取的工作表。");
    matrix = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { header: 1, defval: "", raw: false, blankrows: false, dateNF: "yyyy-mm-dd" });
  } else {
    throw new Error("支持 CSV、TSV、XLS、XLSX 和 XLSM 文件。");
  }
  if (!matrix.length || !matrix[0]?.some((cell) => String(cell).trim())) throw new Error("文件为空，或首行没有字段标题。");
  if (matrix.length - 1 > MAX_DATA_ROWS) throw new Error(`文件超过 ${MAX_DATA_ROWS.toLocaleString()} 行限制。`);
  const headers = matrix[0].map((value, i) => String(value ?? "").trim() || `未命名列 ${i + 1}`);
  const rows = matrix.slice(1).map((cells) => headers.map((_, i) => cells?.[i] ?? ""));
  return { buffer, headers, rows, sheetName: extension === "csv" || extension === "tsv" ? "CSV" : "第一个工作表" };
}

function headerKey(value) { return String(value ?? "").normalize('NFKC').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s_\-（）()]/g, ""); }

export function suggestMapping(reportType, headers) {
  const spec = REPORTS[reportType];
  if (!spec) throw new Error("请选择正确的表格类型。");
  return Object.fromEntries(spec.fields.map((field) => {
    const aliases = new Set([field.key, field.label, ...field.aliases].map(headerKey));
    const found = headers.find((header) => aliases.has(headerKey(header)));
    return [field.key, found ?? ""];
  }));
}

function valueOf(row, headers, mapping, key) {
  const header = mapping[key];
  if (!header) return "";
  const index = headers.indexOf(header);
  return index < 0 ? "" : row[index];
}

function asText(value) { return String(value ?? "").trim(); }

export function normalizeMoneyForCurrency(value, currency) {
  if (value === null || value === undefined || String(value).trim() === '') return value;
  let text = String(value).trim();
  const allowed = { CNY: '¥￥', USD: '$', EUR: '€', GBP: '£', CAD: '$', AUD: '$', SAR: '' }[currency] ?? '';
  text = text.replace(new RegExp(`^${currency}\\s*|\\s*${currency}$`, 'i'), '').trim();
  for (const symbol of ['¥','￥','$','€','£']) {
    if (!text.includes(symbol)) continue;
    if (!allowed.includes(symbol)) throw new Error(`金额符号与 ${currency} 店铺不一致，请检查币种。`);
    text = text.replace(symbol, '').trim();
  }
  text = text.replace(/[\u00a0\u202f ]/g, '');
  const parentheses = /^\(.*\)$/.test(text);
  if (parentheses) text = text.slice(1, -1);
  const wrap = result => parentheses ? `(${result})` : result;
  if (text.includes(',') && text.includes('.')) {
    if (/^[+-]?\d{1,3}(?:\.\d{3})+,\d+$/.test(text)) return wrap(text.replaceAll('.', '').replace(',', '.'));
    if (/^[+-]?\d{1,3}(?:,\d{3})+\.\d+$/.test(text)) return wrap(text.replaceAll(',', ''));
    throw new Error(`金额格式不明确：${String(value)}。请检查小数和千位分隔符。`);
  }
  if (text.includes(',')) {
    if (/^[+-]?\d+,\d{1,2}$/.test(text)) return wrap(text.replace(',', '.')); 
    throw new Error(`金额格式不明确：${String(value)}。请去掉千位分隔符并使用两位小数。`);
  }
  return wrap(text);
}

export function parseMappedDate(value, dateOrder = '') {
  if (typeof value === "number" && value > 20000 && value < 80000 && globalThis.XLSX?.SSF?.parse_date_code) {
    const date = XLSX.SSF.parse_date_code(value);
    if (date) return normalizeDate(`${date.y}-${date.m}-${date.d}`);
  }
  const raw = String(value ?? '').trim();
  const ambiguous = raw.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
  if (ambiguous && Number(ambiguous[1]) <= 12 && Number(ambiguous[2]) <= 12) {
    if (!['DMY','MDY'].includes(dateOrder)) throw new Error(`日期 ${raw} 有歧义。请在高级选项中确认日/月顺序后重新检查。`);
    const [first, second, year] = ambiguous.slice(1);
    const result = normalizeDate(`${year}-${dateOrder === 'DMY' ? second : first}-${dateOrder === 'DMY' ? first : second}`);
    if (!result) throw new Error(`日期无法识别：${raw}。`);
    return result;
  }
  const result = normalizeDate(value);
  if (!result && raw) throw new Error(`日期格式不明确或无法识别：${raw}。请改成 YYYY-MM-DD，例如 2026-10-27。`);
  return result;
}

function canonicalRowHash(data) {
  const clean = Object.fromEntries(Object.keys(data).sort().map((key) => [key, data[key]]));
  return JSON.stringify(clean);
}

function requiredValue(value, label) {
  if (value === null || value === undefined || value === "") throw new Error(`缺少${label}`);
  return value;
}

function normalizeCandidate(reportType, raw, headers, mapping, storeId, rowNumber, currency = 'CNY', dateOrder = '') {
  const mapped = Object.fromEntries(REPORTS[reportType].fields.map((field) => [field.key, valueOf(raw, headers, mapping, field.key)]));
  for (const key of ['unitPrice','discountAmount','itemAmount','refundAmount','feeAmount','unitCost','expenseAmount','settlementAmount']) {
    if (mapped[key] === undefined || mapped[key] === null || String(mapped[key]).trim() === '') continue;
    mapped[key] = normalizeMoneyForCurrency(mapped[key], currency);
  }
  const sourceDate = {
    orders: "orderedAt", refunds: "completedAt", fees: "feeDate", costs: "effectiveFrom", expenses: "expenseDate", settlements: "settlementDate",
  }[reportType];
  let data;
  if (reportType === "orders") {
    const platformOrderId = asText(requiredValue(mapped.platformOrderId, "平台订单号"));
    const orderedAt = requiredValue(parseMappedDate(mapped.orderedAt, dateOrder), "有效下单日期");
    const orderStatus = asText(requiredValue(mapped.orderStatus, "订单状态"));
    const skuId = asText(requiredValue(mapped.skuId, "商品编号"));
    const quantityMilli = requiredValue(parseQuantityMilli(mapped.quantity), "有效销售数量");
    if (quantityMilli <= 0) throw new Error("销售数量必须大于 0");
    const unitPriceFen = parseMoneyFen(mapped.unitPrice);
    const discountFen = parseMoneyFen(mapped.discountAmount) ?? 0;
    let amountFen = parseMoneyFen(mapped.itemAmount);
    if (amountFen === null) {
      if (unitPriceFen === null) throw new Error("商品实付金额和商品单价至少填写一项");
      amountFen = multiplyFenByMilli(unitPriceFen, quantityMilli) - discountFen;
    }
    if (amountFen < 0) throw new Error("商品实付金额不能为负数，请将退款记录放到退款表");
    data = { storeId, platformOrderId, orderedAt, orderStatus, statusClass: classifyOrderStatus(orderStatus), skuId,
      productName: asText(mapped.productName), platformItemId: asText(mapped.platformItemId) || "",
      quantityMilli, unitPriceFen, amountFen, discountFen };
  } else if (reportType === "refunds") {
    data = { storeId, platformRefundId: asText(mapped.platformRefundId) || "", platformOrderId: asText(requiredValue(asText(mapped.platformOrderId), "平台订单号")),
      platformItemId: asText(mapped.platformItemId) || "", refundStatus: asText(requiredValue(asText(mapped.refundStatus), "退款状态")),
      confirmed: isRefundConfirmed(mapped.refundStatus), amountFen: requiredValue(parseMoneyFen(mapped.refundAmount), "有效退款金额"),
      completedAt: requiredValue(parseMappedDate(mapped.completedAt, dateOrder), "有效退款完成日期") };
  } else if (reportType === "fees") {
    data = { storeId, feeId: asText(mapped.feeId) || "", platformOrderId: asText(mapped.platformOrderId) || "", feeType: asText(requiredValue(asText(mapped.feeType), "费用类型")),
      amountFen: requiredValue(parseMoneyFen(mapped.feeAmount), "有效费用金额"), feeDate: requiredValue(parseMappedDate(mapped.feeDate, dateOrder), "有效费用日期") };
  } else if (reportType === "costs") {
    const effectiveFrom = parseMappedDate(mapped.effectiveFrom, dateOrder) || "1970-01-01";
    const effectiveTo = mapped.effectiveTo ? parseMappedDate(mapped.effectiveTo, dateOrder) : null;
    if (mapped.effectiveTo && !effectiveTo) throw new Error("截止日期格式看不懂，请检查这一列");
    if (effectiveTo && effectiveTo < effectiveFrom) throw new Error("截止日期不能早于开始日期");
    data = { storeId, skuId: asText(requiredValue(asText(mapped.skuId), "商品编号")), productName: asText(mapped.productName),
      unitCostFen: requiredValue(parseMoneyFen(mapped.unitCost), "有效单位成本"), effectiveFrom, effectiveTo };
    if (data.unitCostFen < 0) throw new Error("单位成本不能为负数");
  } else if (reportType === "expenses") {
    data = { storeId, expenseId: asText(mapped.expenseId) || "", expenseType: asText(requiredValue(asText(mapped.expenseType), "费用类型")),
      amountFen: requiredValue(parseMoneyFen(mapped.expenseAmount), "有效费用金额"), expenseDate: requiredValue(parseMappedDate(mapped.expenseDate, dateOrder), "有效费用日期"),
      allocationMethod: asText(mapped.allocationMethod) || "店铺级", platformOrderId: asText(mapped.platformOrderId) || "", skuId: asText(mapped.skuId) || "", note: asText(mapped.note) };
  } else if (reportType === "settlements") {
    data = { storeId, transactionId: asText(mapped.transactionId) || "", platformOrderId: asText(mapped.platformOrderId) || "",
      amountFen: requiredValue(parseMoneyFen(mapped.settlementAmount), "实际到账金额"), settlementStatus: asText(requiredValue(asText(mapped.settlementStatus), "到账状态")),
      confirmed: isSettlementConfirmed(mapped.settlementStatus), settlementDate: requiredValue(parseMappedDate(mapped.settlementDate, dateOrder), "到账日期") };
  } else throw new Error("暂不支持这种表格类型。");

  const recordKey = stableRecordKey(reportType, data);
  return { data, recordKey, rowHash: canonicalRowHash(data), rowNumber, raw };
}

export async function prepareImport(db, file, reportType, storeId, headers, rows, mapping, fileHash, dateOrder = '') {
  if (!REPORTS[reportType]) throw new Error("请选择表格类型。");
  const currency = (await readAll(db, 'stores')).find(store => store.id === storeId)?.currency || 'CNY';
  const existingBatch = await getByIndex(db, "importBatches", "fileKey", [storeId, reportType, fileHash]);
  const good = [];
  const rejected = [];
  for (let index = 0; index < rows.length; index += 1) {
    try { good.push(normalizeCandidate(reportType, rows[index], headers, mapping, storeId, index + 2, currency, dateOrder)); }
    catch (error) { rejected.push({ rowNumber: index + 2, raw: rows[index], message: error.message || "数据格式无法识别" }); }
  }
  const objectStore = { orders: "orderItems", refunds: "refunds", fees: "platformFees", costs: "productCosts", expenses: "otherExpenses", settlements: "settlements" }[reportType];
  const existing = (await readAll(db, objectStore)).filter((record) => record.storeId === storeId);
  const split = dedupeCandidates(good, existing);
  const dateKey = { orders: "orderedAt", refunds: "completedAt", fees: "feeDate", costs: "effectiveFrom", expenses: "expenseDate", settlements: "settlementDate" }[reportType];
  const coverageDates = split.accepted.map((row) => row.data[dateKey]).filter(Boolean).sort();
  return {
    fileName: file.name, size: file.size, reportType, storeId, fileHash, headers, rows, mapping,
    accepted: split.accepted, duplicates: split.duplicates, conflicts: split.conflicts, rejected,
    duplicateFile: Boolean(existingBatch), batchAlreadyImported: existingBatch || null,
    coverageStart: coverageDates[0] || null, coverageEnd: coverageDates.at(-1) || null,
    rowCount: rows.length,
  };
}

function uuid() {
  return globalThis.crypto?.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
}

function entityStore(reportType) {
  return { orders: "orderItems", refunds: "refunds", fees: "platformFees", costs: "productCosts", expenses: "otherExpenses", settlements: "settlements" }[reportType];
}

function entityData(reportType, candidate, batchId) {
  const base = { ...candidate.data, id: uuid(), recordKey: candidate.recordKey, rowHash: candidate.rowHash, importBatchId: batchId, sourceRowNumber: candidate.rowNumber };
  if (reportType === "orders") return { ...base, orderId: "" };
  if (reportType === "refunds") return { ...base, platformRefundId: base.platformRefundId || "" };
  return base;
}

export async function commitImport(db, plan) {
  if (plan.duplicateFile) throw new Error("這份文件已完整匯入過，未重複寫入資料。");
  const batchId = uuid();
  const importedAt = new Date().toISOString();
  const allCandidates = [...plan.accepted, ...plan.duplicates, ...plan.conflicts];
  const dates = allCandidates.map((row) => row.data[{
    orders: "orderedAt", refunds: "completedAt", fees: "feeDate", costs: "effectiveFrom", expenses: "expenseDate", settlements: "settlementDate",
  }[plan.reportType]]).filter(Boolean).sort();
  const batch = {
    id: batchId, storeId: plan.storeId, reportType: plan.reportType, originalFilename: plan.fileName,
    fileHash: plan.fileHash, importedAt, rowCount: plan.rowCount, acceptedCount: plan.accepted.length,
    rejectedCount: plan.rejected.length, duplicateCount: plan.duplicates.length, conflictCount: plan.conflicts.length,
    status: plan.rejected.length || plan.conflicts.length ? "partial" : "imported", fieldMapping: plan.mapping,
    coverageStart: plan.confirmedCoverage?.start || dates[0] || "", coverageEnd: plan.confirmedCoverage?.end || dates.at(-1) || "",
    coverageConfirmed: !!plan.confirmedCoverage && !plan.rejected.length && !plan.conflicts.length, appSchemaVersion: 1,
  };
  const bundle = { importBatches: [batch], rawRecords: [], issues: [], [entityStore(plan.reportType)]: [] };
  const issue = (rowNumber, type, severity, description, status = "open") => {
    const stableKey = `import|${batchId}|${rowNumber}|${type}`;
    bundle.issues.push({ id: uuid(), storeId: plan.storeId, issueType: type, severity, status, description,
      sourceRecordId: "", relatedRecordIds: [], amountDifferenceFen: null, resolutionNote: "", createdAt: importedAt, stableKey });
  };

  for (const row of [...plan.accepted, ...plan.duplicates, ...plan.conflicts, ...plan.rejected]) {
    const isBad = "message" in row;
    const decision = isBad ? "rejected" : plan.duplicates.includes(row) ? "duplicate" : plan.conflicts.includes(row) ? "conflict" : "accepted";
    bundle.rawRecords.push({ id: uuid(), batchId, rowNumber: row.rowNumber, sourceValues: row.raw, decision, validationMessage: isBad ? row.message : "" });
    if (isBad) issue(row.rowNumber, "import_validation", "warning", `第 ${row.rowNumber} 行：${row.message}`);
    else if (decision === "duplicate") issue(row.rowNumber, "duplicate_record", "info", `第 ${row.rowNumber} 行与已有数据相同，已跳过。`, "resolved");
    else if (decision === "conflict") issue(row.rowNumber, "record_conflict", "warning", `第 ${row.rowNumber} 行的订单号或流水号已存在，但内容不一样；原记录没有被改动。`);
  }

  if (plan.reportType === "orders") {
    const currentOrders = (await readAll(db, "orders")).filter((row) => row.storeId === plan.storeId);
    const orderByPlatformId = new Map(currentOrders.map((row) => [row.platformOrderId, row]));
    const pendingOrders = new Map();
    for (const candidate of plan.accepted) {
      const item = entityData("orders", candidate, batchId);
      let order = orderByPlatformId.get(candidate.data.platformOrderId) || pendingOrders.get(candidate.data.platformOrderId);
      if (!order) {
        order = { id: uuid(), storeId: plan.storeId, platformOrderId: candidate.data.platformOrderId,
          orderedAt: candidate.data.orderedAt, orderStatus: candidate.data.orderStatus,
          statusClass: candidate.data.statusClass, createdAt: importedAt, importBatchId: batchId };
        pendingOrders.set(candidate.data.platformOrderId, order);
      } else if (order.orderedAt !== candidate.data.orderedAt || order.statusClass !== candidate.data.statusClass) {
        issue(candidate.rowNumber, "order_status_conflict", "warning", `订单 ${candidate.data.platformOrderId} 的日期或状态和已有记录不一样；保留了旧信息。`);
      }
      item.orderId = order.id;
      bundle.orderItems.push(item);
      if (candidate.data.statusClass === "unknown") issue(candidate.rowNumber, "unknown_order_status", "warning", `订单 ${candidate.data.platformOrderId} 的状态“${candidate.data.orderStatus}”看不懂，所以没有算进销售。`);
    }
    bundle.orders = [...pendingOrders.values()];
  } else {
    for (const candidate of plan.accepted) bundle[entityStore(plan.reportType)].push(entityData(plan.reportType, candidate, batchId));
  }

  if (plan.reportType === "fees") {
    const orderIds = new Set((await readAll(db, "orders")).filter((o) => o.storeId === plan.storeId).map((o) => o.platformOrderId));
    for (const candidate of plan.accepted) if (candidate.data.platformOrderId && !orderIds.has(candidate.data.platformOrderId)) {
      issue(candidate.rowNumber, "unmatched_fee", "warning", `费用流水“${candidate.data.feeId || candidate.data.feeType}”关联的订单不存在或尚未导入。`);
    }
  }

  await writeRecords(db, bundle, "add");
  return { batch, importedCount: plan.accepted.length, rejectedCount: plan.rejected.length, duplicateCount: plan.duplicates.length, conflictCount: plan.conflicts.length, issueCount: bundle.issues.length };
}
