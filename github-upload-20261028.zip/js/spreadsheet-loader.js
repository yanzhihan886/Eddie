// Load the bundled local libraries only when an Excel file is opened or exported.
const pending = new Map();
export function ensureSpreadsheetLibrary(kind) {
  const key = kind === "style" ? "style" : "read";
  if (key === "style" && globalThis.XLSX_STYLE) return Promise.resolve(globalThis.XLSX_STYLE);
  if (key === "read" && globalThis.XLSX_READER) { globalThis.XLSX = globalThis.XLSX_READER; return Promise.resolve(globalThis.XLSX_READER); }
  if (pending.has(key)) return pending.get(key);
  // Libraries both use window.XLSX. Serialize loads so neither can overwrite
  // the reference before it is captured.
  const previous = Promise.allSettled([...pending.values()]);
  const task = previous.then(() => new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = new URL(key === "style" ? "../vendor/xlsx-style.bundle.js" : "../vendor/xlsx.full.min.js", import.meta.url).href;
    script.onload = () => {
      const library = globalThis.XLSX;
      if (!library) { script.remove(); reject(new Error("Excel library did not initialize.")); return; }
      if (key === "style") globalThis.XLSX_STYLE = library;
      else globalThis.XLSX_READER = library;
      resolve(library);
    };
    script.onerror = () => { script.remove(); reject(new Error("Could not load the local Excel component. Check website files and try again.")); };
    document.head.append(script);
  })).finally(() => pending.delete(key));
  pending.set(key, task);
  return task;
}
