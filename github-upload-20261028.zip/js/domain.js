export const DB_VERSION = 1;
export const CALCULATION_RULE_VERSION = "local-profit-v1";

export const REPORTS = {
  orders: {
    label: "订单表",
    fields: [
      { key: "platformOrderId", label: "平台订单号", required: true, type: "text", aliases: ["订单编号", "订单号", "主订单编号", "平台订单号", "order id", "order number", "order no", "transaction id", "platform_order_id", "numéro de commande", "numero de pedido", "número de pedido"] },
      { key: "orderedAt", label: "下单日期", required: true, type: "date", aliases: ["订单日期", "下单时间", "创建时间", "付款时间", "order date", "purchase date", "created at", "order created", "date ordered", "order_date", "ordered_at", "date de commande", "fecha del pedido", "fecha de compra"] },
      { key: "orderStatus", label: "订单状态", required: true, type: "text", aliases: ["订单状态", "交易状态", "状态", "status", "order status", "fulfillment status", "financial status", "order_status", "statut de commande", "estado del pedido"] },
      { key: "skuId", label: "商品编号", required: true, type: "text", aliases: ["商品编码", "商品编号", "sku", "sku id", "sku_id", "merchant sku", "seller sku", "item sku", "商家编码", "référence produit", "referencia del producto", "codigo sku"] },
      { key: "productName", label: "商品名称", required: false, type: "text", aliases: ["商品名称", "商品标题", "货品名称", "product name", "product title", "item name", "item title", "nom du produit", "nombre del producto"] },
      { key: "quantity", label: "销售数量", required: true, type: "quantity", aliases: ["购买数量", "商品数量", "数量", "件数", "quantity", "qty", "items sold", "quantité", "cantidad"] },
      { key: "itemAmount", label: "商品实付金额", required: false, type: "money", aliases: ["商品实付金额", "商品金额", "销售金额", "订单金额", "实付金额", "item amount", "item total", "line total", "line amount", "total amount", "order total", "amount", "montant de la ligne", "total de la ligne", "importe del artículo", "total de línea"] },
      { key: "unitPrice", label: "商品单价", required: false, type: "money", aliases: ["商品单价", "成交单价", "单价", "unit price", "item price", "price per unit", "price", "prix unitaire", "precio unitario"] },
      { key: "discountAmount", label: "商品优惠金额", required: false, type: "money", aliases: ["优惠金额", "商品优惠", "折扣金额", "discount amount", "discount"] },
      { key: "platformItemId", label: "商品明细号", required: false, type: "text", aliases: ["子订单编号", "商品明细ID", "明细编号", "item_id", "platform_item_id"] },
    ],
  },
  refunds: {
    label: "退款表",
    fields: [
      { key: "platformRefundId", label: "退款单号", required: false, type: "text", aliases: ["退款单号", "售后单号", "退款编号", "refund id", "refund number"] },
      { key: "platformOrderId", label: "平台订单号", required: true, type: "text", aliases: ["订单编号", "订单号", "主订单编号", "order id", "order number", "order no", "platform order id"] },
      { key: "platformItemId", label: "商品明细号", required: false, type: "text", aliases: ["子订单编号", "商品明细ID", "明细编号", "item_id"] },
      { key: "refundStatus", label: "退款状态", required: true, type: "text", aliases: ["退款状态", "售后状态", "状态", "refund status", "return status"] },
      { key: "refundAmount", label: "退款金额", required: true, type: "money", aliases: ["退款金额", "退款总金额", "实退金额", "refund amount", "amount refunded", "refund total", "amount"] },
      { key: "completedAt", label: "退款完成日期", required: true, type: "date", aliases: ["退款完成时间", "退款时间", "完成时间", "退款成功时间", "refund date", "processed at", "completed at", "refunded at"] },
    ],
  },
  fees: {
    label: "平台扣费表",
    fields: [
      { key: "feeId", label: "费用记录编号", required: false, type: "text", aliases: ["费用编号", "账单编号", "流水号", "fee id", "transaction id"] },
      { key: "platformOrderId", label: "平台订单号（可空）", required: false, type: "text", aliases: ["订单编号", "订单号", "关联订单号", "order_id"] },
      { key: "feeType", label: "费用类型", required: true, type: "text", aliases: ["费用类型", "费用名称", "账单类型", "项目", "fee type", "fee name", "transaction type", "description"] },
      { key: "feeAmount", label: "费用金额", required: true, type: "money", aliases: ["费用金额", "支出金额", "扣款金额", "手续费", "fee amount", "transaction fee", "amount"] },
      { key: "feeDate", label: "费用日期", required: true, type: "date", aliases: ["费用发生日期", "账单日期", "发生时间", "扣款时间", "账单时间", "date", "transaction date", "posted date", "fee date"] },
    ],
  },
  costs: {
    label: "商品成本表",
    fields: [
      { key: "skuId", label: "商品编号", required: true, type: "text", aliases: ["商品编码", "商品编号", "sku", "sku id", "merchant sku", "seller sku", "item sku"] },
      { key: "productName", label: "商品名称", required: false, type: "text", aliases: ["商品名称", "商品标题", "product name", "product title", "item name"] },
      { key: "unitCost", label: "单位成本", required: true, type: "money", aliases: ["单位成本", "采购成本", "商品成本", "进货价", "成本", "unit cost", "purchase cost", "product cost", "cost per item", "cost"] },
      { key: "effectiveFrom", label: "成本开始日期（可空）", required: false, type: "date", aliases: ["生效日期", "开始日期", "effective from", "start date"] },
      { key: "effectiveTo", label: "成本截止日期（可空）", required: false, type: "date", aliases: ["失效日期", "结束日期", "effective to", "end date"] },
    ],
  },
  expenses: {
    label: "其他支出表",
    fields: [
      { key: "expenseId", label: "费用编号", required: false, type: "text", aliases: ["费用编号", "流水号", "expense id", "transaction id"] },
      { key: "expenseType", label: "费用类型", required: true, type: "text", aliases: ["费用类型", "费用名称", "项目", "expense type", "expense name", "description"] },
      { key: "expenseAmount", label: "费用金额", required: true, type: "money", aliases: ["费用金额", "支出金额", "金额", "expense amount", "amount"] },
      { key: "expenseDate", label: "费用日期", required: true, type: "date", aliases: ["费用日期", "账单日期", "发生时间", "日期", "expense date", "date incurred", "date"] },
      { key: "allocationMethod", label: "费用怎么分摊（可空）", required: false, type: "text", aliases: ["分摊方式", "分配方式", "allocation_method"] },
      { key: "platformOrderId", label: "关联订单号（可空）", required: false, type: "text", aliases: ["订单号", "关联订单", "order_id"] },
      { key: "skuId", label: "关联商品编号（可空）", required: false, type: "text", aliases: ["SKU编号", "商品编码", "sku", "sku_id"] },
      { key: "note", label: "备注（可空）", required: false, type: "text", aliases: ["备注", "说明", "note"] },
    ],
  },
  settlements: {
    label: "到账记录表",
    fields: [
      { key: "transactionId", label: "到账流水号", required: false, type: "text", aliases: ["结算流水号", "流水号", "交易编号", "transaction_id"] },
      { key: "platformOrderId", label: "关联订单号（可空）", required: false, type: "text", aliases: ["订单编号", "订单号", "关联订单号", "order_id"] },
      { key: "settlementAmount", label: "实际到账金额", required: true, type: "money", aliases: ["结算金额", "实际到账", "实收金额", "到账金额", "settlement amount", "net payout", "payout amount", "amount"] },
      { key: "settlementStatus", label: "到账状态", required: true, type: "text", aliases: ["结算状态", "账单状态", "状态", "status", "payout status", "settlement status"] },
      { key: "settlementDate", label: "到账日期", required: true, type: "date", aliases: ["结算日期", "到账日期", "账单日期", "结算时间", "settlement date", "payout date", "date"] },
    ],
  },
};

// Common translated column names improve first-pass mapping. They are only
// suggestions: platform-specific exports still require the user to confirm.
const internationalHeaderAliases = {
  orders: {
    platformOrderId: ['Order ID', 'Order Number', 'Order No.', 'Reference de commande', 'Numero de commande', 'Número de pedido', 'Pedido', 'Номер заказа', 'رقم الطلب'],
    orderedAt: ['Order Date', 'Created At', 'Purchase Date', 'Date de commande', 'Date de création', 'Fecha del pedido', 'Fecha de creación', 'Fecha', 'Дата заказа', 'تاريخ الطلب'],
    orderStatus: ['Order Status', 'Financial Status', 'Fulfillment Status', 'Statut de commande', 'État de la commande', 'Estado del pedido', 'Estado', 'Статус заказа', 'حالة الطلب'],
    skuId: ['SKU', 'SKU ID', 'Seller SKU', 'Merchant SKU', 'Référence produit', 'Référence', 'Referencia del producto', 'Código SKU', 'Артикул', 'رمز المنتج'],
    productName: ['Product Name', 'Item Name', 'Product Title', 'Nom du produit', 'Nom de l’article', 'Nombre del producto', 'Nombre del artículo', 'Название товара', 'اسم المنتج'],
    quantity: ['Quantity', 'Qty', 'Items Sold', 'Quantité', 'Cantidad', 'Unidades', 'Количество', 'الكمية'],
    itemAmount: ['Item Amount', 'Line Total', 'Line Amount', 'Product Total', 'Montant de la ligne', 'Total de la ligne', 'Importe del artículo', 'Total de línea', 'Сумма по товару', 'إجمالي المنتج'],
    unitPrice: ['Unit Price', 'Item Price', 'Price per Unit', 'Prix unitaire', 'Precio unitario', 'Precio por unidad', 'Цена за единицу', 'سعر الوحدة'],
    discountAmount: ['Discount', 'Discount Amount', 'Remise', 'Montant de la remise', 'Descuento', 'Importe del descuento', 'Скидка', 'الخصم'],
    platformItemId: ['Line Item ID', 'Order Line ID', 'ID de ligne', 'ID de artículo', 'ID del artículo', 'ID строки заказа', 'معرّف بند الطلب'],
  },
  refunds: {
    platformRefundId: ['Refund ID', 'Return ID', 'Refund Number', 'ID de remboursement', 'ID de devolución', 'ID de reembolso', 'ID de reembolso', 'Номер возврата', 'رقم الاسترداد'],
    platformOrderId: ['Order ID', 'Order Number', 'Platform Order ID', 'ID de commande', 'ID del pedido', 'Номер заказа', 'رقم الطلب'],
    refundStatus: ['Refund Status', 'Return Status', 'Statut du remboursement', 'État du remboursement', 'Estado del reembolso', 'Estado de devolución', 'Статус возврата', 'حالة الاسترداد'],
    refundAmount: ['Refund Amount', 'Amount Refunded', 'Refund Total', 'Montant remboursé', 'Montant du remboursement', 'Importe reembolsado', 'Importe del reembolso', 'Сумма возврата', 'مبلغ الاسترداد'],
    completedAt: ['Refund Date', 'Processed At', 'Completed At', 'Date de remboursement', 'Date de traitement', 'Fecha del reembolso', 'Fecha de devolución', 'Дата возврата', 'تاريخ الاسترداد'],
  },
  fees: {
    feeType: ['Fee Type', 'Fee Name', 'Transaction Type', 'Description', 'Type de frais', 'Nom des frais', 'Tipo de comisión', 'Tipo de tarifa', 'Описание комиссии', 'نوع الرسوم'],
    feeAmount: ['Fee Amount', 'Transaction Fee', 'Amount', 'Montant des frais', 'Frais', 'Importe de la comisión', 'Importe de la tarifa', 'Сумма комиссии', 'مبلغ الرسوم'],
    feeDate: ['Fee Date', 'Transaction Date', 'Posted Date', 'Date des frais', 'Date de transaction', 'Fecha de la comisión', 'Fecha del cargo', 'Дата комиссии', 'تاريخ الرسوم'],
  },
  costs: {
    skuId: ['SKU', 'SKU ID', 'Product SKU', 'Product Code', 'Référence produit', 'Référence', 'Código de producto', 'SKU del producto', 'Артикул', 'رمز المنتج'],
    productName: ['Product Name', 'Item Name', 'Nom du produit', 'Nombre del producto', 'Название товара', 'اسم المنتج'],
    unitCost: ['Unit Cost', 'Purchase Cost', 'Product Cost', 'Cost per Item', 'Cost', 'Coût unitaire', 'Coût d’achat', 'Costo unitario', 'Coste unitario', 'Costo de compra', 'Закупочная цена', 'تكلفة الوحدة'],
    effectiveFrom: ['Effective From', 'Start Date', 'Date de début', 'Fecha de inicio', 'Дата начала', 'تاريخ البداية'],
    effectiveTo: ['Effective To', 'End Date', 'Date de fin', 'Fecha de fin', 'Дата окончания', 'تاريخ الانتهاء'],
  },
  expenses: {
    expenseType: ['Expense Type', 'Expense Name', 'Description', 'Type de dépense', 'Nom de la dépense', 'Tipo de gasto', 'Nombre del gasto', 'Тип расхода', 'نوع المصروف'],
    expenseAmount: ['Expense Amount', 'Amount', 'Montant de la dépense', 'Importe del gasto', 'Сумма расхода', 'مبلغ المصروف'],
    expenseDate: ['Expense Date', 'Date Incurred', 'Date de dépense', 'Fecha del gasto', 'Дата расхода', 'تاريخ المصروف'],
    allocationMethod: ['Allocation Method', 'Allocation', 'Méthode de répartition', 'Método de asignación', 'Способ распределения', 'طريقة التوزيع'],
  },
  settlements: {
    transactionId: ['Transaction ID', 'Payout ID', 'Settlement ID', 'ID de transaction', 'ID de paiement', 'ID de liquidación', 'Номер транзакции', 'رقم المعاملة'],
    settlementAmount: ['Settlement Amount', 'Net Payout', 'Payout Amount', 'Montant versé', 'Versement net', 'Importe del pago', 'Pago neto', 'Сумма выплаты', 'صافي الدفعة'],
    settlementStatus: ['Settlement Status', 'Payout Status', 'Status', 'Statut du paiement', 'Estado del pago', 'Статус выплаты', 'حالة الدفعة'],
    settlementDate: ['Settlement Date', 'Payout Date', 'Date de paiement', 'Fecha del pago', 'Дата выплаты', 'تاريخ الدفعة'],
  },
};
for (const [reportType, fields] of Object.entries(internationalHeaderAliases)) {
  for (const [fieldKey, aliases] of Object.entries(fields)) {
    const field = REPORTS[reportType].fields.find((candidate) => candidate.key === fieldKey);
    if (field) field.aliases.push(...aliases);
  }
}

export const STORE_NAMES = [
  "stores", "orders", "orderItems", "refunds", "platformFees", "productCosts",
  "otherExpenses", "settlements", "importBatches", "rawRecords", "issues", "calculationResults",
];

export function parseMoneyFen(value) {
  if (value === null || value === undefined || String(value).trim() === "") return null;
  let text = String(value).trim().replace(/[¥￥$,，\s]/g, "");
  let negative = false;
  if (/^\(.*\)$/.test(text)) { negative = true; text = text.slice(1, -1); }
  if (/^[+-]/.test(text)) { negative ||= text[0] === "-"; text = text.slice(1); }
  const match = text.match(/^(\d+)(?:\.(\d*))?$/);
  if (!match) throw new Error(`金额格式无法识别：${String(value)}`);
  const whole = BigInt(match[1]);
  const decimals = match[2] || "";
  let cents = whole * 100n + BigInt((decimals + "00").slice(0, 2));
  if (decimals.length > 2 && Number(decimals[2]) >= 5) cents += 1n;
  if (negative) cents = -cents;
  if (cents > BigInt(Number.MAX_SAFE_INTEGER) || cents < BigInt(Number.MIN_SAFE_INTEGER)) throw new Error("金额超出安全计算范围");
  return Number(cents);
}

export function parseQuantityMilli(value) {
  if (value === null || value === undefined || String(value).trim() === "") return null;
  const text = String(value).trim();
  if (/[,，]/.test(text)) throw new Error(`数量格式不明确：${String(value)}。请使用小数点，例如 1.5；不要使用逗号分隔。`);
  const match = text.match(/^(\d+)(?:\.(\d*))?$/);
  if (!match) throw new Error(`数量格式无法识别：${String(value)}`);
  const fraction = match[2] || "";
  if (fraction.length > 3 && Number(fraction[3]) >= 5) {
    const base = BigInt(match[1]) * 1000n + BigInt((fraction + "000").slice(0, 3)) + 1n;
    if (base > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("数量超出安全计算范围");
    return Number(base);
  }
  const milli = BigInt(match[1]) * 1000n + BigInt((fraction + "000").slice(0, 3));
  if (milli > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("数量超出安全计算范围");
  return Number(milli);
}

export function multiplyFenByMilli(fen, quantityMilli) {
  const n = BigInt(fen) * BigInt(quantityMilli);
  const sign = n < 0n ? -1n : 1n;
  const abs = n < 0n ? -n : n;
  const rounded = (abs + 500n) / 1000n * sign;
  if (rounded > BigInt(Number.MAX_SAFE_INTEGER) || rounded < BigInt(Number.MIN_SAFE_INTEGER)) throw new Error("计算金额超出安全范围");
  return Number(rounded);
}

export function normalizeDate(value) {
  if (value instanceof Date && !Number.isNaN(value.valueOf())) return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
  const text = String(value ?? "").trim();
  if (!text) return null;
  // Read the calendar date as written. Never let a browser timezone shift an
  // order or refund into the preceding/following accounting day.
  const iso = text.match(/^(\d{4})[-./](\d{1,2})[-./](\d{1,2})(?:$|[T\s])/);
  const chinese = text.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日?/);
  let year, month, day;
  if (iso || chinese) {
    const parts = iso || chinese;
    [, year, month, day] = parts.map((part, index) => index === 0 ? part : Number(part));
    year = Number(year);
  } else {
    const local = text.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
    if (!local) return null;
    const first = Number(local[1]), second = Number(local[2]);
    if (first <= 12 && second <= 12) return null;
    year = Number(local[3]);
    if (first > 12) { day = first; month = second; } // unambiguous DMY
    else { month = first; day = second; } // unambiguous MDY
  }
  const check = new Date(Date.UTC(year, month - 1, day));
  if (check.getUTCFullYear() !== year || check.getUTCMonth() !== month - 1 || check.getUTCDate() !== day) return null;
  return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function normalizedStatus(value) { return String(value ?? "").normalize("NFKC").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[\s_—-]/g, ""); }
const STATUS = {
  valid: new Set(["已支付", "付款成功", "已发货", "已完成", "交易成功", "已签收", "success", "paid", "complete", "completed", "shipped", "fulfilled", "delivered", "expedie", "livre", "termine", "payee", "pagado", "enviado", "entregado", "completado", "oplacono", "отправлен", "доставлен", "завершен", "оплачен", "تمالشحن", "تمالتوصيل", "مكتمل", "مدفوع"]),
  cancelled: new Set(["已取消", "已关闭", "交易关闭", "取消", "closed", "cancelled", "canceled", "voided", "cancelledbybuyer", "annule", "anulee", "cancelado", "anulado", "отменен", "отменено", "ملغي", "أُلغي"]),
};

export function classifyOrderStatus(value) {
  const text = normalizedStatus(value);
  if (STATUS.cancelled.has(text)) return "cancelled";
  if (STATUS.valid.has(text)) return "valid";
  return "unknown";
}

export function isRefundConfirmed(value) {
  const text = normalizedStatus(value);
  return new Set(["成功", "已完成", "已退款", "退款成功", "success", "complete", "completed", "finished", "refunded", "refundcomplete", "部分退款成功", "仅退款成功", "rembourse", "remboursee", "remboursementtermine", "reembolso", "reembolsado", "refundido", "devuelto", "возвращен", "возвратвыполнен", "возвратзавершен", "تمالاسترداد", "مسترد"]).has(text);
}

export function isSettlementConfirmed(value) {
  return new Set(["成功", "已结算", "已到账", "已完成", "success", "settled", "complete", "completed", "paid", "released", "paye", "verse", "liquidado", "pagado", "выплачен", "зачислен", "تمالدفع", "تمالتحويل"]).has(normalizedStatus(value));
}

export const CURRENCIES = Object.freeze({ CNY: '人民币（CNY）', USD: '美元（USD）', EUR: '欧元（EUR）', GBP: '英镑（GBP）', CAD: '加拿大元（CAD）', AUD: '澳大利亚元（AUD）', SAR: '沙特里亚尔（SAR）' });
let displayCurrency = 'CNY';
let displayLocale = 'zh-CN';
export function setDisplayCurrency(currency, language = 'zh-CN') { displayCurrency = Object.hasOwn(CURRENCIES, currency) ? currency : 'CNY'; displayLocale = ({'zh-CN':'zh-CN',en:'en-US',fr:'fr-FR',ru:'ru-RU',es:'es-ES',ar:'ar-SA'})[language] || 'zh-CN'; }
export function formatFen(fen, currency = displayCurrency) {
  const n = Number(fen || 0) / 100;
  return `${currency === 'CNY' ? '¥' : `${currency} `}${n.toLocaleString(displayLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatQuantity(milli) {
  return (Number(milli || 0) / 1000).toLocaleString(displayLocale, { maximumFractionDigits: 3 });
}

const feeTerms = {
  shipping: /运费|物流|配送|shipping|delivery|postage|fulfil|expedition|livraison|transport|доставк|envio|reparto|الشحن|توصيل/,
  commission: /佣金|技术服务|平台服务|扣点|commission|referral|transactionfee|servicefee|marketplacefee|fraisdevente|provision|комисс|comision|comision|عمولة|رسومالمعالجة/,
  promotion: /推广|广告|直通车|营销|advert|promotion|promoted|sponsored|marketing|publicit|werbung|реклам|promocion|publicidad|اعلان|ترويج/,
};
export function classifyFeeType(value) {
  const text = String(value || '').normalize('NFKC').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s_—-]/g, '');
  return Object.entries(feeTerms).find(([, pattern]) => pattern.test(text))?.[0] || 'other';
}

export function findCost(costs, storeId, skuId, date) {
  return costs
    .filter((cost) => cost.storeId === storeId && cost.skuId === skuId && cost.effectiveFrom <= date && (!cost.effectiveTo || cost.effectiveTo >= date))
    .sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom))[0] || null;
}

export function calculateSummary(data, { storeId = "all", start, end }) {
  const stores = data.stores.filter((s) => storeId === "all" || s.id === storeId);
  if (new Set(stores.map((store) => store.currency || 'CNY')).size > 1) throw new Error('不同币种不能合并统计，请选择单个店铺。');
  const allowed = new Set(stores.map((s) => s.id));
  const orders = data.orders.filter((o) => allowed.has(o.storeId));
  const orderById = new Map(orders.map((o) => [o.id, o]));
  const validOrders = orders.filter((o) => o.statusClass === "valid");
  const periodOrders = validOrders.filter((o) => o.orderedAt >= start && o.orderedAt <= end);
  const periodOrderIds = new Set(periodOrders.map((o) => o.id));
  const orderItems = data.orderItems.filter((item) => periodOrderIds.has(item.orderId));
  const grossSalesFen = orderItems.reduce((sum, row) => sum + row.amountFen, 0);
  const itemCountMilli = orderItems.reduce((sum, row) => sum + row.quantityMilli, 0);

  const refunds = data.refunds.filter((r) => allowed.has(r.storeId) && r.confirmed && r.completedAt >= start && r.completedAt <= end);
  const refundFen = refunds.reduce((sum, row) => sum + row.amountFen, 0);
  const fees = data.platformFees.filter((r) => allowed.has(r.storeId) && r.feeDate >= start && r.feeDate <= end);
  const feeFen = fees.reduce((sum, row) => sum + row.amountFen, 0);
  const expenses = data.otherExpenses.filter((r) => allowed.has(r.storeId) && r.expenseDate >= start && r.expenseDate <= end);
  const expenseFen = expenses.reduce((sum, row) => sum + row.amountFen, 0);

  let costFen = 0;
  const missingCosts = new Map();
  for (const item of orderItems) {
    const order = orderById.get(item.orderId);
    const cost = findCost(data.productCosts, item.storeId, item.skuId, order.orderedAt);
    if (!cost) {
      const key = `${item.storeId}|${item.skuId}`;
      const existing = missingCosts.get(key) || { storeId: item.storeId, skuId: item.skuId, productName: item.productName || "未命名商品", quantityMilli: 0 };
      existing.quantityMilli += item.quantityMilli;
      missingCosts.set(key, existing);
    } else {
      costFen += multiplyFenByMilli(cost.unitCostFen, item.quantityMilli);
    }
  }

  const netSalesFen = grossSalesFen - refundFen;
  const knownProfitFen = netSalesFen - costFen - feeFen - expenseFen;
  const cancelledCount = orders.filter((o) => o.statusClass === "cancelled" && o.orderedAt >= start && o.orderedAt <= end).length;
  const unknownCount = orders.filter((o) => o.statusClass === "unknown" && o.orderedAt >= start && o.orderedAt <= end).length;
  const settlementFen = data.settlements.filter((r) => allowed.has(r.storeId) && r.confirmed && r.settlementDate >= start && r.settlementDate <= end).reduce((sum, r) => sum + r.amountFen, 0);
  const missingInputs = [];
  if (missingCosts.size) missingInputs.push("有些已售商品还没有进货价");
  const unresolvedCount = orders.filter((o) => o.statusClass === "unknown" && o.orderedAt >= start && o.orderedAt <= end && !/(待付款|待支付|等待付款|等待支付|未付款|pending|unpaid|awaitingpayment|enattentedepaiement|pendientedepago|porpagar|ожидаетоплаты|неоплачен|بانتظارالدفع|غيرمدفوع)/i.test(String(o.orderStatus || "").normalize("NFKC").replace(/[\s_—-]/g, ""))).length;
  if (unresolvedCount) missingInputs.push(`${unresolvedCount} 个订单状态尚未确认，暂未计入销售`);
  // Row dates describe observed records, not the period covered by a complete report.
  // Only explicit coverage confirmation can establish completeness; old batches remain uncertain.
  const covered = (storeId, type) => data.importBatches.some((batch) => batch.storeId === storeId && batch.reportType === type && batch.coverageConfirmed === true && batch.coverageStart && batch.coverageEnd && batch.coverageStart <= start && batch.coverageEnd >= end);
  const activeStoreIds = new Set([...periodOrders, ...refunds, ...fees, ...expenses].map((row) => row.storeId));
  for (const [type, label] of [["refunds", "退款表"], ["fees", "平台扣费表"], ["expenses", "其他支出表"]]) {
    const missingCount = [...activeStoreIds].filter((id) => !covered(id, type)).length;
    if (missingCount) missingInputs.push(`${missingCount} 个店铺的${label}覆盖范围尚未确认`);
  }

  return {
    start, end, storeIds: [...allowed], grossSalesFen, refundFen, netSalesFen,
    costFen, feeFen, expenseFen, knownProfitFen,
    profitMargin: netSalesFen > 0 ? knownProfitFen / netSalesFen : null,
    orderCount: periodOrders.length, itemCountMilli, cancelledCount, unknownCount,
    refundCount: refunds.length, feeCount: fees.length, expenseCount: expenses.length,
    settlementFen, missingCosts: [...missingCosts.values()], missingInputs,
    complete: missingInputs.length === 0,
  };
}

export function dailyTrend(data, summary) {
  const validOrders = data.orders.filter((o) => summary.storeIds.includes(o.storeId) && o.statusClass === "valid");
  const ordersById = new Map(validOrders.map((o) => [o.id, o]));
  const days = new Map();
  const start = new Date(`${summary.start}T00:00:00Z`);
  const end = new Date(`${summary.end}T00:00:00Z`);
  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    days.set(d.toISOString().slice(0, 10), 0);
  }
  for (const item of data.orderItems) {
    const order = ordersById.get(item.orderId);
    if (order && days.has(order.orderedAt)) days.set(order.orderedAt, days.get(order.orderedAt) + item.amountFen);
  }
  return [...days].map(([date, grossSalesFen]) => ({ date, grossSalesFen }));
}

export function productSummary(data, summary) {
  const validOrders = data.orders.filter((o) => summary.storeIds.includes(o.storeId) && o.statusClass === "valid" && o.orderedAt >= summary.start && o.orderedAt <= summary.end);
  const ordersById = new Map(validOrders.map((o) => [o.id, o]));
  const map = new Map();
  for (const item of data.orderItems) {
    if (!ordersById.has(item.orderId)) continue;
    const key = `${item.storeId}|${item.skuId}`;
    const row = map.get(key) || { storeId: item.storeId, skuId: item.skuId, productName: item.productName || "未命名商品", quantityMilli: 0, salesFen: 0, costFen: 0, missingCost: false };
    row.quantityMilli += item.quantityMilli;
    row.salesFen += item.amountFen;
    const cost = findCost(data.productCosts, item.storeId, item.skuId, ordersById.get(item.orderId).orderedAt);
    if (cost) row.costFen += multiplyFenByMilli(cost.unitCostFen, item.quantityMilli);
    else row.missingCost = true;
    map.set(key, row);
  }
  return [...map.values()].sort((a, b) => b.salesFen - a.salesFen);
}

export function findFeeSettlementMismatches(data, toleranceFen = 1) {
  const ordersByKey = new Map(data.orders.map((o) => [`${o.storeId}|${o.platformOrderId}`, o]));
  const grossByOrder = new Map();
  for (const item of data.orderItems) grossByOrder.set(item.orderId, (grossByOrder.get(item.orderId) || 0) + item.amountFen);
  const refundsByOrderKey = new Map();
  for (const refund of data.refunds.filter((r) => r.confirmed)) {
    const key = `${refund.storeId}|${refund.platformOrderId}`;
    refundsByOrderKey.set(key, (refundsByOrderKey.get(key) || 0) + refund.amountFen);
  }
  const feesByOrderKey = new Map();
  for (const fee of data.platformFees.filter((r) => r.platformOrderId)) {
    const key = `${fee.storeId}|${fee.platformOrderId}`;
    feesByOrderKey.set(key, (feesByOrderKey.get(key) || 0) + fee.amountFen);
  }
  const settlementsByOrderKey = new Map();
  for (const row of data.settlements.filter((r) => r.confirmed && r.platformOrderId)) {
    const key = `${row.storeId}|${row.platformOrderId}`;
    settlementsByOrderKey.set(key, (settlementsByOrderKey.get(key) || 0) + row.amountFen);
  }
  const mismatches = [];
  for (const [key, settledFen] of settlementsByOrderKey) {
    const order = ordersByKey.get(key);
    if (!order || order.statusClass !== "valid") continue;
    const gross = grossByOrder.get(order.id) || 0;
    const refund = refundsByOrderKey.get(key) || 0;
    const fee = feesByOrderKey.get(key) || 0;
    const expectedFen = gross - refund - fee;
    const differenceFen = settledFen - expectedFen;
    if (Math.abs(differenceFen) > toleranceFen) mismatches.push({ storeId: order.storeId, platformOrderId: order.platformOrderId, expectedFen, settledFen, differenceFen });
  }
  return mismatches;
}

export function reconcileFeeSettlementIssues(data, now = new Date().toISOString()) {
  const previous = new Map((data.issues || [])
    .filter((issue) => issue.issueType === "fee_settlement_mismatch")
    .map((issue) => [issue.stableKey, issue]));
  const updates = [];
  for (const mismatch of findFeeSettlementMismatches(data)) {
    const stableKey = `fee-settlement|${mismatch.storeId}|${mismatch.platformOrderId}`;
    const old = previous.get(stableKey);
    const currency = data.stores.find(store => store.id === mismatch.storeId)?.currency || 'CNY';
    const description = `订单 ${mismatch.platformOrderId} 的预计到账与表格里的实际到账相差 ${formatFen(mismatch.differenceFen, currency)}。请打开平台账单检查。`;
    if (!old) {
      updates.push({ id: `derived-${encodeURIComponent(stableKey)}`, stableKey, storeId: mismatch.storeId,
        issueType: "fee_settlement_mismatch", severity: "warning", status: "open", description,
        amountDifferenceFen: mismatch.differenceFen, relatedRecordIds: [], resolutionNote: "", createdAt: now });
    } else {
      previous.delete(stableKey);
      if (old.status !== "resolved" && (old.description !== description || old.amountDifferenceFen !== mismatch.differenceFen)) {
        updates.push({ ...old, description, amountDifferenceFen: mismatch.differenceFen, updatedAt: now });
      }
    }
  }
  for (const [stableKey, old] of previous) {
      if (old.status !== "resolved") updates.push({ ...old, status: "resolved", resolutionNote: "更新表格后，这笔金额差异已经消失。", resolvedAt: now, updatedAt: now });
  }
  return updates;
}

export function reconcileMissingCostIssues(data, now = new Date().toISOString()) {
  const orderById = new Map(data.orders.map((order) => [order.id, order]));
  const costsBySku = new Map();
  for (const cost of data.productCosts) {
    const key = `${cost.storeId}|${cost.skuId}`;
    const rows = costsBySku.get(key) || [];
    rows.push(cost);
    costsBySku.set(key, rows);
  }
  const missingBySku = new Map();
  for (const item of data.orderItems) {
    const order = orderById.get(item.orderId);
    if (!order || order.statusClass !== "valid") continue;
    const orderedAt = item.orderedAt || order.orderedAt;
    const hasCost = (costsBySku.get(`${order.storeId}|${item.skuId}`) || []).some((cost) => cost.effectiveFrom <= orderedAt
      && (!cost.effectiveTo || cost.effectiveTo >= orderedAt));
    if (hasCost) continue;
    const key = `${order.storeId}|${item.skuId}`;
    const row = missingBySku.get(key) || { storeId: order.storeId, skuId: item.skuId, dates: [], quantityMilli: 0 };
    row.dates.push(orderedAt);
    row.quantityMilli += item.quantityMilli || 0;
    missingBySku.set(key, row);
  }
  const previous = new Map((data.issues || []).filter((issue) => issue.issueType === "missing_cost").map((issue) => [issue.stableKey, issue]));
  const updates = [];
  for (const missing of missingBySku.values()) {
    const stableKey = `missing-cost|${missing.storeId}|${missing.skuId}`;
    const dates = missing.dates.sort();
    const description = `商品编号 ${missing.skuId} 在 ${dates[0]} 至 ${dates.at(-1)} 没有填写进货价；涉及 ${missing.quantityMilli / 1000} 件商品，利润暂不完整。`;
    const old = previous.get(stableKey);
    if (!old) {
      updates.push({ id: `derived-${encodeURIComponent(stableKey)}`, stableKey, storeId: missing.storeId,
        issueType: "missing_cost", severity: "warning", status: "open", description,
        amountDifferenceFen: null, relatedRecordIds: [], resolutionNote: "", createdAt: now });
    } else {
      previous.delete(stableKey);
      if (old.status === "resolved") updates.push({ ...old, status: "open", description, resolutionNote: "", updatedAt: now });
      else if (old.description !== description) updates.push({ ...old, description, updatedAt: now });
    }
  }
  for (const old of previous.values()) {
    if (old.status !== "resolved") updates.push({ ...old, status: "resolved", resolutionNote: "已补上这段时间使用的商品进货价。", resolvedAt: now, updatedAt: now });
  }
  return updates;
}

export function stableRecordKey(kind, row) {
  const parts = {
    orders: row.platformItemId ? [row.storeId, row.platformOrderId, row.platformItemId] : [row.storeId, row.platformOrderId, row.skuId, row.orderedAt, row.quantityMilli, row.amountFen],
    refunds: row.platformRefundId ? [row.storeId, row.platformRefundId] : [row.storeId, row.platformOrderId, row.completedAt, row.amountFen],
    fees: row.feeId ? [row.storeId, row.feeId] : [row.storeId, row.platformOrderId || "store", row.feeDate, row.feeType, row.amountFen],
    costs: [row.storeId, row.skuId, row.effectiveFrom],
    expenses: row.expenseId ? [row.storeId, row.expenseId] : [row.storeId, row.expenseDate, row.expenseType, row.amountFen, row.platformOrderId || "", row.skuId || ""],
    settlements: row.transactionId ? [row.storeId, row.transactionId] : [row.storeId, row.platformOrderId || "store", row.settlementDate, row.amountFen, row.settlementStatus],
  }[kind];
  return `${kind}|${parts.map((p) => String(p ?? "").trim()).join("|")}`;
}

export function dedupeCandidates(candidates, existingRecords = []) {
  const byKey = new Map(existingRecords.map((row) => [row.recordKey, row.rowHash]));
  const accepted = [];
  const duplicates = [];
  const conflicts = [];
  for (const row of candidates) {
    if (byKey.has(row.recordKey)) {
      (byKey.get(row.recordKey) === row.rowHash ? duplicates : conflicts).push(row);
    } else {
      accepted.push(row);
      byKey.set(row.recordKey, row.rowHash);
    }
  }
  return { accepted, duplicates, conflicts };
}

export function periodKey(storeId, start, end) {
  return `${storeId}|${start}|${end}|${CALCULATION_RULE_VERSION}`;
}
