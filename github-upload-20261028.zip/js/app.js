import { clearAllData, openDatabase, putOne, readAll, readSnapshot, undoImportBatch, writeRecords } from "./db.js";
import { CALCULATION_RULE_VERSION, REPORTS, STORE_NAMES, calculateSummary, classifyFeeType, classifyOrderStatus, dedupeCandidates, findCost, findFeeSettlementMismatches, formatFen, formatQuantity, multiplyFenByMilli, normalizeDate, parseMoneyFen, periodKey, reconcileFeeSettlementIssues, reconcileMissingCostIssues, stableRecordKey } from "./domain.js";
import { commitImport, MAX_DATA_ROWS, MAX_FILE_BYTES, normalizeMoneyForCurrency, prepareImport, readTabularFile, sha256, suggestMapping } from "./importer.js";
import { makeBackup, restoreBackup, validateBackup } from "./backup.js";
import { downloadWorkbook } from "./exporter.js";
import { buildProfitInsights } from "./insights.js";
import { trendSvg } from "./charts.js";
import { loadDemoData } from "./sample.js";
import { isLanguage, resolveLanguage, setupLanguage } from "./language.js";
import { ensureSpreadsheetLibrary } from "./spreadsheet-loader.js";
import { CURRENCIES, setDisplayCurrency } from "./domain.js";

const PREFS_KEY = "seller-profit-assistant:prefs:v1";
const PAGE_META = {
  overview: ["看赚多少", "看看最近经营情况"], stores: ["店铺管理", "管理你的店铺"], import: ["导入表格", "添加订单和费用"],
  records: ["数据明细", "查看已保存的数据"], costs: ["商品成本", "补上商品进货成本"], issues: ["需要处理", "检查导入中的问题"],
  settings: ["备份数据", "保护和搬运本机数据"], guide: ["新手教程", "第一次使用看这里"],
};
const ISSUE_LABELS = {
  missing_cost: "还没有商品成本", fee_settlement_mismatch: "到账金额对不上", unknown_order_status: "订单状态看不懂",
  import_validation: "表格内容有问题", duplicate_record: "重复数据", record_conflict: "订单信息不一致",
  unmatched_fee: "有费用找不到对应订单", order_status_conflict: "订单信息不一致",
};
const SEVERITY_LABELS = { error: "需要处理", warning: "请留意", info: "提示" };
const ISSUE_STATUS_LABELS = { open: "待处理", review: "检查中", resolved: "已处理" };
const EMPTY_DATA = () => Object.fromEntries(STORE_NAMES.map((name) => [name, []]));
const GUIDED_TOUR_STEPS = [
  { page: "overview", target: '[data-nav="overview"]', name: "经营总览", title: "先看经营总览", copy: "这里集中显示销售额、退款、预计利润和趋势图。下面会用虚构样例演示这些数字从哪里来。" },
  { page: "issues", target: '[data-nav="issues"]', name: "需要处理", title: "提醒会集中放在这里", copy: "点开后可以查看缺少商品成本、订单状态看不懂或到账金额对不上等问题，再按每条说明检查。" },
  { page: "costs", target: '[data-nav="costs"]', name: "商品成本", title: "补上每件商品的进货价", copy: "成本按商品编号匹配订单。编号相同，系统才能把进货价算进预计利润；样例里已经放好了几项成本。" },
  { page: "import", target: '[data-nav="import"]', name: "导入表格", title: "自己的数据从这里导入", copy: "选店铺、表格类型和文件。保存前先核对列名、预览和问题条数；本次体验不需要上传你的文件。" },
  { page: "overview", target: '[data-nav="overview"]', name: "经营总览", title: "最后回到总览看结果", copy: "样例图表、销售额、退款和预计利润都在这里。演示店铺名称带有“虚构数据”字样，不会和你的真实店铺混在一起。" },
];
const $ = (selector, root = document) => root.querySelector(selector);
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
const uid = () => globalThis.crypto?.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
const localToday = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
};
const dateOffset = (dateString, offset) => {
  const d = new Date(`${dateString}T12:00:00`);
  d.setDate(d.getDate() + offset);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
const bytesLabel = (value) => {
  if (!Number.isFinite(value)) return "—";
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(0)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
};

function readPrefs() {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw || raw.length > 4096) return {};
    const value = JSON.parse(raw);
    return value && typeof value === "object" ? value : {};
  } catch { return {}; }
}

const savedPrefs = readPrefs();
const todayAtLoad = localToday();
const migrateLegacy30DayRange = savedPrefs.overviewDefaultMigrated !== true
  && savedPrefs.start === dateOffset(todayAtLoad, -29) && savedPrefs.end === todayAtLoad;
const state = {
  db: null,
  page: PAGE_META[savedPrefs.page] ? savedPrefs.page : "overview",
  selectedStoreId: typeof savedPrefs.storeId === "string" ? savedPrefs.storeId : "all",
  start: migrateLegacy30DayRange ? `${todayAtLoad.slice(0, 7)}-01` : typeof savedPrefs.start === "string" ? savedPrefs.start : "",
  end: migrateLegacy30DayRange ? todayAtLoad : typeof savedPrefs.end === "string" ? savedPrefs.end : "",
  lowMarginThreshold: Number.isFinite(Number(savedPrefs.lowMarginThreshold)) ? Math.max(0, Math.min(50, Number(savedPrefs.lowMarginThreshold))) : 10,
  focusProduct: null,
  overviewDefaultMigrated: true,
  guidedTourSeen: savedPrefs.guidedTourSeen === true,
  lastBackupAt: typeof savedPrefs.lastBackupAt === "string" ? savedPrefs.lastBackupAt : "",
  language: resolveLanguage(savedPrefs.language, navigator.languages?.length ? navigator.languages : [navigator.language]),
  guidedTourActive: false,
  guidedTourStep: 0,
  recordType: "orders",
  recordQuery: "",
  recordPage: 0,
  recordStatus: "all",
  recordUsePeriod: false,
  editCostId: null,
  importStoreId: "",
  importReportType: "orders",
  pendingFile: null,
  pendingSourceFile: null,
  csvEncoding: 'auto',
  dateOrder: '',
  importMapping: null,
  importPlan: null,
  data: EMPTY_DATA(),
  isBusy: false,
};

function savePrefs() {
  const prefs = { page: state.page, storeId: state.selectedStoreId, start: state.start, end: state.end, lowMarginThreshold: state.lowMarginThreshold, overviewDefaultMigrated: state.overviewDefaultMigrated, guidedTourSeen: state.guidedTourSeen, lastBackupAt: state.lastBackupAt, language: state.language };
  const serialized = JSON.stringify(prefs);
  if (serialized.length > 2048) return;
  try { localStorage.setItem(PREFS_KEY, serialized); }
  catch { toast("浏览器没有保存页面偏好；经营记录仍保存在此浏览器。", "warn"); }
}

if (migrateLegacy30DayRange) savePrefs();

function toast(message, type = "ok", duration = 4300) {
  const node = document.createElement("div");
  node.className = `toast ${type === "error" ? "error" : type === "warn" ? "warn" : ""}`;
  node.textContent = message;
  $("#toast-stack").append(node);
  window.setTimeout(() => node.remove(), duration);
}

function openTutorial() {
  const dialog = $("#welcome-tutorial");
  $("[data-action='tutorial-skip']", dialog).hidden = !state.guidedTourSeen;
  $(".tutorial-close", dialog).hidden = !state.guidedTourSeen;
  if (!dialog.open) {
    if (typeof dialog.showModal === "function") dialog.showModal();
    else dialog.setAttribute("open", "");
  }
}

function closeTutorial() {
  const dialog = $("#welcome-tutorial");
  if (dialog.open && typeof dialog.close === "function") dialog.close();
  else {
    dialog.removeAttribute("open");
  }
}

function markTutorialSeen() {
  state.guidedTourSeen = true;
  savePrefs();
}

function positionGuidedTour() {
  if (!state.guidedTourActive) return;
  const step = GUIDED_TOUR_STEPS[state.guidedTourStep];
  const target = step && $(step.target);
  const layer = $("#guided-tour");
  const spotlight = $("#guided-tour-spotlight");
  const card = $("#guided-tour-card");
  if (!step || !target) return;
  layer.hidden = false;
  const rect = target.getBoundingClientRect();
  spotlight.style.left = `${Math.max(0, rect.left - 4)}px`;
  spotlight.style.top = `${Math.max(0, rect.top - 4)}px`;
  spotlight.style.width = `${rect.width + 8}px`;
  spotlight.style.height = `${rect.height + 8}px`;
  spotlight.setAttribute("aria-label", `点击高亮的${step.name}继续`);
  card.style.width = `min(360px, calc(100vw - 24px))`;
  const cardHeight = card.getBoundingClientRect().height;
  if (window.innerWidth <= 760) {
    card.style.left = "12px";
    card.style.top = `${Math.max(12, Math.min(rect.bottom + 16, window.innerHeight - cardHeight - 12))}px`;
  } else {
    const width = Math.min(360, window.innerWidth - 24);
    let left = rect.right + 20;
    if (left + width > window.innerWidth - 12) left = Math.max(12, rect.left - width - 20);
    card.style.left = `${left}px`;
    card.style.top = `${Math.max(12, Math.min(rect.top - 18, window.innerHeight - cardHeight - 12))}px`;
  }
}

function renderGuidedTour() {
  const layer = $("#guided-tour");
  if (!state.guidedTourActive) { layer.hidden = true; return; }
  const step = GUIDED_TOUR_STEPS[state.guidedTourStep];
  if (!step) return;
  // The costs page now lives inside the More menu; reveal it before measuring
  // the highlighted target, including when navigating back in the tour.
  const target = $(step.target);
  const more = target?.closest("details.nav-more");
  if (more) more.open = true;
  $("#guided-tour-step").textContent = `第 ${state.guidedTourStep + 1} 步，共 ${GUIDED_TOUR_STEPS.length} 步`;
  $("#guided-tour-title").textContent = step.title;
  $("#guided-tour-copy").textContent = step.copy;
  $("#guided-tour-prompt").textContent = `请点击高亮的“${step.name}”继续`;
  $("[data-action='guided-tour-back']").hidden = state.guidedTourStep === 0;
  $("[data-action='guided-tour-skip']").hidden = !state.guidedTourSeen;
  layer.hidden = false;
  requestAnimationFrame(() => {
    $(step.target)?.scrollIntoView({ block: "nearest", inline: "center" });
    positionGuidedTour();
    $(step.target)?.focus({ preventScroll: true });
  });
}

function finishGuidedTour({ skipped = false } = {}) {
  if (skipped && !state.guidedTourSeen) return;
  state.guidedTourActive = false;
  $("#guided-tour").hidden = true;
  if (!skipped) markTutorialSeen();
  if (skipped) toast("已退出引导。虚构样例仍保存在单独的演示店铺中。", "warn", 5500);
  else {
    state.page = "overview";
    savePrefs();
    renderPage();
    toast("体验完成，经营总览已显示虚构样例结果。", "ok", 6000);
  }
}

async function startGuidedTour(control) {
  if (control) control.disabled = true;
  try {
    await loadDemoData(state.db);
    state.selectedStoreId = "demo-store-local-v1";
    state.start = `${localToday().slice(0, 7)}-01`;
    state.end = localToday();
    await refreshData();
    state.page = "overview";
    state.guidedTourStep = 0;
    state.guidedTourActive = true;
    closeTutorial();
    savePrefs();
    renderPage();
    renderGuidedTour();
  } catch (error) {
    presentError(normalizeIdbError(error), "无法开始引导");
    const description = $("#tutorial-description");
    if (description) description.textContent = `虚构样例没有载入成功：${error?.message || "请检查浏览器存储空间后重试。"}`;
  } finally {
    if (control?.isConnected) control.disabled = false;
  }
}

function presentError(error, context = "操作未完成") {
  const quota = error?.name === "QuotaExceededError" || error?.code === 22 || /quota|storage.*full/i.test(error?.message || "");
  if (quota) {
    toast("浏览器本地空间不足，操作没有保存。请先导出备份，清理无用数据或释放设备空间后重试。", "error", 8000);
  } else {
    toast(`${context}：${error?.message || "未知错误"}。数据没有被标记为已保存。`, "error", 8000);
  }
  console.error(context, error);
}

async function refreshData() {
  state.data = await readSnapshot(state.db);
  const derivedIssues = [...reconcileFeeSettlementIssues(state.data), ...reconcileMissingCostIssues(state.data)];
  if (derivedIssues.length) {
    await writeRecords(state.db, { issues: derivedIssues }, "put");
    state.data = await readSnapshot(state.db);
  }
  const storeIds = new Set(state.data.stores.map((store) => store.id));
  if (state.selectedStoreId !== "all" && !storeIds.has(state.selectedStoreId)) state.selectedStoreId = "all";
  if (state.selectedStoreId === 'all' && new Set(state.data.stores.map(store => store.currency || 'CNY')).size > 1) state.selectedStoreId = state.data.stores[0].id;
  if (state.importStoreId && !storeIds.has(state.importStoreId)) state.importStoreId = "";
  if (!state.start || !state.end) setDefaultPeriod(state.data);
  if (state.start > state.end) [state.start, state.end] = [state.end, state.start];
}

function setDefaultPeriod(data) {
  const today = localToday();
  state.end = today;
  state.start = `${today.slice(0, 7)}-01`;
}

function selectedStoreName(data = state.data) {
  if (state.selectedStoreId === "all") return "全部店铺";
  return data.stores.find((row) => row.id === state.selectedStoreId)?.name || "全部店铺";
}

function fillGlobalControls(data) {
  const storeSelect = $("#global-store-select");
  const mixedCurrencies = new Set(data.stores.map(store => store.currency || 'CNY')).size > 1;
  storeSelect.innerHTML = `${mixedCurrencies ? '' : '<option value="all">全部店铺</option>'}${data.stores.map((store) => `<option value="${esc(store.id)}" ${store.demo ? 'data-demo-name="true"' : ""}>${esc(store.name)} · ${esc(store.currency || 'CNY')}</option>`).join("")}`;
  storeSelect.value = state.selectedStoreId;
  $(".store-control").hidden = data.stores.length <= 1;
  const selectedStore = data.stores.find((store) => store.id === state.selectedStoreId);
  const storeKind = $("#global-store-kind");
  storeKind.hidden = !selectedStore?.demo;
  storeKind.textContent = selectedStore?.demo ? "演示数据" : "";
  $("#global-start").value = state.start;
  $("#global-end").value = state.end;
  if ($("#overview-start")) $("#overview-start").value = state.start;
  if ($("#overview-end")) $("#overview-end").value = state.end;
  const openIssues = uniqueVisibleIssues(data.issues.filter((issue) => (issue.status === "open" || issue.status === "review") && (state.selectedStoreId === "all" || issue.storeId === state.selectedStoreId)), data).length;
  $("#nav-issue-count").textContent = openIssues ? String(openIssues) : "";
  document.querySelectorAll("[data-nav]").forEach((button) => {
    button.classList.toggle("active", button.dataset.nav === state.page);
    if (button.dataset.nav === "import") button.setAttribute("aria-label", "导入表格");
    if (button.dataset.nav === "issues") button.setAttribute("aria-label", `需要处理，${openIssues} 条待处理`);
  });
  const title = PAGE_META[state.page] || PAGE_META.overview;
  $("#top-title").textContent = title[0];
  $("#top-eyebrow").textContent = title[1];
  updateSidebarBackupStatus();
  document.querySelectorAll("[data-period]").forEach((button) => button.classList.toggle("active", matchesPreset(button.dataset.period)));
}

function matchesPreset(preset) {
  const today = localToday();
  if (preset === "7") return state.end === today && state.start === dateOffset(today, -6);
  if (preset === "30") return state.end === today && state.start === dateOffset(today, -29);
  if (preset === "month") return state.start === `${today.slice(0, 7)}-01` && state.end === today;
  if (preset === "previous-month") {
    const first = new Date(`${today.slice(0, 7)}-01T12:00:00`);
    first.setDate(0);
    const end = `${first.getFullYear()}-${String(first.getMonth() + 1).padStart(2, "0")}-${String(first.getDate()).padStart(2, "0")}`;
    return state.start === `${end.slice(0, 7)}-01` && state.end === end;
  }
  return false;
}

function backupStatus(data = state.data) {
  const hasSavedRecords = data && ["orders", "orderItems", "refunds", "platformFees", "productCosts", "otherExpenses", "settlements"].some((name) => data[name]?.length);
  if (!hasSavedRecords) return { text: "添加经营数据后，可在此备份。", overdue: false };
  if (!state.lastBackupAt) return { text: "尚未备份，建议导出一份副本。", overdue: true };
  const backupDate = new Date(state.lastBackupAt);
  const dayCount = Number.isFinite(backupDate.valueOf()) ? Math.max(0, Math.floor((Date.now() - backupDate.valueOf()) / 86400000)) : Infinity;
  return { text: dayCount > 7 ? `上次备份已过 ${dayCount} 天，建议导出最新副本。` : `上次备份：${backupDate.toLocaleDateString(state.language)}`, overdue: dayCount > 7 };
}

function updateSidebarBackupStatus(data = state.data) {
  const backup = backupStatus(data);
  document.querySelectorAll("#sidebar-backup-status, #dashboard-backup-status").forEach((node) => {
    node.textContent = backup.text;
    node.classList.toggle("overdue", backup.overdue);
  });
}

function currentSummary(data = state.data) {
  return calculateSummary(data, { storeId: state.selectedStoreId, start: state.start, end: state.end });
}

function storeName(data, storeId) { return data.stores.find((row) => row.id === storeId)?.name || "未知店铺"; }

function pageHeading(kicker, title, description, actions = "") {
  return `<div class="page-heading"><div>${kicker ? `<div class="kicker">${esc(kicker)}</div>` : ""}<h1>${title}</h1><p>${description}</p></div><div class="heading-actions">${actions}</div></div>`;
}

function emptyState(title, text, actions = "") {
  return `<section class="card empty-state"><div class="empty-art" aria-hidden="true">◌</div><h2>${title}</h2><p>${text}</p><div class="button-row">${actions}</div></section>`;
}

function cleanStatus(value) { return String(value ?? "").normalize("NFKC").trim().toLowerCase().replace(/[\s_—-]/g, ""); }

function isPendingOrderStatus(value) {
  const status = cleanStatus(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const pendingChinese = ["待付款", "待支付", "等待付款", "等待支付", "等待买家付款", "等待买家支付", "买家未付款", "未付款", "待买家付款", "待买家支付", "pending", "awaitingpayment", "awaitingfulfillment", "unpaid", "paymentpending", "enattentedepaiement", "pendientedepago", "pendientepago", "porpagar", "ожидаетоплаты", "неоплачен", "ожидаетоплаты", "بانتظارالدفع", "غيرمدفوع"];
  return pendingChinese.some((known) => status.includes(known)) || ["pending", "unpaid", "awaitingpayment"].includes(status);
}

function orderForIssue(issue, data = state.data) {
  if (issue.issueType !== "unknown_order_status") return null;
  const match = String(issue.description || "").match(/订单\s+(.+?)\s+的状态/);
  if (!match) return null;
  return data.orders.find((order) => order.storeId === issue.storeId && order.platformOrderId === match[1]) || null;
}

function isVisibleIssue(issue, data = state.data) {
  if (issue.issueType !== "unknown_order_status") return true;
  const order = orderForIssue(issue, data);
  return !(order && order.statusClass !== "valid" && isPendingOrderStatus(order.orderStatus));
}

function uniqueVisibleIssues(issues, data = state.data) {
  const seen = new Set();
  return issues.filter((issue) => {
    if (!isVisibleIssue(issue, data)) return false;
    const order = orderForIssue(issue, data);
    const key = order ? `unknown-order|${order.id}|${issue.status}` : issue.id;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function orderIssueActions(issue, order) {
  if (!order || issue.status === "resolved") return "";
  return `<div class="order-status-actions"><button class="button small" data-action="order-status" data-resolution="include" data-order-id="${esc(order.id)}" data-issue-id="${esc(issue.id)}">按已成交计入</button><button class="button secondary small" data-action="order-status" data-resolution="ignore" data-order-id="${esc(order.id)}" data-issue-id="${esc(issue.id)}">忽略</button><button class="button ghost small" data-action="order-status" data-resolution="manual" data-order-id="${esc(order.id)}" data-issue-id="${esc(issue.id)}">手动指定状态</button></div>`;
}

function dashboardIssueMarkup(issue, data) {
  const order = orderForIssue(issue, data);
  if (order) return `<article class="dashboard-issue-link status-issue-row"><div class="dashboard-issue-copy"><strong>${esc(ISSUE_LABELS[issue.issueType] || "需要检查")}</strong><span>订单 ${esc(order.platformOrderId)} 的状态“${esc(order.orderStatus)}”无法识别，默认没有计入销售。</span></div>${orderIssueActions(issue, order)}</article>`;
  return `<button class="dashboard-issue-link" data-action="open-issue" data-issue-id="${esc(issue.id)}"><span class="tag ${issue.severity === "error" ? "tag-danger" : "tag-warn"}">${esc(SEVERITY_LABELS[issue.severity] || "请检查")}</span><span class="dashboard-issue-copy"><strong>${esc(ISSUE_LABELS[issue.issueType] || "需要检查")}</strong><span>${esc(issue.description)}</span></span><span class="dashboard-issue-arrow" aria-hidden="true">↗</span></button>`;
}

function financialTrend(data, summary) {
  const days = new Map();
  const start = new Date(`${summary.start}T00:00:00Z`);
  const end = new Date(`${summary.end}T00:00:00Z`);
  for (let date = new Date(start); date <= end; date.setUTCDate(date.getUTCDate() + 1)) {
    days.set(date.toISOString().slice(0, 10), { date: date.toISOString().slice(0, 10), grossSalesFen: 0, costFen: 0, refundFen: 0, feeFen: 0, expenseFen: 0 });
  }
  const allowed = new Set(summary.storeIds);
  const orders = data.orders.filter((order) => allowed.has(order.storeId) && order.statusClass === "valid" && days.has(order.orderedAt));
  const orderById = new Map(orders.map((order) => [order.id, order]));
  for (const item of data.orderItems) {
    const order = orderById.get(item.orderId);
    if (!order) continue;
    const point = days.get(order.orderedAt);
    point.grossSalesFen += item.amountFen;
    const cost = findCost(data.productCosts, item.storeId, item.skuId, order.orderedAt);
    if (cost) point.costFen += multiplyFenByMilli(cost.unitCostFen, item.quantityMilli);
  }
  for (const refund of data.refunds) if (allowed.has(refund.storeId) && refund.confirmed && days.has(refund.completedAt)) days.get(refund.completedAt).refundFen += refund.amountFen;
  for (const fee of data.platformFees) if (allowed.has(fee.storeId) && days.has(fee.feeDate)) days.get(fee.feeDate).feeFen += fee.amountFen;
  for (const expense of data.otherExpenses) if (allowed.has(expense.storeId) && days.has(expense.expenseDate)) days.get(expense.expenseDate).expenseFen += expense.amountFen;
  return [...days.values()].map((point) => ({ ...point, profitFen: point.grossSalesFen - point.costFen - point.refundFen - point.feeFen - point.expenseFen }));
}

function previousPeriodSummary(data, summary) {
  const today = localToday();
  const monthStart = `${today.slice(0, 7)}-01`;
  if (summary.start === monthStart && summary.end === today) {
    const previousMonthLast = new Date(`${monthStart}T12:00:00`);
    previousMonthLast.setDate(0);
    const previousStart = `${previousMonthLast.getFullYear()}-${String(previousMonthLast.getMonth() + 1).padStart(2, "0")}-01`;
    const previousEndDay = Math.min(Number(today.slice(8, 10)), previousMonthLast.getDate());
    const previousEnd = `${previousStart.slice(0, 7)}-${String(previousEndDay).padStart(2, "0")}`;
    return calculateSummary(data, { storeId: state.selectedStoreId, start: previousStart, end: previousEnd });
  }
  const days = Math.round((Date.parse(`${summary.end}T00:00:00Z`) - Date.parse(`${summary.start}T00:00:00Z`)) / 86400000) + 1;
  const end = dateOffset(summary.start, -1);
  const start = dateOffset(end, -(Math.max(1, days) - 1));
  return calculateSummary(data, { storeId: state.selectedStoreId, start, end });
}

function periodDelta(current, previous, label) {
  const difference = current - previous;
  const percent = previous ? Math.abs(difference / Math.abs(previous) * 100).toFixed(1) : null;
  const direction = difference > 0 ? "up" : difference < 0 ? "down" : "flat";
  const text = previous ? `${direction === "up" ? "↑" : direction === "down" ? "↓" : "→"} ${percent}%` : difference ? "新增" : "持平";
  return `<span class="period-delta ${direction}">${esc(label)} ${text}（${difference > 0 ? "+" : ""}${esc(formatFen(difference))}）</span>`;
}

function feeComposition(data, summary) {
  const allowed = new Set(summary.storeIds);
  const fees = data.platformFees.filter((row) => allowed.has(row.storeId) && row.feeDate >= summary.start && row.feeDate <= summary.end);
  const expenses = data.otherExpenses.filter((row) => allowed.has(row.storeId) && row.expenseDate >= summary.start && row.expenseDate <= summary.end);
  const shippingFee = fees.filter((row) => classifyFeeType(row.feeType) === "shipping").reduce((sum, row) => sum + row.amountFen, 0);
  const shippingExpense = expenses.filter((row) => classifyFeeType(row.expenseType) === "shipping").reduce((sum, row) => sum + row.amountFen, 0);
  const commission = fees.filter((row) => classifyFeeType(row.feeType) === "commission").reduce((sum, row) => sum + row.amountFen, 0);
  const promotionFee = fees.filter((row) => classifyFeeType(row.feeType) === "promotion").reduce((sum, row) => sum + row.amountFen, 0);
  const promotionExpense = expenses.filter((row) => classifyFeeType(row.expenseType) === "promotion").reduce((sum, row) => sum + row.amountFen, 0);
  const shipping = shippingFee + shippingExpense;
  const promotion = promotionFee + promotionExpense;
  const other = summary.feeFen + summary.expenseFen - commission - shipping - promotion;
  return [
    ["商品销售额", summary.grossSalesFen, "income"], ["商品成本", summary.costFen, "deduction"], ["佣金", commission, "deduction"],
    ["运费", shipping, "deduction"], ["退款", summary.refundFen, "deduction"], ["推广", promotion, "deduction"],
    ["其他费用", other, "deduction"], ["预计利润", summary.knownProfitFen, "profit"],
  ];
}

function profitFlowValue(amount, kind) {
  if (kind === "income" || kind === "profit") return formatFen(amount);
  return amount < 0 ? `+ ${formatFen(Math.abs(amount))}` : `− ${formatFen(amount)}`;
}

function monthRangeLabel(summary) {
  const today = localToday();
  if (summary.start === `${today.slice(0, 7)}-01` && summary.end === today) return "本月";
  const end = new Date(`${today.slice(0, 7)}-01T12:00:00`);
  end.setDate(0);
  const lastDay = `${end.getFullYear()}-${String(end.getMonth() + 1).padStart(2, "0")}-${String(end.getDate()).padStart(2, "0")}`;
  if (summary.start === `${lastDay.slice(0, 7)}-01` && summary.end === lastDay) return "上月";
  return "本期";
}

function marginComparison(summary, previousSummary, periodLabel) {
  if (summary.profitMargin === null) return "利润率暂时无法计算";
  const margin = `${(summary.profitMargin * 100).toFixed(1)}%`;
  if (previousSummary.profitMargin === null) return `利润率 ${margin} · 上期数据不足，暂时无法比较`;
  const delta = (summary.profitMargin - previousSummary.profitMargin) * 100;
  const movement = Math.abs(delta).toFixed(1).replace(/\.0$/, "");
  const relation = delta > 0.05 ? `比${periodLabel === "本月" ? "上月同期" : "上期"}高 ${movement} 个百分点`
    : delta < -0.05 ? `比${periodLabel === "本月" ? "上月同期" : "上期"}低 ${movement} 个百分点` : "和上期接近";
  return `利润率 ${margin}，${relation}`;
}

function productAction(row, label = "查看商品") {
  return `<button class="button secondary small" data-action="focus-product" data-target="${esc(row.target || "records")}" data-store-id="${esc(row.storeId)}" data-sku-id="${esc(row.skuId)}" data-product-name="${esc(row.productName || row.skuId)}" data-start="${esc(row.effectiveFrom || "")}">${esc(label)}</button>`;
}

function demoNameAttr(row) { return state.data.stores.some((store) => store.demo && store.id === row.storeId) ? ' data-demo-name="true"' : ""; }

function lossRowsMarkup(rows) {
  return rows.map((row) => `<article class="loss-product-row">
    <div class="loss-product-name"><strong${demoNameAttr(row)} title="${esc(row.productName)}">${esc(row.productName || row.skuId)}</strong><small>${esc(row.skuId)} · 售出 ${esc(formatQuantity(row.quantityMilli))} 件</small></div>
    <strong class="loss-product-amount">− ${esc(formatFen(Math.abs(row.profitFen)))}</strong>
    <div class="loss-product-reason"><span>可能原因</span><strong>${esc(row.reason)}</strong></div>
    <div class="loss-product-advice"><span>${esc(row.suggestion)}</span>${productAction(row, row.action)}</div>
  </article>`).join("");
}

function uncertainCostMarkup(rows) {
  if (!rows.length) return "";
  return `<details class="uncertain-products-details"><summary>${rows.length} 件商品没填成本，利润暂时算不准</summary><div class="uncertain-product-list">${rows.map((row) => `<div class="uncertain-product-row"><span><strong${demoNameAttr(row)}>${esc(row.productName || row.skuId)}</strong><small>${esc(row.skuId)} · 售出 ${esc(formatQuantity(row.quantityMilli))} 件 · 没填成本，结果可能偏高</small></span>${productAction({ ...row, target: "costs", action: "补填成本" }, "补填成本")}</div>`).join("")}</div></details>`;
}

function thinRowsMarkup(rows) {
  if (!rows.length) return `<p class="empty-inline">目前没有达到薄利提醒线的商品。</p>`;
  return `<div class="thin-product-list">${rows.slice(0, 5).map((row) => `<div class="thin-product-row">
    <div><strong${demoNameAttr(row)}>${esc(row.productName || row.skuId)}</strong><small>${esc(row.skuId)} · 售出 ${esc(formatQuantity(row.quantityMilli))} 件</small></div>
    <span>${row.margin === null ? "—" : `${(row.margin * 100).toFixed(1)}%`} 利润率 · ${esc(formatFen(row.profitFen))} 利润</span>
    ${productAction(row, "查看商品")}
  </div>`).join("")}</div>`;
}

function overviewDateControls(summary) {
  return `<section class="overview-date-card" aria-label="选择查看时间">
    <div class="overview-date-label"><strong>查看哪段时间</strong><span>${esc(summary.start)} 至 ${esc(summary.end)}</span></div>
    <div class="overview-date-inputs"><label>开始<input id="overview-start" type="date" value="${esc(state.start)}"></label><label>结束<input id="overview-end" type="date" value="${esc(state.end)}"></label></div>
    <div class="date-quick-options" aria-label="快捷日期范围"><button type="button" data-period="7">近 7 天</button><button type="button" data-period="30">近 30 天</button><button type="button" data-period="month">本月</button><button type="button" data-period="previous-month">上月</button></div>
  </section>`;
}

function renderDashboard(data) {
  const summary = currentSummary(data);
  const insights = buildProfitInsights(data, summary, state.lowMarginThreshold);
  const trend = financialTrend(data, summary);
  const previousSummary = previousPeriodSummary(data, summary);
  const composition = feeComposition(data, summary);
  const dashboardIssues = uniqueVisibleIssues(data.issues.filter((issue) => (issue.status === "open" || issue.status === "review")
    && (state.selectedStoreId === "all" || issue.storeId === state.selectedStoreId)), data);
  if (!data.orders.some((order) => summary.storeIds.includes(order.storeId))) {
    return `<section class="card card-pad"><h1>先导入一份订单表，我帮你看看赚了多少。</h1><p>订单和进货价只保存在当前浏览器。</p><div class="button-row"><button class="button" data-nav="import">导入我的订单</button><button class="text-button" data-action="load-demo">先用示例体验</button></div></section>`;
  }
  const pendingOrderCount = data.orders.filter((order) => summary.storeIds.includes(order.storeId) && order.orderedAt >= summary.start && order.orderedAt <= summary.end && order.statusClass !== "valid" && isPendingOrderStatus(order.orderStatus)).length;
  const knownRecords = data.orders.length + data.refunds.length + data.platformFees.length + data.productCosts.length + data.otherExpenses.length + data.settlements.length;
  const recentBatches = [...data.importBatches].sort((a, b) => b.importedAt.localeCompare(a.importedAt)).slice(0, 5);
  const periodLabel = monthRangeLabel(summary);
  const hasPeriodActivity = summary.grossSalesFen || summary.refundFen || summary.costFen || summary.feeFen || summary.expenseFen;
  const conclusionTone = !hasPeriodActivity ? "neutral" : !summary.complete ? "thin" : summary.knownProfitFen < 0 ? "loss" : summary.knownProfitFen > 0 && summary.profitMargin !== null && summary.profitMargin >= state.lowMarginThreshold / 100 ? "profit" : "thin";
  const conclusionText = !hasPeriodActivity
    ? `${periodLabel}暂时没有可计入的销售金额`
    : !summary.complete
      ? summary.missingCosts.length ? `还差 ${summary.missingCosts.length} 个商品的进货价，暂时算不准` : `${periodLabel}暂时无法确认赚亏`
    : summary.knownProfitFen < 0
      ? `${periodLabel}预计亏了 ${formatFen(Math.abs(summary.knownProfitFen))}`
      : summary.knownProfitFen > 0
        ? `${periodLabel}预计赚了 ${formatFen(summary.knownProfitFen)}`
        : `${periodLabel}暂时打平`;
  const totalOutflowFen = summary.costFen + summary.feeFen + summary.expenseFen + summary.refundFen;
  const earlierOrders = new Set(data.orders.filter(order => summary.storeIds.includes(order.storeId) && order.orderedAt < summary.start).map(order => `${order.storeId}|${order.platformOrderId}`));
  const priorRefunds = data.refunds.filter(refund => refund.confirmed && summary.storeIds.includes(refund.storeId) && refund.completedAt >= summary.start && refund.completedAt <= summary.end && earlierOrders.has(`${refund.storeId}|${refund.platformOrderId}`));
  const smallDataWarning = summary.missingInputs.length ? `还缺：${summary.missingInputs.join("；")}。` : "";
  const conclusionCard = `<section class="profit-conclusion ${conclusionTone}" aria-labelledby="profit-conclusion-title">
    <div class="profit-conclusion-main"><span class="profit-conclusion-label">${esc(periodLabel)}经营结论</span><h2 id="profit-conclusion-title">${esc(conclusionText)}</h2>
      <p>${summary.complete ? esc(summary.profitMargin === null ? "净销售额不大于零，利润率暂时无法计算" : previousSummary.complete ? marginComparison(summary, previousSummary, periodLabel) : `利润率 ${(summary.profitMargin * 100).toFixed(1)}% · 上期数据不完整，暂不比较`) : `已知项目相减后${summary.knownProfitFen < 0 ? "相差" : "剩余"} ${esc(formatFen(summary.knownProfitFen))}，不代表最终利润。`}</p>
      <small>根据已导入的订单、退款和费用估算；平台到账不等于利润。</small>
      ${priorRefunds.length ? `<small>本期包含 ${priorRefunds.length} 笔以前订单的退款，退款会减少本期结果。</small>` : ""}
      ${smallDataWarning ? `<div class="profit-data-warning"><strong>资料不完整，暂不能确认赚亏</strong><span>${esc(smallDataWarning)}</span><button class="button secondary small" data-nav="${summary.missingCosts.length ? "costs" : "import"}">${summary.missingCosts.length ? "补填商品成本" : "补充费用表"}</button></div>` : ""}
    </div>
    <div class="profit-support-metrics"><div><span>商品销售额</span><strong>${esc(formatFen(summary.grossSalesFen))}</strong></div><div><span>已知支出（含退款）</span><strong>${esc(formatFen(totalOutflowFen))}</strong><small>已导入成本、费用及退款</small></div><div><span>已知项目利润率</span><strong>${summary.profitMargin === null ? "—" : `${(summary.profitMargin * 100).toFixed(1)}%`}</strong></div></div>
    <details class="profit-explanation"><summary>这些数字怎么算？</summary><p>净销售额 = 商品销售额 − 已确认退款；已知项目利润 = 净销售额 − 已匹配成本 − 已导入费用；利润率 = 已知项目利润 ÷ 净销售额。退款按完成日、订单按下单日计入；缺项会影响结果。</p></details>
  </section>`;
  const lossHeading = insights.lossCount
    ? `${insights.lossCount} 件商品按已匹配项目预计亏损 ${formatFen(insights.totalLossFen)}`
    : insights.uncertainProducts.length || insights.unallocated.count ? "目前还不能确认所有商品的盈亏" : "已核对商品暂未发现亏损";
  const lossMarkup = insights.lossCount
    ? `${lossRowsMarkup(insights.lossProducts.slice(0, 3))}${insights.lossCount > 3 ? `<details class="more-loss-products"><summary>再看其余 ${insights.lossCount - 3} 件亏损商品</summary>${lossRowsMarkup(insights.lossProducts.slice(3))}</details>` : ""}`
    : `<p class="no-loss-copy">已匹配成本和费用的商品暂未发现亏损。${insights.uncertainProducts.length ? `另有 ${insights.uncertainProducts.length} 件商品没填成本，无法判断。` : ""}</p>`;
  const unallocatedNote = insights.unallocated.count ? `<p class="allocation-warning">另有 ${insights.unallocated.count} 条退款或费用（合计 ${esc(formatFen(insights.unallocatedFen))}）无法明确对应本期单个商品，未分摊到商品；店铺利润已计入这些款项。</p>` : "";
  const lossCard = `<section class="loss-products-card" aria-labelledby="loss-products-title"><div class="loss-products-heading"><div><span class="section-eyebrow">先处理可能亏钱的商品</span><h2 id="loss-products-title">${esc(lossHeading)}</h2><p>按已匹配商品的成本、退款和费用估算；缺失或无法归属的费用可能改变结论。</p></div><span class="loss-total-pill">已匹配项目预计亏损 ${esc(formatFen(insights.totalLossFen))}</span></div><div class="loss-products-list">${lossMarkup}</div>${unallocatedNote}${uncertainCostMarkup(insights.uncertainProducts)}</section>`;
  const thinCard = `<details class="thin-products-card card card-pad"><summary>薄利商品：${insights.thinProducts.length} 件</summary><div class="thin-products-heading"><div><p>卖得多但赚得少的商品会列在这里。</p></div><label class="threshold-control" title="低于此利润率的商品会列为薄利，默认 10%">提醒线 <input type="number" min="0" max="50" step="1" value="${state.lowMarginThreshold}" data-low-margin-threshold aria-label="薄利提醒利润率百分比"> %</label></div>${thinRowsMarkup(insights.thinProducts)}</details>`;
  const pendingReason = pendingOrderCount ? ` 另有 ${pendingOrderCount} 个待付款订单还没成交，因此没有计入销售。` : "";
  const nextAction = !data.orders.length
    ? `<span>还没有订单，先导入订单表开始查看。</span><button class="button small" data-nav="import">开始导入</button>`
    : summary.missingCosts.length
      ? `<span>${summary.missingCosts.length} 个商品未填成本，利润可能偏高。${pendingReason}</span><button class="button secondary small" data-nav="costs">补上成本</button>`
      : dashboardIssues.length
        ? `<span>还有 ${dashboardIssues.length} 个问题需要处理。</span><button class="button secondary small" data-nav="issues">处理问题</button>`
      : !summary.complete
        ? `<span>目前结果按已导入的订单估算；补充费用表可让利润更完整。${pendingReason}</span><button class="button secondary small" data-nav="import">补充数据</button>`
        : `<span>已按当前记录估算。${pendingReason}</span><button class="button secondary small" data-action="export-xlsx">下载经营报告</button>`;
  const overviewReady = summary.complete && data.orders.length > 0;
  const summaryCard = `<div class="overview-status ${overviewReady ? "is-ready" : "is-incomplete"}" role="status"><span class="completeness-icon" aria-hidden="true">${overviewReady ? "✓" : "i"}</span><strong>${overviewReady ? "已匹配当前记录" : "经营数据提示"}</strong><span class="overview-status-copy">${nextAction}</span></div>`;
  const dashboardIssueCard = `<details class="dashboard-issues" aria-labelledby="dashboard-issues-title">
    <summary class="dashboard-issues-summary"><span class="issue-summary-title" id="dashboard-issues-title">需要处理</span><span class="issue-summary-count">${dashboardIssues.length ? `${dashboardIssues.length} 项` : "目前没有待处理问题"}</span><span class="issue-summary-action">${dashboardIssues.length ? "展开查看" : "查看已处理记录"}</span></summary>
    <div class="dashboard-issue-list">${dashboardIssues.slice(0, 6).map((issue) => dashboardIssueMarkup(issue, data)).join("") || `<p class="empty-inline">目前没有需要处理的问题。</p>`}</div>
    ${dashboardIssues.length > 6 ? `<p class="dashboard-issues-more">这里显示 6 条，共 ${dashboardIssues.length} 条；点“查看全部”可继续检查。</p>` : ""}
  </details>`;
  const hasAnyData = knownRecords > 0;
  const discoveryLabel = `${periodLabel}已匹配项目预计亏损 ${formatFen(insights.totalLossFen)}`;
  const backupState = backupStatus(data);
  const html = `<div class="overview-toolbar"><h1 class="visually-hidden">经营总览</h1><span>统计范围：${esc(summary.start)} 至 ${esc(summary.end)} · ${esc(selectedStoreName(data))}</span><div class="overview-toolbar-actions"><span class="discovery-badge">本助手${esc(discoveryLabel)}</span><button class="button secondary small" data-action="export-xlsx">下载 Excel 报告</button>${hasAnyData ? "" : `<button class="button small" data-nav="import">导入表格</button>`}</div></div>
    ${conclusionCard}
    ${lossCard}
    ${overviewDateControls(summary)}
    ${thinCard}
    ${summaryCard}
    ${dashboardIssueCard}
    <aside class="dashboard-backup-reminder"><div><strong>记得留一份本机数据备份</strong><span id="dashboard-backup-status">${esc(backupState.text)}</span></div><div class="button-row"><button class="button secondary small" data-action="download-backup">下载备份</button><button class="button ghost small" data-nav="settings">管理备份</button></div></aside>
    <details class="analysis-details card card-pad"><summary><span>看看钱怎么算出来的</span><small>趋势、利润构成和利润较高商品</small></summary>
      <section class="dashboard-grid">
        <article class="card chart-card"><div class="section-title"><div><div class="section-eyebrow">每日趋势</div><h2>销售额和利润变化</h2><p>销售按下单日统计；退款、扣费和支出按各自日期计入。</p></div><span class="tag tag-blue">${trend.length} 天</span></div>
          <div class="chart-legend"><span><i class="legend-sales"></i>销售额</span><span><i class="legend-profit"></i>预计利润</span></div>
          <div class="period-comparison"><span>和上期比较（${esc(previousSummary.start)} 至 ${esc(previousSummary.end)}）</span>${periodDelta(summary.grossSalesFen, previousSummary.grossSalesFen, "销售额")}${periodDelta(summary.knownProfitFen, previousSummary.knownProfitFen, "利润")}</div>${trendSvg(trend)}</article>
        <article class="card chart-card composition-card"><div class="section-title"><div><div class="section-eyebrow">利润怎么算</div><h2>收入扣掉哪些费用</h2><p>按已导入项目归类；未识别的费用放在“其他费用”。</p></div></div>
          <div class="profit-flow">${composition.map(([label, amount, kind], index) => `<div class="profit-flow-step ${kind}"><span>${esc(label)}</span><strong>${esc(profitFlowValue(amount, kind))}</strong></div>${index < composition.length - 1 ? `<span class="profit-flow-arrow" aria-hidden="true">→</span>` : ""}`).join("")}</div>
        </article>
      </section>
      <section class="card card-pad product-rankings"><div class="section-title"><div><div class="section-eyebrow">表现较好的商品</div><h2>利润较高的商品</h2></div></div><ol class="ranked-product-list">${insights.products.filter((row) => !row.missingCost && row.profitFen >= 0).sort((a, b) => b.profitFen - a.profitFen).slice(0, 5).map((row) => `<li><span class="rank-product-copy"><strong>${esc(row.productName || row.skuId)}</strong><small>${esc(row.skuId)} · 售出 ${esc(formatQuantity(row.quantityMilli))} 件</small></span><span class="rank-product-value">${esc(formatFen(row.profitFen))}</span></li>`).join("") || `<li>目前没有可列出的商品。</li>`}</ol></section>
    </details>
    <section class="card card-pad recent-imports"><div class="section-title"><div><div class="section-eyebrow">最近导入</div><h2>导入的表格</h2><p>已导入 ${data.importBatches.length} 次 · 保存了 ${knownRecords.toLocaleString(state.language)}</p></div><button class="button ghost small" data-nav="import">继续导入 →</button></div>
      ${recentBatches.length ? `<div class="recent-batch-list">${recentBatches.map((batch) => { const errors = data.rawRecords.filter((row) => row.batchId === batch.id && (row.decision === "rejected" || row.decision === "conflict")); return `<details class="recent-batch"><summary><strong>${esc(REPORTS[batch.reportType]?.label || batch.reportType)}</strong><span>${esc(batch.originalFilename)} · 新增 ${batch.acceptedCount} 条 · ${esc(new Date(batch.importedAt).toLocaleString(state.language, { dateStyle: "short", timeStyle: "short" }))}</span></summary><p>跳过重复 ${batch.duplicateCount || 0} 条；待检查 ${(batch.rejectedCount || 0) + (batch.conflictCount || 0)} 条。批次信息仅保存在当前浏览器。</p>${errors.slice(0, 5).map((row) => `<p>第 ${row.rowNumber} 行：${esc(row.validationMessage || "与已有记录内容不同，请核对")}</p>`).join("")}${batch.demo ? "<p>虚构演示数据不支持按批次撤销。</p>" : `<button class="button secondary small" data-action="undo-batch" data-batch-id="${esc(batch.id)}">撤销此次导入</button>`}</details>`; }).join("")}</div>` : `<div class="empty-inline">还没有导入表格。</div>`}</section>`;
  saveCalculation(data, summary).catch((error) => presentError(error, "保存计算结果失败"));
  return html;
}

async function saveCalculation(data, summary) {
  const currentStore = state.selectedStoreId;
  const id = periodKey(currentStore, summary.start, summary.end);
  const record = { id, storeId: currentStore, start: summary.start, end: summary.end, ruleVersion: CALCULATION_RULE_VERSION,
    calculatedAt: new Date().toISOString(), inputSnapshot: { stores: data.stores.length, orders: data.orders.length, items: data.orderItems.length,
      refunds: data.refunds.length, fees: data.platformFees.length, costs: data.productCosts.length, expenses: data.otherExpenses.length },
    outputSummary: summary, warnings: summary.missingInputs };
  await putOne(state.db, "calculationResults", record);
}

function renderStores(data) {
  const platforms = ["淘宝/天猫", "拼多多", "抖音电商", "闲鱼", "Amazon", "eBay", "Etsy", "Shopify", "Walmart Marketplace", "AliExpress", "Shopee", "Lazada", "TikTok Shop", "其他/演示"];
  const content = data.stores.length ? `<div class="grid grid-2">${data.stores.map((store) => `<article class="card card-pad store-card"><div class="store-card-top"><span class="store-platform">${esc(store.platform)} · ${esc(store.currency || 'CNY')}</span><span class="tag ${store.demo ? "tag-warn" : "tag-ok"}">${store.demo ? "演示数据" : "我的店铺"}</span></div><h2 ${store.demo ? 'data-demo-name="true"' : ""}>${esc(store.name)}</h2><p>创建于 ${esc(String(store.createdAt || "").slice(0, 10))}</p><button class="button secondary small" data-action="select-store" data-store-id="${esc(store.id)}">查看数据</button></article>`).join("")}</div>` : emptyState("还没有添加店铺", "添加后，导入的订单和费用就会归到这个店铺。这里只记录名称，不会连接你的平台账号。", "");
  return `${pageHeading("我的店铺", "先添加店铺，再导入表格。", "店铺名称只用来分开整理数据，不需要登录或绑定平台账号。")}
    <section class="grid grid-2"><article class="card card-pad"><div class="section-title"><div><h2>添加一个店铺</h2><p>例如你在淘宝、拼多多或抖音经营的店铺。</p></div></div>
      <p class="form-note">各平台报表尚未使用真实脱敏样本验证，选平台仅用于分类，不会连接账号。每个店铺只使用一种币种，不自动换汇；导入金额、成本和费用须均为该币种。</p><form data-form="add-store" class="form-grid"><div class="field"><label for="store-platform">在哪个平台卖</label><select id="store-platform" name="platform" required>${platforms.map((p) => `<option value="${esc(p)}">${esc(p)}</option>`).join("")}</select></div><div class="field"><label for="store-name">店铺叫什么</label><input id="store-name" name="name" maxlength="80" placeholder="例如：晴日数码小店" required></div><div class="field"><label for="store-currency">金额单位</label><select id="store-currency" name="currency">${Object.entries(CURRENCIES).map(([code, label]) => `<option value="${code}">${label}</option>`).join('')}</select></div><div class="field full"><button class="button" type="submit">保存店铺</button></div></form>
      <p class="form-note">数据只保存在当前浏览器。换浏览器或换设备后，需要重新导入或恢复备份。</p></article><article class="card card-pad"><div class="section-title"><div><h2>我的店铺</h2><p>已添加 ${data.stores.length} 个店铺</p></div></div>${content}</article></section>`;
}

function renderImport(data) {
  const stores = data.stores;
  if (!stores.length) return `${pageHeading("导入表格", "先给店铺起个名字。", "选择金额单位后，就可以选择订单表。数据只保存在当前浏览器。")}
    <section class="card card-pad"><h2>第 1 步：准备导入</h2><form data-form="add-store" class="form-grid">
      <div class="field"><label for="store-name">店铺叫什么</label><input id="store-name" name="name" maxlength="80" required></div>
      <div class="field"><label for="store-currency">表格里的金额单位</label><select id="store-currency" name="currency" required><option value="">请选择币种</option>${Object.entries(CURRENCIES).map(([code, label]) => `<option value="${code}">${label}</option>`).join("")}</select></div>
      <div class="field"><label for="store-platform">销售平台</label><select id="store-platform" name="platform"><option value="其他/演示">其他/演示</option>${["淘宝/天猫", "拼多多", "抖音电商", "闲鱼", "Amazon", "eBay", "Etsy", "Shopify", "Walmart Marketplace", "AliExpress", "Shopee", "Lazada", "TikTok Shop"].map((platform) => `<option value="${esc(platform)}">${esc(platform)}</option>`).join("")}</select></div>
      <div class="field full"><button class="button" type="submit">保存并选择表格</button></div></form></section>`;
  const importStoreId = state.importStoreId && stores.some((row) => row.id === state.importStoreId) ? state.importStoreId : state.selectedStoreId !== "all" ? state.selectedStoreId : stores[0].id;
  state.importStoreId = importStoreId;
  const pending = state.pendingFile;
  const reportType = pending?.reportType || state.importReportType;
  const mapping = state.importMapping || (pending ? suggestMapping(reportType, pending.headers) : {});
  const options = Object.entries(REPORTS).map(([key, report]) => `<option value="${key}" ${reportType === key ? "selected" : ""}>${esc(report.label)}</option>`).join("");
  const reportFields = REPORTS[reportType].fields;
  const alternativeKeys = reportType === "orders" ? new Set(["itemAmount", "unitPrice"]) : new Set();
  const fieldRow = (field) => {
    const marker = field.required ? "required" : alternativeKeys.has(field.key) ? "alternative" : "";
    return `<div class="map-row"><label class="${marker}" for="map-${esc(field.key)}">${esc(field.label)}</label><select id="map-${esc(field.key)}" data-map-field="${esc(field.key)}"><option value="">不选择这一列</option>${pending.headers.map((header) => `<option value="${esc(header)}" ${mapping[field.key] === header ? "selected" : ""}>${esc(header)}</option>`).join("")}</select></div>`;
  };
  const keyFields = reportFields.filter((field) => field.required || alternativeKeys.has(field.key));
  const optionalFields = reportFields.filter((field) => !field.required && !alternativeKeys.has(field.key));
  const fields = pending ? `${keyFields.map(fieldRow).join("")}${optionalFields.length ? `<details class="optional-mapping"><summary>其他信息（可以不填）</summary><div class="mapping-grid">${optionalFields.map(fieldRow).join("")}</div></details>` : ""}` : "";
  let planBox = "";
  if (state.importPlan) {
    const p = state.importPlan;
    const duplicateFile = p.duplicateFile;
    planBox = `<p class="preflight-good">识别到 ${pending.rows.length} 行，预计可导入 ${p.accepted.length} 行，${p.duplicates.length} 行重复，${p.rejected.length + p.conflicts.length} 行需要检查。</p><div class="summary-strip">
      <div class="summary-chip"><span>可以保存</span><strong>${p.accepted.length} 条</strong></div>
      <div class="summary-chip warn"><span>有问题</span><strong>${p.rejected.length} 条</strong></div>
      <div class="summary-chip"><span>重复跳过</span><strong>${p.duplicates.length} 条</strong></div>
      <div class="summary-chip warn"><span>内容不一致</span><strong>${p.conflicts.length} 条</strong></div>
    </div>${duplicateFile ? `<div class="preflight-error">这份表格已在 ${esc(p.batchAlreadyImported.importedAt)} 导入过了，为避免重复计算，本次不能再次导入。</div>` : p.accepted.length ? `<div class="preflight-good">表格检查完成。确认后会保存到当前浏览器；上传的原文件不会保留。</div>` : `<div class="preflight-error">没有可以保存的新记录。请按下面的提示检查表格内容。</div>`}
    ${["refunds", "fees", "expenses"].includes(reportType) && !p.rejected.length && !p.conflicts.length && p.accepted.length ? `<div class="warning-note"><label><input type="checkbox" id="confirm-report-coverage"> 我确认这份表包含所选日期范围内的全部${esc(REPORTS[reportType].label)}记录（${esc(state.start)} 至 ${esc(state.end)}）。</label><p>仅在已核对整段时间且没有遗漏时勾选；表格中的记录日期本身不能证明数据完整。</p></div>` : ""}
    ${p.rejected.slice(0, 5).map((row) => `<div class="preflight-error">第 ${row.rowNumber} 行：${esc(row.message)}</div>`).join("")}
    ${p.conflicts.slice(0, 5).map((row) => `<div class="preflight-error">第 ${row.rowNumber} 行：这个订单号已有不同内容，旧记录没有被改动。</div>`).join("")}
    ${p.rejected.length || p.conflicts.length ? `<button class="button secondary small" data-action="download-import-errors">下载待检查行</button>` : ""}
    <div class="button-row" style="margin-top:14px"><button class="button" data-action="commit-import" ${duplicateFile || !p.accepted.length ? "disabled" : ""}>确认导入 ${p.accepted.length} 行</button><button class="button secondary" data-action="clear-import">取消</button></div>`;
  }
  const preview = pending ? `<div class="file-meta"><strong>${esc(pending.fileName)}</strong><span>当前按${esc(REPORTS[reportType].label)}读取 · ${esc(bytesLabel(pending.size))} · ${esc(pending.sheetName)} · ${pending.rows.length} 行</span></div><div class="section-title"><div><h3><span class="step-number">3</span>检查表格内容</h3><p>左边是我们要读取的信息，右边选择你表格中对应的列。系统会先帮你选择，请检查是否正确；“其他信息”可以不填。</p></div></div><div class="mapping-grid">${fields}</div>
    ${reportType === "orders" ? `<div class="warning-note" style="margin-top:12px">取消的订单不会算作销售。系统看不懂的订单状态会列出来让你检查，不会自行猜金额。</div>` : ""}
    <details class="optional-mapping"><summary>日期格式（需要时选择）</summary><label for="import-date-order">如果日期中日和月都不超过 12，请确认顺序</label><select id="import-date-order"><option value="">尚未确认</option><option value="DMY" ${state.dateOrder === 'DMY' ? 'selected' : ''}>日 / 月 / 年（例如 05/03/2026 是 3 月 5 日）</option><option value="MDY" ${state.dateOrder === 'MDY' ? 'selected' : ''}>月 / 日 / 年（例如 05/03/2026 是 5 月 3 日）</option></select></details>
    <div class="button-row" style="margin-top:15px"><button class="button blue" data-action="validate-import">检查这份表格</button></div>
    ${planBox || ""}<div class="mapping-preview"><table><thead><tr>${pending.headers.map((header) => `<th>${esc(header)}</th>`).join("")}</tr></thead><tbody>${pending.rows.slice(0, 8).map((row) => `<tr>${pending.headers.map((_, i) => `<td>${esc(row[i])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : "";
  return `${pageHeading("导入表格", "把平台导出的表格放进来。", "按步骤选择表格、检查内容，确认后保存。你的文件只在当前浏览器里处理。")}
    <div class="import-progress" aria-label="导入进度"><span class="active">1 选店铺</span><span class="active">2 选表格</span><span class="${pending ? "active" : ""}">3 检查内容</span><span class="${state.importPlan ? "active" : ""}">4 确认保存</span></div>
    <div class="platform-note">所有平台的真实报表格式尚未验证，请检查列映射。金额必须与店铺币种一致，不自动换汇；小数请用点号，避免逗号造成误读。数量也用点号且不要加千位分隔符。日期请使用 YYYY-MM-DD；含糊的日/月日期会要求你先改清楚。Excel 仅读取第一个工作表。 <button class="text-button" data-action="download-template">下载当前类型的空白表头</button></div>
    <section class="card card-pad"><div class="section-title"><div><h2><span class="step-number">1</span>选择店铺和表格</h2><p>支持 Excel 或 CSV 文件，单个文件最大 20 MB、最多 50,000 行。</p></div><span class="tag tag-ok">只在本机处理</span></div>
      <div class="form-grid"><div class="field"><label for="import-store">保存到哪个店铺</label><select id="import-store" data-import-store>${stores.map((store) => `<option value="${esc(store.id)}" ${store.demo ? 'data-demo-name="true"' : ""} ${store.id === importStoreId ? "selected" : ""}>${esc(store.name)} · ${esc(store.platform)}</option>`).join("")}</select></div><div class="field"><label for="import-kind">这是什么表格</label><select id="import-kind" data-import-kind>${options}</select></div><div class="field"><label for="csv-encoding">CSV 文件文字编码</label><select id="csv-encoding" data-csv-encoding><option value="auto" ${state.csvEncoding === 'auto' ? 'selected' : ''}>自动（UTF-8 / 自动识别）</option><option value="utf-8" ${state.csvEncoding === 'utf-8' ? 'selected' : ''}>UTF-8</option><option value="windows-1252" ${state.csvEncoding === 'windows-1252' ? 'selected' : ''}>西欧 Windows-1252</option><option value="windows-1251" ${state.csvEncoding === 'windows-1251' ? 'selected' : ''}>俄语 Windows-1251</option><option value="windows-1256" ${state.csvEncoding === 'windows-1256' ? 'selected' : ''}>阿拉伯语 Windows-1256</option><option value="gb18030" ${state.csvEncoding === 'gb18030' ? 'selected' : ''}>简体中文 GB18030</option></select></div><div class="field full"><label class="dropzone" for="import-file"><span class="drop-icon">⇧</span><strong>${pending ? "换一份表格" : "选择平台导出的表格"}</strong><span>选择 CSV 或 Excel 文件。文件不会上传；只有你确认后，识别出的记录才会保存在当前浏览器。</span></label><input id="import-file" type="file" accept=".csv,.tsv,.txt,.xls,.xlsx,.xlsm" hidden></div></div>
      ${preview}</section>
    <details class="card card-pad disclosure" style="margin-top:16px"><summary>没有商品编号或导入遇到问题？</summary><ul class="rule-list"><li>商品编号是用来匹配订单与进货价的标识；如果表中没有，请在订单表和成本表里为同一商品填写一致的编号。</li><li>同一份表格不会重复计算；相同记录会跳过，内容不一致时会提示检查。</li><li>可下载空白表头和待检查行，在本机修改后重新导入。</li><li>支持 .csv、.tsv、.xls、.xlsx、.xlsm；Excel 仅读取第一个工作表，每个文件最大 20 MB。</li><li>原始文件不会上传到网站；确认后的记录保存在当前浏览器。</li></ul></details>`;
}

function renderRecords(data) {
  const type = state.recordType;
  const categories = {
    orders: ["orders", "订单"], orderItems: ["orderItems", "商品明细"], refunds: ["refunds", "退款"],
    platformFees: ["platformFees", "平台扣费"], otherExpenses: ["otherExpenses", "其他支出"], settlements: ["settlements", "到账记录"],
  };
  const [storeNameKey, title] = categories[type] || categories.orders;
  const focusedProduct = type === "orderItems" ? state.focusProduct : null;
  const dateKey = { orders: "orderedAt", orderItems: "orderedAt", refunds: "completedAt", platformFees: "feeDate", otherExpenses: "expenseDate", settlements: "settlementDate" }[type];
  const query = state.recordQuery.trim().toLocaleLowerCase();
  const matchingRows = data[storeNameKey].filter((row) => (state.selectedStoreId === "all" || row.storeId === state.selectedStoreId)
    && (!focusedProduct || (row.skuId === focusedProduct.skuId && row.storeId === focusedProduct.storeId))
    && (!state.recordUsePeriod || (row[dateKey] >= state.start && row[dateKey] <= state.end))
    && (type !== "orders" || state.recordStatus === "all" || (state.recordStatus === "pending" ? row.statusClass !== "valid" && isPendingOrderStatus(row.orderStatus) : state.recordStatus === "unknown" ? row.statusClass === "unknown" && !isPendingOrderStatus(row.orderStatus) : row.statusClass === state.recordStatus))
    && (!query || [row.platformOrderId, row.skuId, row.productName, row.platformRefundId, row.feeId, row.expenseId, row.transactionId].some((v) => String(v || "").toLocaleLowerCase().includes(query))))
    .sort((a, b) => String(b[dateKey] || "").localeCompare(String(a[dateKey] || "")) || String(b.id).localeCompare(String(a.id)));
  const pageSize = 50;
  const pageCount = Math.max(1, Math.ceil(matchingRows.length / pageSize));
  state.recordPage = Math.min(state.recordPage, pageCount - 1);
  const rows = matchingRows.slice(state.recordPage * pageSize, (state.recordPage + 1) * pageSize);
  const columns = {
    orders: [["platformOrderId", "订单号"], ["orderedAt", "下单日期"], ["orderStatus", "平台订单状态"], ["statusClass", "系统判断"]],
    orderItems: [["platformOrderId", "订单号"], ["skuId", "商品编号"], ["productName", "商品名称"], ["quantityMilli", "数量", "quantity"], ["amountFen", "实付金额", "money"], ["orderedAt", "下单日期"]],
    refunds: [["platformRefundId", "退款单号"], ["platformOrderId", "订单号"], ["refundStatus", "状态"], ["amountFen", "退款金额", "money"], ["completedAt", "退款日期"], ["confirmed", "已确认"]],
    platformFees: [["feeId", "费用编号"], ["platformOrderId", "订单号"], ["feeType", "费用类型"], ["amountFen", "费用金额", "money"], ["feeDate", "费用日期"]],
    otherExpenses: [["expenseId", "费用编号"], ["expenseType", "费用类型"], ["amountFen", "金额", "money"], ["expenseDate", "费用日期"], ["allocationMethod", "费用怎么分配"]],
    settlements: [["transactionId", "到账流水"], ["platformOrderId", "订单号"], ["settlementStatus", "到账状态"], ["amountFen", "实际到账", "money"], ["settlementDate", "到账日期"]],
  }[type];
  const focusHeading = focusedProduct ? `查看“${esc(focusedProduct.productName)}”的订单` : "导入过的内容都在这里。";
  const focusDescription = focusedProduct ? `已按商品编号 ${esc(focusedProduct.skuId)} 筛出相关商品明细。` : "按日期从近到远排列；可搜索订单号或商品编号。";
  return `${pageHeading("我的数据", focusHeading, focusDescription, `${focusedProduct ? `<button class="button ghost small" data-action="clear-product-focus">查看全部</button>` : ""}<button class="button secondary" data-action="export-xlsx">下载 Excel 报告</button>`)}
    <section class="card card-pad"><div class="section-title"><div><h2>${title}</h2><p>共 ${matchingRows.length.toLocaleString(state.language)} 条记录 · 第 ${state.recordPage + 1} / ${pageCount} 页</p></div><select data-record-type aria-label="切换经营记录类型">${Object.entries(categories).map(([key, value]) => `<option value="${key}" ${key === type ? "selected" : ""}>${value[1]}</option>`).join("")}</select></div>
      <form data-form="record-search" class="record-search"><input name="query" value="${esc(state.recordQuery)}" placeholder="搜索订单号、商品名或编号" aria-label="搜索记录">${type === "orders" ? `<select name="status" aria-label="按订单状态筛选">${[["all", "全部状态"], ["valid", "计入销售"], ["cancelled", "已取消"], ["pending", "待付款"], ["unknown", "无法识别"], ["ignored", "已忽略"]].map(([value, label]) => `<option value="${value}" ${state.recordStatus === value ? "selected" : ""}>${label}</option>`).join("")}</select>` : ""}<label class="record-date-filter"><input type="checkbox" name="usePeriod" ${state.recordUsePeriod ? "checked" : ""}> 按当前日期范围</label><button class="button secondary small" type="submit">筛选</button></form>
      ${rows.length ? `<div class="table-wrap"><table><thead><tr><th>店铺</th>${columns.map(([, label]) => `<th>${esc(label)}</th>`).join("")}</tr></thead><tbody>${rows.map((row, index) => `<tr ${focusedProduct && index === 0 ? 'id="focused-product-record"' : ""}><td>${esc(storeName(data, row.storeId))}</td>${columns.map(([key, , kind]) => `<td ${key === "statusClass" || typeof row[key] === "boolean" ? 'data-i18n-system="true"' : ""}>${esc(kind === "money" ? formatFen(row[key]) : kind === "quantity" ? `${formatQuantity(row[key])} 件` : typeof row[key] === "boolean" ? (row[key] ? "是" : "否") : key === "statusClass" ? ({ valid: "计入销售", cancelled: "已取消", ignored: "已忽略，不计入销售", unknown: isPendingOrderStatus(row.orderStatus) ? "待付款，不计入销售" : "状态无法识别" }[row[key]] || row[key]) : row[key])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : `<div class="empty-inline">${focusedProduct ? "没有找到这件商品的订单明细。" : "没有找到符合条件的记录。"}</div>`}
      <div class="record-pagination"><button class="button secondary small" data-action="records-page" data-page="${state.recordPage - 1}" ${state.recordPage === 0 ? "disabled" : ""}>上一页</button><span>第 ${state.recordPage + 1} / ${pageCount} 页</span><button class="button secondary small" data-action="records-page" data-page="${state.recordPage + 1}" ${state.recordPage + 1 >= pageCount ? "disabled" : ""}>下一页</button></div></section>`;
}

function renderCosts(data) {
  const rows = data.productCosts.filter((row) => state.selectedStoreId === "all" || row.storeId === state.selectedStoreId).sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom));
  const focusedProduct = state.focusProduct?.target === "costs" ? state.focusProduct : null;
  const editing = data.productCosts.find((row) => row.id === state.editCostId);
  const orders = new Map(data.orders.filter((o) => o.statusClass === "valid" && o.orderedAt >= state.start && o.orderedAt <= state.end).map((o) => [o.id, o]));
  const missing = new Map();
  for (const item of data.orderItems) {
    const order = orders.get(item.orderId);
    if (!order || (state.selectedStoreId !== "all" && item.storeId !== state.selectedStoreId) || findCost(data.productCosts, item.storeId, item.skuId, order.orderedAt)) continue;
    const key = `${item.storeId}|${item.skuId}`;
    const current = missing.get(key);
    if (!current || order.orderedAt < current.effectiveFrom) missing.set(key, { storeId: item.storeId, skuId: item.skuId, productName: item.productName || item.skuId, effectiveFrom: order.orderedAt, target: "costs" });
  }
  const missingList = [...missing.values()];
  const selectedStore = editing?.storeId || focusedProduct?.storeId || (state.selectedStoreId === "all" ? data.stores[0]?.id : state.selectedStoreId);
  const startDate = editing?.effectiveFrom || focusedProduct?.effectiveFrom || localToday();
  const focusNote = focusedProduct ? `<div class="cost-focus-note" id="product-focus-note"><strong>已定位到：${esc(focusedProduct.productName)}</strong><span>默认从最早未匹配的订单日期开始，请确认当时的实际进货价和生效日期。</span></div>` : "";
  const missingSection = `<section class="card card-pad missing-cost-list"><div class="section-title"><div><h2>待补商品 · ${missingList.length} 件</h2><p>请填写订单发生时每件商品的进货价。</p></div></div>${missingList.length ? `<form data-form="bulk-cost">${missingList.map((row, index) => `<div class="missing-cost-row"><span><strong>${esc(row.productName)}</strong><small>${esc(storeName(data, row.storeId))} · ${esc(row.skuId)} · ${esc(row.effectiveFrom)} 起</small></span><label>每件进货价 (${esc(data.stores.find(store => store.id === row.storeId)?.currency || "CNY")}) <input type="text" inputmode="decimal" data-bulk-cost="${index}" aria-label="${esc(row.productName)}每件进货价" ${index === 0 ? "autofocus" : ""}></label></div>`).join("")}<button class="button" type="submit">保存并看结果</button> <button class="text-button" type="button" data-nav="overview">暂时跳过</button></form>` : `<p class="empty-inline">当前日期范围没有发现缺少进货价的已成交商品。</p>`}</section>`;
  state.missingCostRows = missingList;
  return `${pageHeading("商品成本", "补上进货价，利润会更接近实际。", "商品成本按订单日期匹配；请确认价格生效日期。", `<button class="button secondary" data-nav="import" data-import-report="costs">导入成本表</button>`)}
    ${missingSection}
    <section class="grid grid-2" style="margin-top:16px"><article class="card card-pad">${focusNote}<div class="section-title"><div><h2>${editing ? "修改这条商品成本" : "手动添加一个商品成本"}</h2><p>同一商品可以按日期更新进货价，之前的价格会保留。</p></div></div>
      ${data.stores.length ? `<form data-form="add-cost" class="form-grid"><div class="field"><label for="cost-store">属于哪个店铺</label><select id="cost-store" name="storeId" required>${data.stores.map((store) => `<option value="${esc(store.id)}" ${store.demo ? 'data-demo-name="true"' : ""} ${store.id === selectedStore ? "selected" : ""}>${esc(store.name)}</option>`).join("")}</select></div><div class="field"><label for="cost-sku">商品编号</label><input id="cost-sku" name="skuId" maxlength="100" value="${esc(editing?.skuId || focusedProduct?.skuId || "")}" placeholder="照着订单表里的商品编号填写" required></div><div class="field"><label for="cost-product">商品名称</label><input id="cost-product" name="productName" maxlength="150" value="${esc(editing?.productName || focusedProduct?.productName || "")}" placeholder="可以不填"></div><div class="field"><label for="cost-value">每件进货价（店铺币种）</label><input id="cost-value" name="unitCost" inputmode="decimal" value="${editing ? (editing.unitCostFen / 100).toFixed(2) : ""}" placeholder="例如 12.50" required></div><div class="field"><label for="cost-from">从哪天开始使用这个价格</label><input id="cost-from" name="effectiveFrom" type="date" value="${esc(startDate)}" required></div><div class="field"><label for="cost-to">哪天停止使用（可以不填）</label><input id="cost-to" name="effectiveTo" type="date" value="${esc(editing?.effectiveTo || "")}"></div><div class="field full"><button class="button" type="submit">${editing ? "保存修改" : "保存这个进货价"}</button>${editing ? `<button class="button secondary" type="button" data-action="cancel-cost-edit">取消修改</button>` : ""}</div></form>` : `<div class="empty-inline">请先添加一个店铺。</div>`}</article>
      <article class="card card-pad"><div class="section-title"><div><h2>成本怎么算进利润</h2><p>系统按订单日期和商品编号匹配价格。</p></div></div><div class="formula"><strong>商品成本</strong> = 每件进货价 × 售出数量</div><p class="help-text" style="margin-top:12px">修改历史价格可能影响过去订单的利润。请先核实日期和进货价。</p></article></section>
    <section class="card card-pad" style="margin-top:16px"><div class="section-title"><div><h2>已添加的商品进货价</h2><p>共 ${rows.length} 条</p></div></div>${rows.length ? `<div class="table-wrap"><table><thead><tr><th>店铺</th><th>商品编号</th><th>商品</th><th>每件进货价</th><th>开始日期</th><th>截止日期</th><th>操作</th></tr></thead><tbody>${rows.map((row) => `<tr ${focusedProduct?.skuId === row.skuId && focusedProduct?.storeId === row.storeId ? 'id="focused-product-cost"' : ""}><td>${esc(storeName(data, row.storeId))}</td><td>${esc(row.skuId)}</td><td>${esc(row.productName || "—")}</td><td>${formatFen(row.unitCostFen)}</td><td>${row.effectiveFrom === "1970-01-01" ? "长期有效" : esc(row.effectiveFrom)}</td><td>${esc(row.effectiveTo || "仍在使用")}</td><td><button class="button secondary small" data-action="edit-cost" data-cost-id="${esc(row.id)}">修改</button></td></tr>`).join("")}</tbody></table></div>` : `<div class="empty-inline">还没有商品进货价。可以手动添加，或导入成本表。</div>`}</section>`;
}
function renderIssues(data) {
  const issues = uniqueVisibleIssues([...data.issues].filter((row) => state.selectedStoreId === "all" || row.storeId === state.selectedStoreId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)), data);
  const open = issues.filter((row) => row.status === "open" || row.status === "review").length;
  const mismatches = findFeeSettlementMismatches(data);
  const mismatchNote = mismatches.length ? `<div class="warning-note" style="margin-bottom:14px"><strong>有 ${mismatches.length} 笔订单的到账金额对不上。</strong>请打开平台账单，查看订单金额、退款和平台扣费是否一致。平台可能还会调整运费或补贴。</div>` : "";
  const cards = issues.length ? issues.map((issue) => {
    const order = orderForIssue(issue, data);
    const missingItem = issue.issueType === "missing_cost" ? data.orderItems.find((item) => `missing-cost|${item.storeId}|${item.skuId}` === issue.stableKey) : null;
    const description = order
      ? `订单 ${order.platformOrderId} 的状态“${order.orderStatus}”无法识别，默认不计入销售。确认已成交后可按成交计入；如果是待付款，请保留不计入。`
      : issue.description;
    return `<article class="issue-card" id="issue-${esc(issue.id)}" tabindex="-1"><div class="issue-card-head"><span class="tag ${issue.severity === "error" ? "tag-danger" : issue.severity === "info" ? "tag-blue" : "tag-warn"}">${esc(SEVERITY_LABELS[issue.severity] || "请检查")}</span><strong>${esc(ISSUE_LABELS[issue.issueType] || "需要检查")}</strong><span class="tag ${issue.status === "resolved" ? "tag-ok" : "tag-neutral"}">${esc(ISSUE_STATUS_LABELS[issue.status] || "待处理")}</span></div><p data-generated-issue>${esc(description)}</p>${orderIssueActions(issue, order)}${missingItem && issue.status !== "resolved" ? productAction({ ...missingItem, target: "costs" }, "填写进货价") : ""}<div class="issue-card-foot"><span>${esc(storeName(data, issue.storeId))} · ${esc(String(issue.createdAt || "").slice(0, 16).replace("T", " "))}</span>${issue.status !== "resolved" && !order && !missingItem ? `<button class="button secondary small" data-action="resolve-issue" data-issue-id="${esc(issue.id)}">标记已处理</button>` : issue.status === "resolved" ? `<span class="help-text">${esc(issue.resolutionNote || "已标记处理")}</span>` : ""}</div></article>`;
  }).join("") : `<div class="empty-inline">目前没有需要检查的问题。</div>`;
  return `${pageHeading("需要处理", "这里列出需要你检查的内容。", `共有 ${open} 条还没处理。点开每条可以看原因；处理后点击“标记已处理”。`, `<button class="button secondary" data-action="export-xlsx">下载经营报告</button>`)}${mismatchNote}<section class="card card-pad"><div class="section-title"><div><h2>问题清单</h2><p>共 ${issues.length} 条，包含表格内容、订单状态、重复记录和缺少进货价等问题。</p></div><span class="tag ${open ? "tag-warn" : "tag-ok"}">${open} 条待处理</span></div><div class="issue-list">${cards}</div></section>`;
}

function renderSettings(data) {
  const counts = `店铺 ${data.stores.length} 个 · 订单 ${data.orders.length} 笔 · 商品成本 ${data.productCosts.length} 条 · 退款 ${data.refunds.length} 笔`;
  return `${pageHeading("备份数据", "保存一份副本，换设备也能带走。", "数据只保存在当前设备和当前浏览器。清除浏览器记录后，数据可能无法找回。")}
    <section class="grid grid-2"><article class="card card-pad"><div class="section-title"><div><h2>当前浏览器空间</h2><p id="storage-summary">正在查看可用空间…</p></div><span class="tag tag-ok">当前设备</span></div><div class="storage-meter"><span id="storage-meter-fill"></span></div><div class="storage-meta"><span id="storage-used">已使用 —</span><span id="storage-quota">可用 —</span></div><p class="help-text" id="storage-persistent-note" style="margin-top:12px">浏览器清理网站数据可能会删除订单。建议定期下载备份。</p><button class="button secondary small" data-action="request-persistence" style="margin-top:10px">尽量保留此网站的数据</button></article>
    <article class="card card-pad"><div class="section-title"><div><h2>下载备份文件</h2><p>包含店铺、订单、成本、退款和问题记录。</p></div><span class="tag tag-blue">${data.stores.length} 个店铺</span></div><p class="help-text">备份文件可能包含订单和费用详情，请保存到安全的位置，不要公开分享。</p><button class="button" data-action="download-backup">下载备份文件</button></article></section>
    <section class="card card-pad" style="margin-top:16px"><div class="section-title"><div><h2>从备份恢复</h2><p>可以把以前保存的记录放回这个浏览器。恢复会替换当前数据。</p></div></div><div class="inline-form"><div class="field"><label for="restore-file">选择以前下载的备份文件</label><input id="restore-file" type="file" accept=".json,application/json"></div></div><p class="form-note">选择后会先显示文件里的记录数量；确认两次后才会替换当前数据。</p></section>
    <section class="card card-pad danger-zone" style="margin-top:16px"><div class="section-title"><div><h2>清空这个浏览器里的数据</h2><p>会删除店铺、订单、成本、退款和问题记录，且不能撤销。</p></div><span class="tag tag-danger">不能撤销</span></div><button class="button danger" data-action="clear-data">清空全部数据</button></section>
    <section class="card card-pad" style="margin-top:16px"><div class="section-title"><div><h2>目前保存的数据</h2><p>${esc(counts)}</p></div></div><p class="help-text">更换浏览器、设备或网址后不会自动同步。请用备份文件搬运数据。</p></section>`;
}

function renderGuide() {
  return `${pageHeading("新手教程", "跟着页面点几步，最后看见完整结果。", "分步体验会载入单独的虚构样例，并带你查看总览、提醒、成本和导入页面。", `<button class="button secondary" data-action="tutorial-start-demo">重新开始引导</button><button class="button" data-action="load-demo">载入虚构样例</button>`)}
    <section class="guide-grid">
      <article class="card guide-step"><span class="guide-step-num">第 1 步</span><span class="guide-icon">▣</span><h3>添加店铺名称</h3><p>点左侧“店铺管理”，选择你在哪个平台卖，并填写店铺名称。这里只做分类，不会登录或连接平台账号。</p></article>
      <article class="card guide-step"><span class="guide-step-num">第 2 步</span><span class="guide-icon">⇧</span><h3>导入平台导出的订单表</h3><p>点“导入表格”，选择店铺、订单表和文件。系统会先帮你认列名；检查预览没有问题后，再点“保存记录”。</p></article>
      <article class="card guide-step"><span class="guide-step-num">第 3 步</span><span class="guide-icon">◇</span><h3>补上商品进货价</h3><p>点“商品成本”，填写订单表里相同的商品编号和每件进货价。成本越齐，预计利润越接近实际。</p></article>
      <article class="card guide-step"><span class="guide-step-num">完成</span><span class="guide-icon">↗</span><h3>查看利润并下载报告</h3><p>回到“经营总览”查看销售额、退款和预计利润。黄色提醒会告诉你还有什么需要补充或检查。</p></article>
    </section>
    <section class="card card-pad guide-demo"><div><div class="section-eyebrow">第一次使用</div><h2>先看一套完整示例</h2><p>示例全部是虚构数据，只保存在你的浏览器里，不会影响真实店铺资料。</p></div><button class="button" data-action="load-demo">载入虚构样例</button></section>
    <section class="grid grid-2" style="margin-top:16px"><details class="card card-pad disclosure"><summary>为什么利润显示“预计”？</summary><p>系统只按你导入的订单、退款、进货价和费用计算。如果少了成本或费用，预计利润可能偏高；平台实际到账也可能因运费、补贴或调整而不同。</p></details>
      <details class="card card-pad disclosure"><summary>我的订单会保存在哪里？</summary><p>订单只保存在当前设备的当前浏览器中，不会上传到网站。换设备、换浏览器或换网址不会自动同步；需要搬家时，请先下载备份文件。</p></details>
      <details class="card card-pad disclosure"><summary>怎么把数据带到另一台电脑？</summary><p>先在“备份数据”下载备份文件，再在另一台电脑打开网站，选择“从备份恢复”。恢复会替换那台电脑当前保存的数据。</p></details>
      <details class="card card-pad disclosure"><summary>导入错了怎么办？</summary><p>先到“数据明细”查看结果。如果不确定，请不要清空数据，先下载备份，再联系维护人员协助处理。</p></details></section>
    <details class="card card-pad disclosure" style="margin-top:16px"><summary>开源组件和许可</summary><p>读取和导出 Excel 使用 SheetJS Community Edition。<a class="license-link" href="./THIRD_PARTY_NOTICES.md" target="_blank" rel="noopener">查看开源许可</a>。</p></details>`;
}

function renderPage(data = state.data) {
  if (state.selectedStoreId === 'all' && new Set(data.stores.map(store => store.currency || 'CNY')).size > 1) state.selectedStoreId = data.stores[0].id;
  setDisplayCurrency((data.stores.find(store => store.id === state.selectedStoreId) || data.stores[0])?.currency || 'CNY', state.language);
  $("#app-shell").dataset.page = state.page;
  const root = $("#page-content");
  const renderers = { overview: renderDashboard, stores: renderStores, import: renderImport, records: renderRecords, costs: renderCosts, issues: renderIssues, settings: renderSettings, guide: () => renderGuide() };
  root.innerHTML = (renderers[state.page] || renderDashboard)(data);
  fillGlobalControls(data);
  root.focus({ preventScroll: true });
  if (state.page === "settings") updateStorageDetails();
}

function setPage(page) {
  if (!PAGE_META[page]) return;
  if (state.page === "import" && page !== "import" && state.pendingFile && !window.confirm("这份表格还没有确认保存。离开后，本次打开页面期间仍可返回预览；刷新或关闭页面后需要重新选择。继续离开吗？")) return;
  state.page = page;
  savePrefs();
  renderPage();
  window.scrollTo({ top: 0, behavior: "auto" });
}

function setFilterFromControls(source) {
  state.selectedStoreId = $("#global-store-select").value || "all";
  const fromOverview = source?.matches("#overview-start, #overview-end");
  const start = fromOverview ? $("#overview-start").value : $("#global-start").value;
  const end = fromOverview ? $("#overview-end").value : $("#global-end").value;
  if (normalizeDate(start) && normalizeDate(end)) {
    state.start = start;
    state.end = end;
    if (state.start > state.end) [state.start, state.end] = [state.end, state.start];
  }
  savePrefs();
  renderPage();
}

function applyQuickPeriod(preset) {
  const today = localToday();
  if (preset === "7") { state.end = today; state.start = dateOffset(today, -6); }
  else if (preset === "30") { state.end = today; state.start = dateOffset(today, -29); }
  else if (preset === "month") { state.start = `${today.slice(0, 7)}-01`; state.end = today; }
  else if (preset === "previous-month") {
    const first = new Date(`${today.slice(0, 7)}-01T12:00:00`);
    first.setDate(0);
    state.end = `${first.getFullYear()}-${String(first.getMonth() + 1).padStart(2, "0")}-${String(first.getDate()).padStart(2, "0")}`;
    state.start = `${state.end.slice(0, 7)}-01`;
  } else return;
  savePrefs();
  renderPage();
}

function normalizeIdbError(error) {
  if (error?.name === "ConstraintError") return new Error("订单号重复，或同一商品同一天的进货价已经保存过了。没有新增记录。", { cause: error });
  if (error?.name === "DataCloneError") return new Error("有一项内容不能保存，请检查后重试。原有数据没有更改。", { cause: error });
  return error;
}

async function addStore(form) {
  const values = new FormData(form);
  const name = String(values.get("name") || "").trim();
  const platform = String(values.get("platform") || "").trim();
  if (!name || !platform) throw new Error("请填写店铺名称并选择销售平台。");
  const id = uid();
  const currency = String(values.get('currency') || 'CNY');
  if (!Object.hasOwn(CURRENCIES, currency)) throw new Error('请选择有效的币种。');
  const record = { id, platform, name, currency, createdAt: new Date().toISOString() };
  await writeRecords(state.db, { stores: [record] }, "add");
  state.selectedStoreId = id;
  state.importStoreId = id;
  savePrefs();
  await refreshData();
  state.page = "import";
  renderPage();
  toast("店铺已保存到当前浏览器。", "ok");
}

async function addManualCost(form) {
  const values = new FormData(form);
  const storeId = String(values.get("storeId") || "");
  const skuId = String(values.get("skuId") || "").trim();
  const productName = String(values.get("productName") || "").trim();
  const effectiveFrom = normalizeDate(values.get("effectiveFrom"));
  const effectiveTo = normalizeDate(values.get("effectiveTo")) || null;
  const currency = state.data.stores.find(store => store.id === storeId)?.currency || 'CNY';
  const unitCostFen = parseMoneyFen(normalizeMoneyForCurrency(values.get("unitCost"), currency));
  if (!state.data.stores.some((store) => store.id === storeId)) throw new Error("请选择一个店铺。");
  if (!skuId || !effectiveFrom || unitCostFen === null || unitCostFen < 0) throw new Error("商品编号、开始日期和正确的进货价都需要填写。");
  if (effectiveTo && effectiveTo < effectiveFrom) throw new Error("截止日期不能早于开始日期。");
  const existing = state.editCostId && state.data.productCosts.find((row) => row.id === state.editCostId);
  if (state.editCostId && !existing) throw new Error("找不到要修改的成本，请刷新后重试。");
  if (existing && !window.confirm(`修改 ${skuId} 的进货价会重新计算相关历史订单的利润。请确认生效日期 ${effectiveFrom} 和价格 ${formatFen(unitCostFen, currency)} 正确。继续吗？`)) return;
  const record = { ...(existing || {}), id: existing?.id || uid(), storeId, skuId, productName, unitCostFen, effectiveFrom, effectiveTo,
    costSource: "手动维护", updatedAt: new Date().toISOString() };
  record.recordKey = stableRecordKey("costs", record);
  record.rowHash = JSON.stringify({ storeId, skuId, productName, unitCostFen, effectiveFrom, effectiveTo });
  await writeRecords(state.db, { productCosts: [record] }, existing ? "put" : "add");
  state.editCostId = null;
  state.focusProduct = null;
  await refreshData();
  renderPage();
  toast("商品进货价已保存，相关利润会重新计算。", "ok");
}

async function saveBulkCosts(form) {
  const records = [];
  for (const input of form.querySelectorAll('[data-bulk-cost]')) {
    const text = input.value.trim();
    if (!text) continue;
    const row = state.missingCostRows[Number(input.dataset.bulkCost)];
    const currency = state.data.stores.find(store => store.id === row.storeId)?.currency || 'CNY';
    const unitCostFen = parseMoneyFen(normalizeMoneyForCurrency(text, currency));
    if (unitCostFen === null || unitCostFen < 0) { input.focus(); throw new Error(`${row.productName} 的进货价无法识别，请输入不小于零的金额。`); }
    const record = { id: uid(), storeId: row.storeId, skuId: row.skuId, productName: row.productName, unitCostFen, effectiveFrom: row.effectiveFrom, effectiveTo: null, costSource: '手动维护', updatedAt: new Date().toISOString() };
    record.recordKey = stableRecordKey('costs', record);
    record.rowHash = JSON.stringify({ storeId: row.storeId, skuId: row.skuId, productName: row.productName, unitCostFen, effectiveFrom: row.effectiveFrom, effectiveTo: null });
    records.push(record);
  }
  if (!records.length) throw new Error('请至少填写一件商品的进货价，或选择暂时跳过。');
  if (records.some(record => record.effectiveFrom < localToday()) && !window.confirm('这些进货价从列表中显示的日期开始生效，可能改变之前订单的利润。请核对当时的实际进货价，确认保存吗？')) return;
  await writeRecords(state.db, { productCosts: records }, 'add');
  await refreshData();
  state.page = 'overview';
  savePrefs();
  renderPage();
  toast(`已保存 ${records.length} 件商品的进货价。`, 'ok');
}

async function handleImportFile(file) {
  if (!file) return;
  const selectedReportType = $("#import-kind")?.value || state.importReportType;
  const selectedStoreId = $("#import-store")?.value || state.importStoreId;
  state.importReportType = selectedReportType;
  state.importStoreId = selectedStoreId;
  try {
    if (file.size > MAX_FILE_BYTES) throw new Error("单个文件不能超过 20 MB。");
    const parsed = await readTabularFile(file, { encoding: state.csvEncoding });
    const fileHash = await sha256(parsed.buffer);
    const reportType = selectedReportType;
    const storeId = selectedStoreId || state.data.stores[0]?.id;
    state.pendingSourceFile = file;
    state.importPlan = null;
    state.pendingFile = { fileName: file.name, size: file.size, reportType, storeId, fileHash, headers: parsed.headers, rows: parsed.rows, sheetName: parsed.sheetName };
    state.importMapping = suggestMapping(reportType, parsed.headers);
    renderPage();
    toast(`读到了 ${parsed.rows.length} 行。检查无误后再保存。`, "ok");
  } catch (error) { presentError(error, "解析文件失败"); }
}

function validateMapping(reportType, mapping) {
  const missing = REPORTS[reportType].fields.filter((field) => field.required && !mapping[field.key]).map((field) => field.label);
  if (reportType === "orders" && !mapping.itemAmount && !mapping.unitPrice) missing.push("商品实付金额或商品单价（二选一）");
  if (missing.length) throw new Error(`请先在下拉菜单里选出这些表格列：${missing.join("、")}`);
}

async function validateImport() {
  const pending = state.pendingFile;
  if (!pending) throw new Error("请先选择一份表格。");
  const reportType = $("#import-kind")?.value || pending.reportType;
  const storeId = $("#import-store")?.value || pending.storeId;
  const mapping = Object.fromEntries(REPORTS[reportType].fields.map((field) => [field.key, $(`[data-map-field="${field.key}"]`)?.value || ""]));
  validateMapping(reportType, mapping);
  state.pendingFile = { ...pending, reportType, storeId };
  state.importMapping = mapping;
  state.dateOrder = $("#import-date-order")?.value || '';
  state.importPlan = await prepareImport(state.db, { name: pending.fileName, size: pending.size }, reportType, storeId, pending.headers, pending.rows, mapping, pending.fileHash, state.dateOrder);
  renderPage();
  toast("表格检查完成，请看看下面的结果。", "ok");
}

async function importValidatedRows() {
  const plan = state.importPlan;
  if (!plan || plan.duplicateFile || !plan.accepted.length) throw new Error("没有可以保存的新记录。");
  const invalidCount = plan.rejected.length + plan.conflicts.length;
  const message = `将保存 ${plan.accepted.length} 条新记录，跳过 ${plan.duplicates.length} 条重复记录，另有 ${invalidCount} 行需要检查。\n\n表格文件不会上传或保存。要继续吗？`;
  if (!window.confirm(message)) return;
  try {
    plan.confirmedCoverage = $("#confirm-report-coverage")?.checked ? { start: state.start, end: state.end } : null;
    const result = await commitImport(state.db, plan);
    state.selectedStoreId = plan.storeId;
    state.importStoreId = plan.storeId;
    if (plan.coverageStart && plan.coverageEnd && (plan.coverageEnd < state.start || plan.coverageStart > state.end)) {
      state.start = plan.coverageStart;
      state.end = plan.coverageEnd;
    }
    state.pendingFile = null;
    state.importPlan = null;
    state.importMapping = null;
    await refreshData();
    state.page = plan.reportType === "orders" && currentSummary(state.data).missingCosts.length ? "costs" : "overview";
    savePrefs();
    renderPage();
    toast(`导入完成：保存 ${result.importedCount} 条，跳过重复记录 ${result.duplicateCount} 条，有 ${result.rejectedCount + result.conflictCount} 行需要检查。建议到“备份数据”下载副本。`, "ok", 8000);
  } catch (error) { presentError(normalizeIdbError(error), "导入未完成"); }
}

function clickDownload(blob, fileName) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  anchor.hidden = true;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function csvCell(value) {
  let text = String(value ?? "");
  if (/^[\s]*[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

function downloadImportTemplate() {
  const report = REPORTS[state.importReportType];
  const headers = report.fields.map((field) => field.aliases[0] || field.label);
  const csv = `\uFEFF${headers.map(csvCell).join(",")}\r\n`;
  clickDownload(new Blob([csv], { type: "text/csv;charset=utf-8" }), `空白示例_${report.label}.csv`);
}

function downloadImportErrors() {
  const plan = state.importPlan;
  if (!plan) throw new Error("请先检查表格。");
  const rows = [["原表行号", "问题", ...plan.headers],
    ...plan.rejected.map((row) => [row.rowNumber, row.message, ...row.raw]),
    ...plan.conflicts.map((row) => [row.rowNumber, "记录已存在但内容不同，请核对", ...row.raw])];
  const csv = `\uFEFF${rows.map((row) => row.map(csvCell).join(",")).join("\r\n")}\r\n`;
  clickDownload(new Blob([csv], { type: "text/csv;charset=utf-8" }), "待检查的表格行.csv");
}

async function exportBackup() {
  const snapshot = await readSnapshot(state.db);
  const backup = makeBackup(snapshot);
  const json = JSON.stringify(backup, null, 2);
  if (json.length > 120 * 1024 * 1024) throw new Error("备份文件超过浏览器可安全导出的大小，请分批清理或检查异常记录数。");
  const date = localToday().replaceAll("-", "");
  const name = snapshot.stores.length === 1 ? snapshot.stores[0].name : "全部店铺";
  const safeName = String(name || "全部店铺").replace(/[\\/:*?"<>|]/g, "_").slice(0, 35);
  clickDownload(new Blob([json], { type: "application/json;charset=utf-8" }), `卖家利润助手_${safeName}_备份_${date}.json`);
  state.lastBackupAt = new Date().toISOString();
  savePrefs();
  updateSidebarBackupStatus();
  toast(`备份文件已生成：${snapshot.stores.length} 个店铺、${snapshot.orders.length} 个订单。请妥善保管下载文件。`, "ok", 6000);
}

async function undoBatch(batchId) {
  const batch = state.data.importBatches.find((row) => row.id === batchId);
  if (!batch || batch.demo) throw new Error("找不到此批次，或演示数据不支持按批次撤销。");
  const labels = { orders: "订单", orderItems: "商品明细", refunds: "退款", platformFees: "平台扣费", productCosts: "商品成本", otherExpenses: "其他支出", settlements: "到账记录" };
  const counts = Object.entries(labels).map(([name, label]) => `${label} ${state.data[name].filter((row) => row.importBatchId === batchId).length} 条`).join("、");
  if (!window.confirm(`准备撤销“${batch.originalFilename}”。该批次保存的记录：${counts}。\n\n操作会删除这些记录并重新计算，建议先下载备份。其他批次若关联这些订单，系统会阻止撤销。继续吗？`)) return;
  if (window.prompt('请再次输入“撤销”以确认删除此批次。', "") !== "撤销") { toast("未确认，批次没有被删除。", "warn"); return; }
  await undoImportBatch(state.db, batchId);
  await refreshData();
  renderPage();
  toast(`已撤销 ${batch.originalFilename}，相关数字已重新计算。`, "ok", 6000);
}

async function resolveOrderStatus(orderId, issueId, resolution) {
  const order = state.data.orders.find((row) => row.id === orderId);
  const issue = state.data.issues.find((row) => row.id === issueId);
  if (!order || !issue) throw new Error("找不到这笔订单或提醒，请刷新页面后重试。");
  let statusClass = "unknown";
  let orderStatus = order.orderStatus;
  if (resolution === "include") statusClass = "valid";
  else if (resolution === "ignore") statusClass = "ignored";
  else {
    orderStatus = String(window.prompt("手动输入订单状态（例如：已完成、已取消、待付款、忽略）：", order.orderStatus) || "").trim();
    if (!orderStatus) return;
    const clean = cleanStatus(orderStatus);
    if (isPendingOrderStatus(orderStatus) || ["忽略", "不计入", "已忽略"].includes(clean)) statusClass = "ignored";
    else if (classifyOrderStatus(orderStatus) !== "unknown") statusClass = classifyOrderStatus(orderStatus);
    else if (/(成交|支付成功|付款成功|已付款|已支付)/.test(orderStatus)) statusClass = "valid";
    else if (/(取消|关闭)/.test(orderStatus)) statusClass = "cancelled";
    else { toast("这个状态仍无法判断。请填写已成交、已取消、待付款或忽略。", "warn", 5500); return; }
  }
  const updatedOrder = { ...order, orderStatus, statusClass, updatedAt: new Date().toISOString() };
  const resolvedAt = new Date().toISOString();
  const resolutionNote = resolution === "include" ? "已按已成交计入销售。" : resolution === "ignore" ? "已忽略，未计入销售。" : `已手动指定为“${orderStatus}”。`;
  const linkedIssues = state.data.issues.filter((row) => row.issueType === "unknown_order_status" && orderForIssue(row, state.data)?.id === order.id);
  const updatedIssues = (linkedIssues.length ? linkedIssues : [issue]).map((row) => ({ ...row, status: "resolved", resolutionNote, resolvedAt }));
  await writeRecords(state.db, { orders: [updatedOrder], issues: updatedIssues }, "put");
  await refreshData();
  renderPage();
  toast(statusClass === "valid" ? "订单已计入销售，利润已更新。" : "订单已按指定状态处理，未计入销售。", "ok", 5000);
}

async function handleRestoreFile(file) {
  if (!file) return;
  try {
    if (file.size > 120 * 1024 * 1024) throw new Error("备份文件大于 120 MB，无法安全读取。");
    const parsed = validateBackup(JSON.parse(await file.text()));
    const labels = { stores: "店铺", orders: "订单", orderItems: "商品明细", refunds: "退款", platformFees: "平台扣费", productCosts: "商品成本", otherExpenses: "其他支出", settlements: "到账记录", importBatches: "导入记录", issues: "待处理问题" };
    const counts = Object.entries(parsed.stores).filter(([, rows]) => rows.length).map(([name, rows]) => `${labels[name] || name} ${rows.length} 条`).join("，") || "没有数据";
    if (!window.confirm(`备份文件可以使用。恢复后会替换当前浏览器里的数据。\n\n文件里有：${counts}\n\n建议先下载当前数据备份。要继续吗？`)) return;
    const confirmation = window.prompt("最后确认：输入“替换”以覆盖当前浏览器里的全部数据。", "");
    if (confirmation !== "替换") { toast("未输入“替换”，恢复已取消；当前数据未变更。", "warn"); return; }
    const result = await restoreBackup(state.db, parsed);
    await refreshData();
    renderPage();
    toast(`恢复完成：${result.stores} 个店铺、${result.orders} 笔订单、${result.orderItems} 条商品明细。`, "ok", 6500);
  } catch (error) { presentError(error, "备份恢复失败；原有数据未被标记为已替换"); }
}

async function clearBrowserData() {
  if (!window.confirm("确定清空这个浏览器里的店铺、订单、退款、费用和进货价吗？这一步不能撤销。")) return;
  const confirmation = window.prompt("请再次输入“清空”以确认删除全部本地数据。", "");
  if (confirmation !== "清空") { toast("未输入“清空”，数据未删除。", "warn"); return; }
  try {
    await clearAllData(state.db);
    try { localStorage.removeItem(PREFS_KEY); } catch { /* settings are optional */ }
    state.lastBackupAt = "";
    state.selectedStoreId = "all";
    state.start = "";
    state.end = "";
    state.page = "overview";
    await refreshData();
    renderPage();
    toast("全部本地数据已清空。", "ok", 6000);
  } catch (error) { presentError(error, "没有清空成功；原有数据仍在"); }
}

async function updateStorageDetails() {
  const summary = $("#storage-summary");
  if (!summary) return;
  try {
    const estimate = await navigator.storage?.estimate?.();
    const used = Number(estimate?.usage || 0);
    const quota = Number(estimate?.quota || 0);
    const persisted = await navigator.storage?.persisted?.();
    const ratio = quota ? Math.min(100, used / quota * 100) : 0;
    summary.textContent = persisted ? "浏览器会尽量保留此网站的数据。" : "数据保存在此浏览器中，清理浏览记录时可能被删除。";
    $("#storage-used").textContent = `已使用 ${bytesLabel(used)}`;
    $("#storage-quota").textContent = quota ? `估计还能使用 ${bytesLabel(quota)}` : "浏览器没有提供空间信息";
    $("#storage-meter-fill").style.width = `${ratio.toFixed(1)}%`;
    $("#storage-persistent-note").textContent = persisted ? "浏览器会尽量保留数据，但清理网站记录或设备故障仍可能造成丢失。请定期下载备份。" : "可以请浏览器尽量保留数据，但浏览器仍可能清理。建议定期下载备份。";
  } catch (error) {
    summary.textContent = "浏览器没有提供空间信息；保存时如果失败会显示提示。";
    console.warn("无法读取存储额度", error);
  }
}

async function requestStoragePersistence() {
  if (!navigator.storage?.persist) throw new Error("这个浏览器不支持保留数据的设置。建议定期下载备份。");
  const persisted = await navigator.storage.persist();
  await updateStorageDetails();
  toast(persisted ? "浏览器会尽量保留此网站的数据。" : "浏览器没有开启保留设置；数据仍在本机，但请定期下载备份。", persisted ? "ok" : "warn", 6000);
}

async function exportXlsx() {
  const summary = currentSummary();
  try {
    const currency = (state.data.stores.find(store => store.id === state.selectedStoreId) || state.data.stores[0])?.currency || 'CNY';
    await ensureSpreadsheetLibrary("style");
    downloadWorkbook(state.data, summary, selectedStoreName(), state.lowMarginThreshold, state.language, currency);
    toast("Excel 报告已生成并下载。", "ok", 5500);
  } catch (error) { presentError(error, "生成 Excel 失败"); }
}

async function resolveIssue(issueId) {
  const issue = state.data.issues.find((row) => row.id === issueId);
  if (!issue) throw new Error("找不到这条待处理问题。");
  const note = window.prompt("可填写处理备注（可留空）：", issue.resolutionNote || "");
  if (note === null) return;
  await putOne(state.db, "issues", { ...issue, status: "resolved", resolutionNote: note.trim(), resolvedAt: new Date().toISOString() });
  await refreshData();
  renderPage();
  toast("已标记为处理完成。", "ok");
}

async function handleClick(event) {
  const periodButton = event.target.closest("[data-period]");
  if (periodButton) { applyQuickPeriod(periodButton.dataset.period); return; }
  const nav = event.target.closest("[data-nav]");
  if (nav) {
    event.preventDefault();
    if (nav.dataset.importReport && REPORTS[nav.dataset.importReport]) state.importReportType = nav.dataset.importReport;
    if (state.guidedTourActive) {
      const step = GUIDED_TOUR_STEPS[state.guidedTourStep];
      if (nav.dataset.nav !== step.page) { toast(`请先点击高亮的“${step.name}”继续。`, "warn", 2500); return; }
      setPage(step.page);
      if (state.guidedTourStep === GUIDED_TOUR_STEPS.length - 1) finishGuidedTour();
      else { state.guidedTourStep += 1; renderGuidedTour(); }
      return;
    }
    if (nav.closest("#welcome-tutorial")) closeTutorial();
    setPage(nav.dataset.nav);
    return;
  }
  if (state.guidedTourActive && !event.target.closest("#guided-tour-card")) {
    event.preventDefault();
    toast("请按提示点击高亮菜单，或退出引导。", "warn", 2500);
    return;
  }
  const control = event.target.closest("[data-action]");
  if (!control || control.disabled) return;
  try {
    switch (control.dataset.action) {
      case "tutorial-open": openTutorial(); break;
      case "tutorial-skip": if (state.guidedTourSeen) closeTutorial(); break;
      case "tutorial-own": closeTutorial(); markTutorialSeen(); setPage("import"); break;
      case "tutorial-start-demo": await startGuidedTour(control); break;
      case "guided-tour-skip": finishGuidedTour({ skipped: true }); break;
      case "guided-tour-back":
        if (state.guidedTourStep > 0) {
          state.guidedTourStep -= 1;
          setPage(GUIDED_TOUR_STEPS[state.guidedTourStep].page);
          renderGuidedTour();
        }
        break;
      case "load-demo": {
        if (control.closest("#welcome-tutorial")) closeTutorial();
        control.disabled = true;
        const result = await loadDemoData(state.db);
        if (!result.loaded) toast("虚构演示数据已经载入过，没有重复写入。", "warn");
        else toast(`已载入虚构样例：${result.orderCount} 个订单、${result.itemCount} 条商品明细。`, "ok", 6000);
        state.selectedStoreId = "demo-store-local-v1";
        state.start = `${localToday().slice(0, 7)}-01`;
        state.end = localToday();
        await refreshData();
        state.page = "overview";
        savePrefs();
        renderPage();
        break;
      }
      case "validate-import": await validateImport(); break;
      case "commit-import": await importValidatedRows(); break;
      case "clear-import": state.pendingFile = null; state.pendingSourceFile = null; state.importPlan = null; state.importMapping = null; renderPage(); break;
      case "download-template": downloadImportTemplate(); break;
      case "download-import-errors": downloadImportErrors(); break;
      case "undo-batch": await undoBatch(control.dataset.batchId); break;
      case "download-backup": await exportBackup(); break;
      case "clear-data": await clearBrowserData(); break;
      case "request-persistence": await requestStoragePersistence(); break;
      case "export-xlsx": await exportXlsx(); break;
      case "focus-product": {
        const target = control.dataset.target === "costs" ? "costs" : "records";
        const relatedOrderIds = new Set(state.data.orderItems.filter((item) => item.storeId === control.dataset.storeId && item.skuId === control.dataset.skuId).map((item) => item.orderId));
        const earliest = state.data.orders.filter((order) => relatedOrderIds.has(order.id) && order.statusClass === "valid" && order.orderedAt >= state.start && order.orderedAt <= state.end && !findCost(state.data.productCosts, order.storeId, control.dataset.skuId, order.orderedAt)).map((order) => order.orderedAt).sort()[0];
        state.focusProduct = { target, storeId: control.dataset.storeId, skuId: control.dataset.skuId, productName: control.dataset.productName, effectiveFrom: control.dataset.start || earliest || "" };
        state.editCostId = null;
        state.recordQuery = "";
        state.recordPage = 0;
        if (control.dataset.storeId) state.selectedStoreId = control.dataset.storeId;
        if (target === "records") state.recordType = "orderItems";
        state.page = target;
        savePrefs();
        renderPage();
        window.requestAnimationFrame(() => {
          const point = target === "costs" ? $("#cost-sku") : $("#focused-product-record");
          point?.scrollIntoView({ behavior: "smooth", block: "center" });
          if (target === "costs") point?.focus({ preventScroll: true });
        });
        break;
      }
      case "clear-product-focus": state.focusProduct = null; renderPage(); break;
      case "edit-cost": state.editCostId = control.dataset.costId; state.focusProduct = null; renderPage(); window.requestAnimationFrame(() => $("#cost-value")?.focus()); break;
      case "cancel-cost-edit": state.editCostId = null; renderPage(); break;
      case "records-page": state.recordPage = Math.max(0, Number(control.dataset.page) || 0); renderPage(); break;
      case "resolve-issue": await resolveIssue(control.dataset.issueId); break;
      case "order-status": await resolveOrderStatus(control.dataset.orderId, control.dataset.issueId, control.dataset.resolution); break;
      case "open-issue": {
        state.page = "issues";
        savePrefs();
        renderPage();
        const target = document.getElementById(`issue-${control.dataset.issueId}`);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "center" });
          target.focus({ preventScroll: true });
        }
        break;
      }
      case "select-store": state.selectedStoreId = control.dataset.storeId; savePrefs(); await refreshData(); setPage("overview"); break;
      default: break;
    }
  } catch (error) { presentError(normalizeIdbError(error), "操作失败"); }
}

async function handleChange(event) {
  const target = event.target;
  if (target.matches("#global-store-select, #global-start, #global-end, #overview-start, #overview-end")) { setFilterFromControls(target); return; }
  if (target.matches("[data-low-margin-threshold]")) {
    const value = Number(target.value);
    if (!Number.isFinite(value)) return;
    state.lowMarginThreshold = Math.max(0, Math.min(50, value));
    savePrefs();
    renderPage();
    return;
  }
  if (target.matches("#import-date-order")) { state.dateOrder = target.value; state.importPlan = null; renderPage(); return; }
  if (target.matches("[data-record-type]")) { state.recordType = target.value; state.recordPage = 0; renderPage(); return; }
  if (target.matches("[data-csv-encoding]")) { state.csvEncoding = target.value; if (state.pendingSourceFile) await handleImportFile(state.pendingSourceFile); else renderPage(); return; }
  if (target.matches("[data-import-store]")) {
    state.importStoreId = target.value;
    state.importPlan = null;
    if (state.pendingFile) state.pendingFile.storeId = target.value;
    renderPage(); return;
  }
  if (target.matches("[data-import-kind]")) {
    state.importReportType = target.value;
    if (state.pendingFile) {
      state.pendingFile.reportType = target.value;
      state.importMapping = suggestMapping(target.value, state.pendingFile.headers);
      state.importPlan = null;
      renderPage();
    }
    return;
  }
  if (target.matches("[data-map-field]")) {
    state.importMapping = state.importMapping || {};
    state.importMapping[target.dataset.mapField] = target.value;
    state.importPlan = null;
    renderPage();
    return;
  }
  if (target.matches("#import-file")) { await handleImportFile(target.files?.[0]); return; }
  if (target.matches("#restore-file")) { await handleRestoreFile(target.files?.[0]); return; }
}

async function handleSubmit(event) {
  const form = event.target.closest("form[data-form]");
  if (!form) return;
  event.preventDefault();
  const submit = form.querySelector("button[type=submit]");
  if (submit) submit.disabled = true;
  try {
    if (form.dataset.form === "add-store") await addStore(form);
    else if (form.dataset.form === "add-cost") await addManualCost(form);
    else if (form.dataset.form === "bulk-cost") await saveBulkCosts(form);
    else if (form.dataset.form === "record-search") { const values = new FormData(form); state.recordQuery = String(values.get("query") || "").trim(); state.recordStatus = String(values.get("status") || "all"); state.recordUsePeriod = values.has("usePeriod"); state.recordPage = 0; renderPage(); }
  } catch (error) { presentError(normalizeIdbError(error), "保存失败"); }
  finally { if (submit?.isConnected) submit.disabled = false; }
}

function handleDrag(event) {
  const zone = event.target.closest(".dropzone");
  if (!zone) return;
  if (event.type === "dragover") { event.preventDefault(); zone.classList.add("dragover"); }
  if (event.type === "dragleave") zone.classList.remove("dragover");
  if (event.type === "drop") {
    event.preventDefault(); zone.classList.remove("dragover");
    const file = event.dataTransfer?.files?.[0];
    if (file) handleImportFile(file);
  }
}

async function start() {
  try {
    await setupLanguage(state.language, (language) => { state.language = language; savePrefs(); if (state.db) renderPage(); });
    state.db = await openDatabase();
    await refreshData();
    fillGlobalControls(state.data);
    $("#app-shell").addEventListener("click", handleClick);
    $("#app-shell").addEventListener("change", handleChange);
    $("#app-shell").addEventListener("submit", handleSubmit);
    $("#app-shell").addEventListener("dragover", handleDrag);
    $("#app-shell").addEventListener("dragleave", handleDrag);
    $("#app-shell").addEventListener("drop", handleDrag);
    window.addEventListener("unhandledrejection", (event) => presentError(event.reason, "本地操作异常"));
    const tutorialDialog = $("#welcome-tutorial");
    tutorialDialog.addEventListener("click", handleClick);
    tutorialDialog.addEventListener("cancel", (event) => { if (!state.guidedTourSeen) event.preventDefault(); });
    tutorialDialog.addEventListener("click", (event) => { if (event.target === tutorialDialog && state.guidedTourSeen) closeTutorial(); });
    const guidedTour = $("#guided-tour");
    const guidedTourSpotlight = $("#guided-tour-spotlight");
    guidedTour.addEventListener("click", handleClick);
    guidedTourSpotlight.addEventListener("click", (event) => {
      event.stopPropagation();
      $(GUIDED_TOUR_STEPS[state.guidedTourStep]?.target)?.click();
    });
    guidedTourSpotlight.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        event.stopPropagation();
        $(GUIDED_TOUR_STEPS[state.guidedTourStep]?.target)?.click();
      }
    });
    window.addEventListener("resize", positionGuidedTour);
    window.addEventListener("scroll", positionGuidedTour, true);
    renderPage();
    if (!state.guidedTourSeen) openTutorial();
    if (navigator.storage?.persisted) {
      const persisted = await navigator.storage.persisted();
      document.body.dataset.storagePersisted = String(persisted);
    }
  } catch (error) {
    console.error("Application startup failed", error);
    $("#page-content").innerHTML = `<section class="card empty-state"><div class="empty-art">!</div><h2>暂时读不到这个浏览器里的数据</h2><p>${esc(error.message || "浏览器没有打开本地数据空间。")}</p><p>请使用新版 Edge、Chrome 或 Firefox，并通过 https 网址打开。确认浏览器允许网站保存数据后，再刷新页面。此时没有数据被报告为已保存。</p></section>`;
  }
}

start();

window.addEventListener("beforeunload", (event) => {
  if (!state.pendingFile) return;
  event.preventDefault();
  event.returnValue = "";
});
