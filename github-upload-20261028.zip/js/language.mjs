import { extraTranslations, tourMessages } from "./extra-translations.mjs";
// All translations are bundled with the website. Merchant data is never sent
// to a translation service; user-provided values remain in their original form.
const LANGUAGES = [
  { code: 'zh-CN', name: '简体中文', flag: 'cn', dir: 'ltr' },
  { code: 'en', name: 'English', flag: 'us', dir: 'ltr' },
  { code: 'fr', name: 'Français', flag: 'fr', dir: 'ltr' },
  { code: 'ru', name: 'Русский', flag: 'ru', dir: 'ltr' },
  { code: 'es', name: 'Español', flag: 'es', dir: 'ltr' },
  { code: 'ar', name: 'العربية', flag: 'sa', dir: 'rtl' },
];
const CATALOGS = new Map();
const FRAGMENTS = new Map();
let currentLanguage = 'zh-CN';
const sources = new WeakMap();
const attributes = new WeakMap();

const formulaKey = '净销售额 = 商品销售额 − 已确认退款；已知项目利润 = 净销售额 − 已匹配成本 − 已导入费用；利润率 = 已知项目利润 ÷ 净销售额。退款按完成日、订单按下单日计入；缺项会影响结果。';
const unallocatedKey = '另有 __VARA__ 条退款或费用（合计 __VARB__）无法明确对应本期单个商品，未分摊到商品；店铺利润已计入这些款项。';
const OVERRIDES = {
  en: { '经营总览':'Overview', '店铺管理':'Stores', '导入表格':'Import files', '数据明细':'Records', '商品成本':'Product costs', '需要处理':'Needs attention', '新手教程':'Getting started', '卖家利润助手':'Seller Profit Assistant', '本期':'This period', '本月':'This month', '上月':'Last month', '已知项目利润率':'Recorded-item margin', '已匹配项目预计亏损 __VARA__':'Estimated loss from matched items: __VARA__', '资料不完整，暂不能确认赚亏':'Data is incomplete; profit or loss cannot yet be confirmed.', [formulaKey]:'Net sales = product sales − confirmed refunds; recorded-item profit = net sales − matched costs − imported fees; margin = recorded-item profit ÷ net sales. Orders are counted by order date; refunds by completion date. Missing data affects the result.', [unallocatedKey]:'__VARA__ refunds or fees totaling __VARB__ cannot be assigned to a single product in this period. They are not allocated to products, but are included in store profit.' },
  fr: { '经营总览':'Vue d’ensemble', '店铺管理':'Boutiques', '导入表格':'Importer des fichiers', '数据明细':'Données', '商品成本':'Coûts des produits', '需要处理':'À vérifier', '新手教程':'Premiers pas', '卖家利润助手':'Assistant de profit vendeur', '本期':'Cette période', '本月':'Ce mois-ci', '上月':'Mois dernier', '已知项目利润率':'Marge des éléments connus', '已匹配项目预计亏损 __VARA__':'Perte estimée des éléments associés : __VARA__', '资料不完整，暂不能确认赚亏':'Données incomplètes : le résultat ne peut pas encore être confirmé.', [formulaKey]:'Ventes nettes = ventes de produits − remboursements confirmés ; bénéfice connu = ventes nettes − coûts associés − frais importés ; marge = bénéfice connu ÷ ventes nettes. Les commandes comptent à leur date et les remboursements à leur date de finalisation. Les données manquantes influent sur le résultat.', [unallocatedKey]:'__VARA__ remboursements ou frais totalisant __VARB__ ne peuvent pas être attribués à un produit de cette période. Ils ne sont pas répartis entre les produits, mais sont inclus dans le bénéfice de la boutique.' },
  ru: { '经营总览':'Обзор', '店铺管理':'Магазины', '导入表格':'Импорт файлов', '数据明细':'Данные', '商品成本':'Себестоимость', '需要处理':'Требует внимания', '新手教程':'Начало работы', '卖家利润助手':'Помощник продавца', '本期':'Этот период', '本月':'Этот месяц', '上月':'Прошлый месяц', '已知项目利润率':'Маржа по известным данным', '已匹配项目预计亏损 __VARA__':'Расчётный убыток по сопоставленным данным: __VARA__', '资料不完整，暂不能确认赚亏':'Данных недостаточно для подтверждения прибыли или убытка.', [formulaKey]:'Чистые продажи = продажи товаров − подтверждённые возвраты; прибыль по известным данным = чистые продажи − сопоставленная себестоимость − импортированные расходы; маржа = прибыль по известным данным ÷ чистые продажи. Заказы учитываются по дате заказа, возвраты — по дате завершения. Отсутствующие данные влияют на результат.', [unallocatedKey]:'__VARA__ возвратов или расходов на сумму __VARB__ нельзя однозначно отнести к одному товару этого периода. Они не распределены по товарам, но включены в прибыль магазина.' },
  es: { '经营总览':'Resumen', '店铺管理':'Tiendas', '导入表格':'Importar archivos', '数据明细':'Registros', '商品成本':'Costes de productos', '需要处理':'Por revisar', '新手教程':'Primeros pasos', '卖家利润助手':'Asistente de beneficios', '本期':'Este periodo', '本月':'Este mes', '上月':'Mes pasado', '已知项目利润率':'Margen con datos registrados', '已匹配项目预计亏损 __VARA__':'Pérdida estimada con datos asociados: __VARA__', '资料不完整，暂不能确认赚亏':'Faltan datos; aún no se puede confirmar el beneficio o la pérdida.', [formulaKey]:'Ventas netas = ventas de productos − reembolsos confirmados; beneficio registrado = ventas netas − costes asociados − gastos importados; margen = beneficio registrado ÷ ventas netas. Los pedidos se cuentan por fecha de pedido y los reembolsos por fecha de finalización. Los datos ausentes afectan al resultado.', [unallocatedKey]:'__VARA__ reembolsos o gastos por un total de __VARB__ no se pueden atribuir claramente a un producto de este periodo. No se reparten entre productos, pero sí se incluyen en el beneficio de la tienda.' },
  ar: { '经营总览':'نظرة عامة', '店铺管理':'المتاجر', '导入表格':'استيراد الملفات', '数据明细':'السجلات', '商品成本':'تكاليف المنتجات', '需要处理':'يتطلب المراجعة', '新手教程':'دليل البدء', '卖家利润助手':'مساعد أرباح البائع', '本期':'هذه الفترة', '本月':'هذا الشهر', '上月':'الشهر الماضي', '已知项目利润率':'هامش الربح للبيانات المسجلة', '已匹配项目预计亏损 __VARA__':'الخسارة المقدرة للبيانات المطابقة: __VARA__', '资料不完整，暂不能确认赚亏':'البيانات غير مكتملة؛ لا يمكن تأكيد الربح أو الخسارة بعد.', [formulaKey]:'صافي المبيعات = مبيعات المنتجات − المبالغ المستردة المؤكدة؛ الربح للبيانات المسجلة = صافي المبيعات − التكاليف المطابقة − الرسوم المستوردة؛ الهامش = الربح للبيانات المسجلة ÷ صافي المبيعات. تُحسب الطلبات بتاريخ الطلب والاستردادات بتاريخ اكتمالها. تؤثر البيانات الناقصة في النتيجة.', [unallocatedKey]:'لا يمكن ربط __VARA__ من مبالغ الاسترداد أو الرسوم، بإجمالي __VARB__، بمنتج واحد في هذه الفترة. لم تُوزَّع على المنتجات، لكنها محتسبة في ربح المتجر.' },
};
OVERRIDES.fr['例如推广费、包装费等已录入支出。'] = 'Par exemple, les frais de publicité et d’emballage enregistrés.';
const DYNAMIC = {
  en: { periods:{'本月':'This month','本期':'This period','上月':'Last month'}, unknown:'profit or loss cannot yet be confirmed', empty:'no eligible sales have been recorded', even:'breaks even so far', profit:'estimated profit', loss:'estimated loss', scope:'Period', confirmClear:'Type CLEAR to remove all local data.', confirmReplace:'Type REPLACE to replace all current local data with this backup.', confirmUndo:'Type UNDO to remove this import batch.' },
  fr: { periods:{'本月':'Ce mois-ci','本期':'Cette période','上月':'Le mois dernier'}, unknown:'le résultat ne peut pas encore être confirmé', empty:'aucune vente admissible enregistrée', even:'résultat actuellement équilibré', profit:'bénéfice estimé', loss:'perte estimée', scope:'Période', confirmClear:'Saisissez CLEAR pour effacer les données locales.', confirmReplace:'Saisissez REPLACE pour remplacer les données locales par cette sauvegarde.', confirmUndo:'Saisissez UNDO pour annuler cet import.' },
  ru: { periods:{'本月':'В этом месяце','本期':'За этот период','上月':'В прошлом месяце'}, unknown:'прибыль или убыток пока нельзя подтвердить', empty:'учитываемых продаж пока нет', even:'пока без прибыли и убытка', profit:'расчётная прибыль', loss:'расчётный убыток', scope:'Период', confirmClear:'Введите CLEAR, чтобы удалить все локальные данные.', confirmReplace:'Введите REPLACE, чтобы заменить локальные данные резервной копией.', confirmUndo:'Введите UNDO, чтобы отменить этот импорт.' },
  es: { periods:{'本月':'Este mes','本期':'Este periodo','上月':'El mes pasado'}, unknown:'aún no se puede confirmar el beneficio o la pérdida', empty:'todavía no hay ventas computables', even:'por ahora no hay beneficio ni pérdida', profit:'beneficio estimado', loss:'pérdida estimada', scope:'Periodo', confirmClear:'Escribe CLEAR para borrar todos los datos locales.', confirmReplace:'Escribe REPLACE para sustituir los datos locales por esta copia.', confirmUndo:'Escribe UNDO para deshacer esta importación.' },
  ar: { periods:{'本月':'هذا الشهر','本期':'هذه الفترة','上月':'الشهر الماضي'}, unknown:'لا يمكن تأكيد الربح أو الخسارة بعد', empty:'لا توجد مبيعات مؤهلة مسجلة بعد', even:'لا يوجد ربح أو خسارة حتى الآن', profit:'الربح المقدر', loss:'الخسارة المقدرة', scope:'الفترة', confirmClear:'اكتب CLEAR لحذف جميع البيانات المحلية.', confirmReplace:'اكتب REPLACE لاستبدال البيانات المحلية بهذه النسخة الاحتياطية.', confirmUndo:'اكتب UNDO للتراجع عن دفعة الاستيراد.' },
};
Object.assign(DYNAMIC.en,{to:'to',demo:'Demo store (fictional)',sold:(n)=>`${n} sold`,margin:(m,a)=>`${m} margin · ${a} recorded profit`,badge:(p,a)=>`${p}: estimated loss on matched items ${a}`,lossLine:(n,a)=>`${n} products show an estimated loss of ${a} using matched items`});
Object.assign(DYNAMIC.fr,{to:'au',demo:'Boutique de démonstration (fictive)',sold:(n)=>`${n} vendus`,margin:(m,a)=>`Marge ${m} · bénéfice connu ${a}`,badge:(p,a)=>`${p} : perte estimée sur éléments associés ${a}`,lossLine:(n,a)=>`${n} produits affichent une perte estimée de ${a} selon les éléments associés`});
Object.assign(DYNAMIC.ru,{to:'—',demo:'Демо-магазин (вымышленные данные)',sold:(n)=>`продано: ${n}`,margin:(m,a)=>`Маржа ${m} · прибыль по известным данным ${a}`,badge:(p,a)=>`${p}: расчётный убыток по сопоставленным данным ${a}`,lossLine:(n,a)=>`${n} товаров: расчётный убыток по сопоставленным данным ${a}`});
Object.assign(DYNAMIC.es,{to:'a',demo:'Tienda de demostración (ficticia)',sold:(n)=>`${n} vendidos`,margin:(m,a)=>`Margen ${m} · beneficio registrado ${a}`,badge:(p,a)=>`${p}: pérdida estimada con datos asociados ${a}`,lossLine:(n,a)=>`${n} productos muestran una pérdida estimada de ${a} con datos asociados`});
Object.assign(DYNAMIC.ar,{to:'إلى',demo:'متجر تجريبي (بيانات افتراضية)',sold:(n)=>`المباع: ${n}`,margin:(m,a)=>`الهامش ${m} · الربح المسجل ${a}`,badge:(p,a)=>`${p}: الخسارة المقدرة للبيانات المطابقة ${a}`,lossLine:(n,a)=>`${n} من المنتجات تظهر خسارة مقدرة قدرها ${a} وفق البيانات المطابقة`});
Object.assign(DYNAMIC.en,{missing:'Missing',missingReport:(n,r)=>`${n} stores with orders have not imported a ${r} for this period`,knownAmount:(a)=>`Recorded items leave ${a}; this is not final profit`});
Object.assign(DYNAMIC.fr,{missing:'Données manquantes',missingReport:(n,r)=>`${n} boutiques avec des commandes n’ont pas importé ${r} pour cette période`,knownAmount:(a)=>`Les éléments enregistrés laissent ${a} ; ce n’est pas le bénéfice final`});
Object.assign(DYNAMIC.ru,{missing:'Не хватает данных',missingReport:(n,r)=>`Для ${n} магазинов с заказами не импортирован ${r} за этот период`,knownAmount:(a)=>`По известным данным остаётся ${a}; это не окончательная прибыль`});
Object.assign(DYNAMIC.es,{missing:'Faltan datos',missingReport:(n,r)=>`${n} tiendas con pedidos no han importado ${r} para este periodo`,knownAmount:(a)=>`Los datos registrados dejan ${a}; no es el beneficio final`});
Object.assign(DYNAMIC.ar,{missing:'البيانات الناقصة',missingReport:(n,r)=>`${n} من المتاجر التي لديها طلبات لم تستورد ${r} لهذه الفترة`,knownAmount:(a)=>`المتبقي وفق البيانات المسجلة ${a}؛ وهذا ليس الربح النهائي`});
Object.assign(DYNAMIC.en,{lossHeading:(n,a)=>`Products with estimated losses · ${n} · total ${a}`,missingHeading:(n)=>`Cannot determine yet · ${n} products missing costs`,allocation:(n)=>`Only clearly matched product refunds and fees are included; ${n} records could not be assigned to a product.`});
Object.assign(DYNAMIC.fr,{lossHeading:(n,a)=>`Produits en perte estimée · ${n} · total ${a}`,missingHeading:(n)=>`Résultat indéterminé · ${n} produits sans coût`,allocation:(n)=>`Seuls les remboursements et frais clairement associés sont inclus ; ${n} lignes n’ont pas pu être attribuées à un produit.`});
Object.assign(DYNAMIC.ru,{lossHeading:(n,a)=>`Товары с расчётным убытком · ${n} · всего ${a}`,missingHeading:(n)=>`Пока нельзя определить · ${n} товаров без себестоимости`,allocation:(n)=>`Учтены только однозначно сопоставленные возвраты и расходы; ${n} записей нельзя отнести к товару.`});
Object.assign(DYNAMIC.es,{lossHeading:(n,a)=>`Productos con pérdida estimada · ${n} · total ${a}`,missingHeading:(n)=>`Aún no se puede determinar · ${n} productos sin coste`,allocation:(n)=>`Solo se incluyen reembolsos y gastos asociados claramente; ${n} registros no se pudieron atribuir a un producto.`});
Object.assign(DYNAMIC.ar,{lossHeading:(n,a)=>`منتجات ذات خسارة مقدرة · ${n} · الإجمالي ${a}`,missingHeading:(n)=>`لا يمكن التحديد بعد · ${n} منتجات بلا تكلفة`,allocation:(n)=>`تُحتسب الاستردادات والرسوم المرتبطة بمنتج بوضوح فقط؛ تعذر إسناد ${n} سجلات إلى منتج.`});
Object.assign(OVERRIDES.en,{'模拟配件店（虚构数据）':DYNAMIC.en.demo,'轻薄防摔手机壳':'Slim protective phone case','Type-C 快充线':'Type-C fast-charging cable','折叠手机支架':'Foldable phone stand','屏幕清洁套装':'Screen cleaning kit'});
Object.assign(OVERRIDES.fr,{'模拟配件店（虚构数据）':DYNAMIC.fr.demo,'轻薄防摔手机壳':'Coque fine de protection','Type-C 快充线':'Câble de charge rapide Type-C','折叠手机支架':'Support de téléphone pliable','屏幕清洁套装':'Kit de nettoyage d’écran'});
Object.assign(OVERRIDES.ru,{'模拟配件店（虚构数据）':DYNAMIC.ru.demo,'轻薄防摔手机壳':'Тонкий защитный чехол','Type-C 快充线':'Кабель быстрой зарядки Type-C','折叠手机支架':'Складная подставка для телефона','屏幕清洁套装':'Набор для очистки экрана'});
Object.assign(OVERRIDES.es,{'模拟配件店（虚构数据）':DYNAMIC.es.demo,'轻薄防摔手机壳':'Funda protectora delgada','Type-C 快充线':'Cable de carga rápida Type-C','折叠手机支架':'Soporte plegable para móvil','屏幕清洁套装':'Kit de limpieza de pantalla'});
Object.assign(OVERRIDES.ar,{'模拟配件店（虚构数据）':DYNAMIC.ar.demo,'轻薄防摔手机壳':'غطاء هاتف رفيع للحماية','Type-C 快充线':'كابل شحن سريع Type-C','折叠手机支架':'حامل هاتف قابل للطي','屏幕清洁套装':'مجموعة تنظيف الشاشة'});
const REPORT_TERMS = {
  '项目':['Item','Élément','Показатель','Concepto','البند'],
  '实际到账':['Platform payout','Versement de la plateforme','Выплата платформы','Pago de la plataforma','المبلغ المدفوع من المنصة'],
  '计入订单':['Orders counted','Commandes prises en compte','Учтённые заказы','Pedidos incluidos','الطلبات المحتسبة'],
  '售出商品':['Items sold','Articles vendus','Продано товаров','Artículos vendidos','المنتجات المباعة'],
  '这份报告怎么看':['How to read this report','Lire ce rapport','Как читать отчёт','Cómo leer este informe','كيفية قراءة هذا التقرير'],
  '商品销售额':['Product sales','Ventes de produits','Продажи товаров','Ventas de productos','مبيعات المنتجات'],
  '净销售额':['Net sales','Ventes nettes','Чистые продажи','Ventas netas','صافي المبيعات'],
  '预计利润':['Estimated profit','Bénéfice estimé','Расчётная прибыль','Beneficio estimado','الربح المقدر'],
  '预计利润率':['Estimated profit margin','Marge estimée','Расчётная маржа','Margen estimado','هامش الربح المقدر'],
  '已知项目利润':['Profit from recorded items','Bénéfice des éléments connus','Прибыль по известным данным','Beneficio con datos registrados','ربح البيانات المسجلة'],
  '已匹配成本':['Matched cost','Coût associé','Сопоставленная себестоимость','Coste asociado','التكلفة المطابقة'],
  '已匹配退款及费用':['Matched refunds and fees','Remboursements et frais associés','Сопоставленные возвраты и расходы','Reembolsos y gastos asociados','الاستردادات والرسوم المطابقة'],
  '本期相关的导入记录':['Imports for this period','Imports de la période','Импорт за этот период','Importaciones del periodo','الواردات لهذه الفترة'],
  '退款、费用和实际到账':['Refunds, fees and payouts','Remboursements, frais et versements','Возвраты, расходы и выплаты','Reembolsos, gastos y pagos','الاستردادات والرسوم والمدفوعات'],
  '数据情况':['Data status','État des données','Состояние данных','Estado de los datos','حالة البيانات'],
  '记录类型':['Record type','Type d’enregistrement','Тип записи','Tipo de registro','نوع السجل'],
  '预计亏损（元）':['Estimated loss (CNY)','Perte estimée (CNY)','Расчётный убыток (CNY)','Pérdida estimada (CNY)','الخسارة المقدرة (يوان)'],
};
for(const [key,values] of Object.entries(REPORT_TERMS)) ['en','fr','ru','es','ar'].forEach((language,index)=>{OVERRIDES[language][key]=values[index];});
Object.assign(DYNAMIC.en,{change:'Change language',issueStatus:(id,status)=>`Order ${id} has an unrecognized status “${status}” and is not included in sales.`,issueCost:(sku,start,end,n)=>`Product ${sku} has no purchase cost from ${start} to ${end}; ${n} items are affected and profit is incomplete.`});
Object.assign(DYNAMIC.fr,{change:'Changer de langue',issueStatus:(id,status)=>`Le statut « ${status} » de la commande ${id} n’est pas reconnu et la commande n’est pas incluse dans les ventes.`,issueCost:(sku,start,end,n)=>`Le coût du produit ${sku} manque du ${start} au ${end} ; ${n} articles sont concernés et le bénéfice est incomplet.`});
Object.assign(DYNAMIC.ru,{change:'Сменить язык',issueStatus:(id,status)=>`Статус «${status}» заказа ${id} не распознан; заказ не включён в продажи.`,issueCost:(sku,start,end,n)=>`Для товара ${sku} отсутствует себестоимость с ${start} по ${end}; затронуто ${n} единиц, прибыль рассчитана неполно.`});
Object.assign(DYNAMIC.es,{change:'Cambiar idioma',issueStatus:(id,status)=>`El estado «${status}» del pedido ${id} no se reconoce y el pedido no se incluye en las ventas.`,issueCost:(sku,start,end,n)=>`Falta el coste de ${sku} desde ${start} hasta ${end}; afecta a ${n} unidades y el beneficio está incompleto.`});
Object.assign(DYNAMIC.ar,{change:'تغيير اللغة',issueStatus:(id,status)=>`حالة الطلب ${id} «${status}» غير معروفة، ولم يُحتسب ضمن المبيعات.`,issueCost:(sku,start,end,n)=>`تكلفة المنتج ${sku} غير متوفرة من ${start} إلى ${end}؛ يتأثر ${n} منتجاً وحساب الربح غير مكتمل.`});
Object.assign(DYNAMIC.en,{soldMissing:(sku,n)=>`${sku} · ${n} sold · missing cost; profit may be overstated`,batchInfo:(d,e)=>`${d} duplicates skipped; ${e} rows need review. Batch details stay in this browser.`, earliest:(store,sku,date)=>`${store} · ${sku} · earliest unmatched ${date}`,importConfirm:(a,d,e)=>`Save ${a} new records, skip ${d} duplicates and flag ${e} rows for review? The original file is not uploaded or saved.`,undoConfirm:(file,counts)=>`Undo “${file}”? Records in this batch: ${counts}. These records will be deleted and totals recalculated. Back up first. Undo will be blocked if other batches depend on these orders. Continue?`,restoreConfirm:(counts)=>`This backup will replace the current browser data. It contains: ${counts}. Download a backup of current data first. Continue?`,costConfirm:(sku,date,price)=>`Changing ${sku} purchase cost recalculates historical profits. Confirm the effective date ${date} and price ${price}. Continue?`});
Object.assign(DYNAMIC.fr,{soldMissing:(sku,n)=>`${sku} · ${n} vendus · coût manquant ; bénéfice possiblement surestimé`,batchInfo:(d,e)=>`${d} doublons ignorés ; ${e} lignes à vérifier. Les détails restent dans ce navigateur.`,earliest:(store,sku,date)=>`${store} · ${sku} · première date sans coût ${date}`,importConfirm:(a,d,e)=>`Enregistrer ${a} nouvelles lignes, ignorer ${d} doublons et signaler ${e} lignes à vérifier ? Le fichier original n’est ni envoyé ni conservé.`,undoConfirm:(file,counts)=>`Annuler « ${file} » ? Lignes du lot : ${counts}. Elles seront supprimées et les totaux recalculés. Sauvegardez d’abord. L’annulation est bloquée si d’autres lots dépendent de ces commandes. Continuer ?`,restoreConfirm:(counts)=>`Cette sauvegarde remplacera les données actuelles du navigateur. Contenu : ${counts}. Sauvegardez d’abord les données actuelles. Continuer ?`,costConfirm:(sku,date,price)=>`Modifier le coût de ${sku} recalcule les bénéfices passés. Confirmez la date ${date} et le prix ${price}. Continuer ?`});
Object.assign(DYNAMIC.ru,{soldMissing:(sku,n)=>`${sku} · продано ${n} · нет себестоимости; прибыль может быть завышена`,batchInfo:(d,e)=>`Пропущено дубликатов: ${d}; требуют проверки: ${e}. Сведения хранятся в этом браузере.`,earliest:(store,sku,date)=>`${store} · ${sku} · первая дата без себестоимости: ${date}`,importConfirm:(a,d,e)=>`Сохранить ${a} новых записей, пропустить ${d} дубликатов и отметить ${e} строк для проверки? Исходный файл не загружается и не сохраняется.`,undoConfirm:(file,counts)=>`Отменить «${file}»? Записи пакета: ${counts}. Они будут удалены, итоги пересчитаны. Сначала создайте резервную копию. Если другие пакеты связаны с заказами, отмена будет заблокирована. Продолжить?`,restoreConfirm:(counts)=>`Эта копия заменит текущие данные браузера. Содержимое: ${counts}. Сначала сохраните текущую резервную копию. Продолжить?`,costConfirm:(sku,date,price)=>`Изменение себестоимости ${sku} пересчитает прошлую прибыль. Проверьте дату ${date} и цену ${price}. Продолжить?`});
Object.assign(DYNAMIC.es,{soldMissing:(sku,n)=>`${sku} · ${n} vendidos · falta el coste; el beneficio puede estar sobreestimado`,batchInfo:(d,e)=>`${d} duplicados omitidos; ${e} filas por revisar. Los detalles permanecen en este navegador.`,earliest:(store,sku,date)=>`${store} · ${sku} · primera fecha sin coste ${date}`,importConfirm:(a,d,e)=>`¿Guardar ${a} registros nuevos, omitir ${d} duplicados y marcar ${e} filas para revisión? El archivo original no se sube ni se guarda.`,undoConfirm:(file,counts)=>`¿Deshacer «${file}»? Registros del lote: ${counts}. Se borrarán y se recalcularán los totales. Haz primero una copia. Si otros lotes dependen de estos pedidos, se bloqueará la operación. ¿Continuar?`,restoreConfirm:(counts)=>`Esta copia sustituirá los datos actuales del navegador. Contenido: ${counts}. Guarda primero una copia de los datos actuales. ¿Continuar?`,costConfirm:(sku,date,price)=>`Cambiar el coste de ${sku} recalcula los beneficios anteriores. Confirma la fecha ${date} y el precio ${price}. ¿Continuar?`});
Object.assign(DYNAMIC.ar,{soldMissing:(sku,n)=>`${sku} · المباع ${n} · التكلفة ناقصة وقد يكون الربح مبالغاً فيه`,batchInfo:(d,e)=>`تم تجاوز ${d} مكرر؛ ${e} صفوف تحتاج إلى مراجعة. تبقى تفاصيل الدفعة في هذا المتصفح.`,earliest:(store,sku,date)=>`${store} · ${sku} · أول تاريخ بلا تكلفة مطابقة ${date}`,importConfirm:(a,d,e)=>`حفظ ${a} سجلات جديدة وتجاوز ${d} مكررة ووضع ${e} صفوف للمراجعة؟ لا يُرفع الملف الأصلي ولا يُحفظ.`,undoConfirm:(file,counts)=>`التراجع عن «${file}»؟ سجلات الدفعة: ${counts}. ستُحذف ويُعاد حساب الإجماليات. احفظ نسخة احتياطية أولاً. ستُمنع العملية إذا ارتبطت دفعات أخرى بهذه الطلبات. هل تريد المتابعة؟`,restoreConfirm:(counts)=>`ستستبدل هذه النسخة بيانات المتصفح الحالية. المحتويات: ${counts}. احفظ نسخة من البيانات الحالية أولاً. هل تريد المتابعة؟`,costConfirm:(sku,date,price)=>`تغيير تكلفة ${sku} يعيد حساب الأرباح السابقة. تأكد من تاريخ السريان ${date} والسعر ${price}. هل تريد المتابعة؟`});
for(const [lang,value] of Object.entries({en:'Last __VARA__ days',fr:'__VARA__ derniers jours',ru:'Последние __VARA__ дней',es:'Últimos __VARA__ días',ar:'آخر __VARA__ أيام'})) OVERRIDES[lang]['近 __VARA__ 天']=value;
for(const [lang,value] of Object.entries({en:'Supports .csv, .tsv, .xls, .xlsx and .xlsm. Only the first Excel sheet is read; each file can be up to __VARA__ MB.',fr:'Formats .csv, .tsv, .xls, .xlsx et .xlsm pris en charge. Seule la première feuille Excel est lue ; taille maximale : __VARA__ Mo.',ru:'Поддерживаются .csv, .tsv, .xls, .xlsx и .xlsm. Читается только первый лист Excel; размер файла — до __VARA__ МБ.',es:'Admite .csv, .tsv, .xls, .xlsx y .xlsm. Solo se lee la primera hoja de Excel; máximo __VARA__ MB por archivo.',ar:'يدعم .csv و.tsv و.xls و.xlsx و.xlsm. تُقرأ ورقة Excel الأولى فقط؛ الحد الأقصى للملف __VARA__ ميغابايت.'})) OVERRIDES[lang]['支持 .csv、.tsv、.xls、.xlsx、.xlsm；Excel 仅读取第一个工作表，每个文件最大 __VARA__ MB。']=value;
for(const [lang,value] of Object.entries({en:'The sample is saved as a separate demo store and will not overwrite your own stores or orders.',fr:'L’exemple est enregistré dans une boutique de démonstration distincte et ne remplace pas vos données.',ru:'Образец сохраняется в отдельном демо-магазине и не заменяет ваши магазины или заказы.',es:'El ejemplo se guarda en una tienda de demostración independiente y no sustituye tus datos.',ar:'تُحفظ العينة في متجر تجريبي منفصل ولا تستبدل متاجرك أو طلباتك.'})) OVERRIDES[lang]['样例会放在单独的演示店铺里，不会覆盖你的店铺和订单。']=value;
const currencyLabels = {
  '人民币（CNY）':['Chinese yuan (CNY)','Yuan chinois (CNY)','Китайский юань (CNY)','Yuan chino (CNY)','اليوان الصيني (CNY)'],
  '美元（USD）':['US dollar (USD)','Dollar américain (USD)','Доллар США (USD)','Dólar estadounidense (USD)','الدولار الأمريكي (USD)'],
  '欧元（EUR）':['Euro (EUR)','Euro (EUR)','Евро (EUR)','Euro (EUR)','اليورو (EUR)'],
  '英镑（GBP）':['Pound sterling (GBP)','Livre sterling (GBP)','Фунт стерлингов (GBP)','Libra esterlina (GBP)','الجنيه الإسترليني (GBP)'],
  '加拿大元（CAD）':['Canadian dollar (CAD)','Dollar canadien (CAD)','Канадский доллар (CAD)','Dólar canadiense (CAD)','الدولار الكندي (CAD)'],
  '澳大利亚元（AUD）':['Australian dollar (AUD)','Dollar australien (AUD)','Австралийский доллар (AUD)','Dólar australiano (AUD)','الدولار الأسترالي (AUD)'],
  '沙特里亚尔（SAR）':['Saudi riyal (SAR)','Riyal saoudien (SAR)','Саудовский риял (SAR)','Riyal saudí (SAR)','الريال السعودي (SAR)'],
  '每件进货价（店铺币种）':['Purchase cost per item (store currency)','Coût unitaire (devise de la boutique)','Цена закупки за единицу (валюта магазина)','Coste unitario (moneda de la tienda)','تكلفة القطعة (عملة المتجر)'],
  '各平台报表尚未使用真实脱敏样本验证，选平台仅用于分类，不会连接账号。每个店铺只使用一种币种，不自动换汇；导入金额、成本和费用须均为该币种。':['Platform reports have not been verified against real anonymized samples. The platform is only a label; no account is connected. Each store uses one currency; no conversion occurs. All imported amounts, costs and fees must use that currency.','Les rapports de plateforme ne sont pas encore vérifiés sur des exemples réels anonymisés. La plateforme sert uniquement de catégorie, sans connexion au compte. Une seule devise par boutique, sans conversion ; montants, coûts et frais importés doivent utiliser cette devise.','Отчёты площадок ещё не проверены на реальных обезличенных примерах. Площадка служит только меткой; подключение к аккаунту не выполняется. Для магазина используется одна валюта без конвертации; все суммы, затраты и комиссии должны быть в ней.','Los informes aún no se han verificado con muestras reales anonimizadas. La plataforma solo sirve como categoría y no conecta ninguna cuenta. Cada tienda usa una moneda, sin conversión; importa todos los importes, costes y gastos en esa moneda.','لم تُتحقق تقارير المنصات بعد باستخدام عينات حقيقية منزوعة الهوية. المنصة للتصنيف فقط ولا يتم ربط الحساب. يستخدم كل متجر عملة واحدة دون تحويل؛ يجب أن تكون المبالغ والتكاليف والرسوم المستوردة بالعملة نفسها.'],
  '所有平台的真实报表格式尚未验证，请检查列映射。金额必须与店铺币种一致，不自动换汇；小数请用点号，避免逗号造成误读。数量也用点号且不要加千位分隔符。日期请使用 YYYY-MM-DD；含糊的日/月日期会要求你先改清楚。Excel 仅读取第一个工作表。':['Platform report formats have not been verified; check the column mapping. Amounts must match the store currency; no exchange conversion is made. Use a decimal point to avoid ambiguous commas. Use a decimal point for fractional quantities and do not add thousands separators. Use YYYY-MM-DD dates; ambiguous day/month dates must be corrected. Only the first worksheet is read.','Les formats des rapports n’ont pas été vérifiés ; contrôlez les colonnes. Les montants doivent correspondre à la devise de la boutique, sans conversion. Utilisez un point décimal pour éviter toute ambiguïté. Pour les quantités fractionnaires, utilisez un point et aucun séparateur de milliers. Utilisez les dates AAAA-MM-JJ ; corrigez les dates ambiguës. Seule la première feuille est lue.','Форматы отчетов не проверены; проверьте сопоставление столбцов. Суммы должны соответствовать валюте магазина, без конвертации. Используйте десятичную точку, чтобы избежать неоднозначности. Для дробного количества используйте точку без разделителя тысяч. Даты вводите в формате ГГГГ-ММ-ДД; неоднозначные даты нужно исправить. Читается только первый лист.','Los formatos de los informes no están verificados; revisa las columnas. Los importes deben coincidir con la moneda de la tienda; no se convierten. Usa punto decimal para evitar ambigüedades. Para cantidades fraccionarias usa punto y no añadas separadores de miles. Usa fechas AAAA-MM-DD y corrige las ambiguas. Solo se lee la primera hoja.','لم تُتحقق صيغ التقارير؛ راجع مطابقة الأعمدة. يجب أن تطابق المبالغ عملة المتجر ولا يتم تحويلها. استخدم النقطة العشرية لتجنب الالتباس. استخدم النقطة للكميات الكسرية ولا تضف فواصل الآلاف. استخدم التاريخ بصيغة YYYY-MM-DD وصحح التواريخ الملتبسة. تُقرأ ورقة العمل الأولى فقط.'],
  'CSV 文件文字编码':['CSV text encoding','Encodage du texte CSV','Кодировка текста CSV','Codificación de texto CSV','ترميز نص CSV'],
  '自动（UTF-8 / 简体中文）':['Auto (UTF-8 / Simplified Chinese)','Automatique (UTF-8 / chinois simplifié)','Авто (UTF-8 / упрощённый китайский)','Automático (UTF-8 / chino simplificado)','تلقائي (UTF-8 / الصينية المبسطة)'],
  '西欧 Windows-1252':['Western European Windows-1252','Europe occidentale Windows-1252','Западноевропейская Windows-1252','Europa occidental Windows-1252','أوروبا الغربية Windows-1252'],
  '俄语 Windows-1251':['Russian Windows-1251','Russe Windows-1251','Русская Windows-1251','Ruso Windows-1251','الروسية Windows-1251'],
  '阿拉伯语 Windows-1256':['Arabic Windows-1256','Arabe Windows-1256','Арабская Windows-1256','Árabe Windows-1256','العربية Windows-1256'],
  '自动（UTF-8 / 自动识别）':['Auto (UTF-8 / detect automatically)','Auto (UTF-8 / détection automatique)','Авто (UTF-8 / автоопределение)','Auto (UTF-8 / detección automática)','تلقائي (UTF-8 / اكتشاف تلقائي)'],
  '简体中文 GB18030':['Simplified Chinese GB18030','Chinois simplifié GB18030','Упрощённый китайский GB18030','Chino simplificado GB18030','الصينية المبسطة GB18030'],
  'UTF-8':['UTF-8','UTF-8','UTF-8','UTF-8','UTF-8'],
  '日期格式不明确或无法识别：__VARA__。请改成 YYYY-MM-DD，例如 __VARB__；含糊的日/月格式不会猜测。':['Date is unclear or unsupported: __VARA__. Use YYYY-MM-DD, for example __VARB__. Ambiguous day/month dates are never guessed.','Date ambiguë ou non reconnue : __VARA__. Utilisez AAAA-MM-JJ, par exemple __VARB__. Les dates ambiguës ne sont jamais devinées.','Неоднозначная или неподдерживаемая дата: __VARA__. Используйте ГГГГ-ММ-ДД, например __VARB__. Неоднозначные даты не угадываются.','Fecha ambigua o no reconocida: __VARA__. Usa AAAA-MM-DD, por ejemplo __VARB__. No se adivinan fechas ambiguas.','التاريخ غير واضح أو غير مدعوم: __VARA__. استخدم YYYY-MM-DD، مثل __VARB__. لن يتم تخمين التواريخ الملتبسة.'],
};
for (const [key, values] of Object.entries(currencyLabels)) ['en','fr','ru','es','ar'].forEach((lang, i) => { OVERRIDES[lang][key] = values[i]; });

// Complete original flag files are bundled locally; no flag is redrawn or cropped.
function flag(code) { return `<img class="language-flag" src="./flags/${code}.svg" alt="" aria-hidden="true">`; }
function normalized(text) {
  const values=[];
  const key=String(text).trim().replace(/\s+/g,' ').replace(/(?:[¥￥]\s*[+\-]?\d[\d,]*(?:\.\d+)?)|(?:\d{4}[-\/]\d{1,2}[-\/]\d{1,2}(?:\s+\d{1,2}:\d{2})?)|(?:\d[\d,]*(?:\.\d+)?%?)/g,(value)=>{ const token=`__VAR${String.fromCharCode(65+values.length)}__`; values.push([token,value]); return token; });
  return {key,values};
}
function translatedDynamic(text, lang) {
  const rules=DYNAMIC[lang]; if (!rules) return null;
  let tourMatch = String(text).trim().match(/^第 (\d+) 步，共 (\d+) 步$/);
  if (tourMatch) return tourMessages[lang].step(tourMatch[1], tourMatch[2]);
  tourMatch = String(text).trim().match(/^请点击高亮的“(.+)”继续$/);
  if (tourMatch) return tourMessages[lang].prompt(translateText(tourMatch[1], lang));
  tourMatch = String(text).trim().match(/^点击高亮的(.+)继续$/);
  if (tourMatch) return tourMessages[lang].aria(translateText(tourMatch[1], lang));
  let m=String(text).trim().match(/^(本月|本期|上月)(暂时无法确认赚亏|暂时没有可计入的销售金额|暂时打平)$/);
  if(m) { const kind=m[2]==='暂时无法确认赚亏'?'unknown':m[2]==='暂时打平'?'even':'empty'; return `${rules.periods[m[1]]}: ${rules[kind]}`; }
  m=String(text).trim().match(/^(本月|本期|上月)预计(赚了|亏了)\s*((?:¥|(?:USD|EUR|GBP|AUD|CAD|SAR)\s)[-\d,.]+)$/);
  if(m) return `${rules.periods[m[1]]}: ${m[2]==='赚了'?rules.profit:rules.loss} ${m[3]}`;
  m=String(text).trim().match(/^(本月|本期|上月)暂时无法确认赚亏；已知项目相减后为\s*((?:¥|(?:USD|EUR|GBP|AUD|CAD|SAR)\s)[-\d,.]+)$/);
  if(m) return `${rules.periods[m[1]]}: ${rules.unknown}; ${rules.knownAmount(m[2])}`;
  m=String(text).trim().match(/^(\d+) 个有订单的店铺这段时间没有导入(退款表|平台扣费表|其他支出表)$/);
  if(m) return rules.missingReport(m[1],translateText(m[2],lang));
  m=String(text).trim().match(/^还缺：(.+)。$/);
  if(m) return `${rules.missing}: ${m[1].split('；').map((part)=>translateText(part,lang)).join('; ')}.`;
  m=String(text).trim().match(/^本助手(本月|本期|上月)已匹配项目预计亏损\s*((?:¥|(?:USD|EUR|GBP|AUD|CAD|SAR)\s)[-\d,.]+)$/);
  if(m) return rules.badge(rules.periods[m[1]],m[2]);
  m=String(text).trim().match(/^(\d+) 件商品按已匹配项目预计亏损\s*((?:¥|(?:USD|EUR|GBP|AUD|CAD|SAR)\s)[-\d,.]+)$/);
  if(m) return rules.lossLine(m[1],m[2]);
  m=String(text).trim().match(/^亏钱商品清单 · (\d+) 件 · 合计亏\s*((?:¥|(?:USD|EUR|GBP|AUD|CAD|SAR)\s)[-\d,.]+)$/);
  if(m) return rules.lossHeading(m[1],m[2]);
  m=String(text).trim().match(/^暂时不能判断 · (\d+) 件商品缺少成本$/);
  if(m) return rules.missingHeading(m[1]);
  m=String(text).trim().match(/^只计入能明确匹配单个商品的退款和费用；另有 (\d+) 条无法归属商品。$/);
  if(m) return rules.allocation(m[1]);
  m=String(text).trim().match(/^只计入明确匹配商品的退款和费用；(\d+) 条无法归属商品的款项未分摊。缺成本时暂不能判断。$/);
  if(m) return `${rules.allocation(m[1])} ${translateText('缺少成本，暂无法判断',lang)}`;
  m=String(text).trim().match(/^订单\s+(.+?)\s+的状态“(.+?)”(?:未识别，未计入销售|无法识别，默认没有计入销售)。$/);
  if(m) return rules.issueStatus(m[1],m[2]);
  m=String(text).trim().match(/^商品编号 (.+?) 在 (\d{4}-\d{2}-\d{2}) 至 (\d{4}-\d{2}-\d{2}) 没有填写进货价；涉及 ([\d.]+) 件商品，利润暂不完整。$/);
  if(m) return rules.issueCost(m[1],m[2],m[3],m[4]);
  if(String(text).trim()==='模拟配件店（虚构数据） · 其他/演示') return `${rules.demo} · ${translateText('其他/演示',lang)}`;
  m=String(text).trim().match(/^(.+?) · 售出 ([\d,.]+) 件$/);
  if(m) return `${m[1]} · ${rules.sold(m[2])}`;
  m=String(text).trim().match(/^(.+?) · 售出 ([\d,.]+) 件 · 没填成本，结果可能偏高$/);
  if(m) return rules.soldMissing(m[1],m[2]);
  m=String(text).trim().match(/^([\d.,]+%) 利润率 · ((?:¥|(?:USD|EUR|GBP|AUD|CAD|SAR)\s)[-\d,.]+) 利润$/);
  if(m) return rules.margin(m[1],m[2]);
  m=String(text).trim().match(/^跳过重复 (\d+) 条；待检查 (\d+) 条。批次信息仅保存在当前浏览器。$/);
  if(m) return rules.batchInfo(m[1],m[2]);
  m=String(text).trim().match(/^(.+?) · (.+?) · 最早未匹配 (\d{4}-\d{2}-\d{2})$/);
  if(m) return rules.earliest(m[1]==='模拟配件店（虚构数据）'?rules.demo:m[1],m[2],m[3]);
  m=String(text).trim().match(/^将保存 (\d+) 条新记录，跳过 (\d+) 条重复记录，另有 (\d+) 行需要检查。[\s\S]*要继续吗？$/);
  if(m) return rules.importConfirm(m[1],m[2],m[3]);
  m=String(text).trim().match(/^准备撤销“(.+?)”。该批次保存的记录：(.+?)。[\s\S]*继续吗？$/);
  if(m) return rules.undoConfirm(m[1],m[2].split('、').map((part)=>translateText(part,lang)).join(', '));
  m=String(text).trim().match(/^备份文件可以使用。恢复后会替换当前浏览器里的数据。[\s\S]*?文件里有：(.+?)[\s\S]*要继续吗？$/);
  if(m) return rules.restoreConfirm(m[1].split('，').map((part)=>translateText(part,lang)).join(', '));
  m=String(text).trim().match(/^修改 (.+?) 的进货价会重新计算相关历史订单的利润。请确认生效日期 (\d{4}-\d{2}-\d{2}) 和价格 ((?:¥|(?:USD|EUR|GBP|AUD|CAD|SAR)\s)[-\d,.]+) 正确。继续吗？$/);
  if(m) return rules.costConfirm(m[1],m[2],m[3]);
  m=String(text).trim().match(/^(店铺|订单|商品明细|退款|平台扣费|商品成本|其他支出|到账记录|导入记录|待处理问题) (\d+) 条$/);
  if(m) return `${translateText(m[1],lang)}: ${m[2]}`;
  m=String(text).trim().match(/^统计范围：(.+?)\s*·\s*(.+)$/);
  if(m) return `${rules.scope}: ${m[1].replace(' 至 ',` ${rules.to} `)} · ${m[2]==='模拟配件店（虚构数据）'?rules.demo:m[2]}`;
  return null;
}
export function translateText(value, language=currentLanguage) {
  const original=String(value??''); if(language==='zh-CN'||!/[\u3400-\u9fff]/.test(original)) return original;
  const leading=original.match(/^\s*/)?.[0]||''; const trailing=original.match(/\s*$/)?.[0]||'';
  const trimmed=original.trim(); const dynamic=translatedDynamic(trimmed,language);
  if(dynamic!==null) return leading+dynamic+trailing;
  const {key,values}=normalized(trimmed);
  const dict=CATALOGS.get(language)||{};
  const exact = (OVERRIDES[language]||{})[trimmed] ?? dict[trimmed];
  if (exact !== undefined) return leading + exact + trailing;
  let result=(OVERRIDES[language]||{})[key] ?? dict[key];
  if(result!==undefined) {
    for(const [token,number] of values) result=result.replaceAll(token,number);
    return leading+result+trailing;
  }
  // Compose only from complete, known interface fragments. The source text is
  // still kept separately, so switching back restores the exact original.
  result=trimmed;
  const fragments=FRAGMENTS.get(language)||[];
  for(const part of fragments) if(result.includes(part)) result=result.split(part).join((OVERRIDES[language]||{})[part] ?? dict[part]);
  return leading+result+trailing;
}
export function getLanguage() { return currentLanguage; }
export function isLanguage(code) { return LANGUAGES.some((item)=>item.code===code); }
// Respect a previously saved choice. Unknown browser languages fall back to English.
export function resolveLanguage(saved, preferred = []) {
  if (isLanguage(saved)) return saved;
  for (const raw of preferred) {
    const tag = String(raw || '').toLowerCase().replaceAll('_', '-');
    if (tag === 'zh' || tag.startsWith('zh-')) return 'zh-CN';
    const base = tag.split('-')[0];
    if (isLanguage(base)) return base;
  }
  return 'en';
}
export function translateGeneratedIssue(value, language=currentLanguage) {
  return language === 'zh-CN' ? String(value ?? '') : translatedDynamic(String(value ?? ''), language) ?? String(value ?? '');
}

function skipElement(el) {
  if (!el) return true;
  if (el.dataset?.demoName === 'true' || el.dataset?.i18nSystem === 'true') return false;
  if (el.closest('script,style,[translate="no"],textarea,.mapping-preview,tbody,.store-card h2,.loss-product-name strong,.thin-product-row strong,.uncertain-product-row strong,.missing-cost-row strong,.rank-product-copy strong,.recent-batch summary span,.file-meta strong')) return true;
  if (el.tagName === 'OPTION') {
    const select=el.parentElement;
    if (select?.matches('#import-store,#cost-store,[data-map-field]')) return true;
    if (select?.id==='global-store-select' && el.value!=='all') return true;
  }
  return false;
}
function applyTranslation(root=document.body) {
  if (!root) return;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT); let node;
  while((node=walker.nextNode())) {
    if(skipElement(node.parentElement)) continue;
    const current=node.nodeValue; let entry=sources.get(node);
    if(!entry||entry.output!==current) entry={source:current,output:current};
    const output=node.parentElement?.closest('[data-generated-issue]') ? translateGeneratedIssue(entry.source) : translateText(entry.source);
    sources.set(node,{source:entry.source,output});
    if(output!==current) node.nodeValue=output;
  }
  const els=[...(root.nodeType===1?[root]:[]),...(root.querySelectorAll?.('[placeholder],[aria-label],[title]')||[])];
  for(const el of els) {
    if(skipElement(el)||el.id==='cost-product') continue;
    const prior=attributes.get(el)||{};
    for(const key of ['placeholder','aria-label','title']) {
      if(!el.hasAttribute?.(key)) continue;
      const current=el.getAttribute(key); let entry=prior[key];
      if(!entry||entry.output!==current) entry={source:current,output:current};
      const output=translateText(entry.source); prior[key]={source:entry.source,output};
      if(output!==current) el.setAttribute(key,output);
    }
    attributes.set(el,prior);
  }
}
export async function loadCatalog(lang) {
  if(lang==='zh-CN'||CATALOGS.has(lang)) return;
  const response=await fetch(new URL(`./locales/${lang}.json`,import.meta.url));
  if(!response.ok) throw new Error(`Language file could not be loaded (${response.status}).`);
  const catalog=await response.json();
  const simpleLabels = {
    en: ['See earnings','To-do','More','My stores','Purchase prices','All records','Backup and restore','Help','Start','Try an example','Maybe later'],
    fr: ['Voir les gains','À faire','Plus','Mes boutiques','Prix d’achat','Tous les enregistrements','Sauvegarde et restauration','Aide','Commencer','Essayer un exemple','Plus tard'],
    ru: ['Доход','Задачи','Ещё','Мои магазины','Закупочные цены','Все записи','Резервная копия','Помощь','Начать','Попробовать пример','Позже'],
    es: ['Ver ganancias','Pendientes','Más','Mis tiendas','Precios de compra','Todos los registros','Copia y restauración','Ayuda','Empezar','Probar un ejemplo','Más tarde'],
    ar: ['عرض الأرباح','المهام','المزيد','متاجري','أسعار الشراء','كل السجلات','النسخ والاستعادة','المساعدة','ابدأ','جرّب المثال','لاحقاً']
  };
  const simpleKeys = ['看赚多少','待办事项','更多','我的店铺','商品进货价','全部记录','备份与恢复','使用帮助','开始','用示例试一下','稍后再说'];
  simpleKeys.forEach((key,index)=>{ catalog[key]=simpleLabels[lang][index]; });
  for (const [key, values] of Object.entries(extraTranslations)) catalog[key] = values[['en','fr','ru','es','ar'].indexOf(lang)];
  CATALOGS.set(lang,catalog);
  FRAGMENTS.set(lang,Object.keys(catalog).filter((part)=>part.length>=4&&part.length<=34&&!part.includes('__VAR')&&!/[.!?。！？；;]/.test(part)).sort((a,b)=>b.length-a.length));
}
function setupDialogs() {
  const confirmNative=window.confirm.bind(window), promptNative=window.prompt.bind(window);
  window.confirm=(message)=>confirmNative(translateText(message));
  window.prompt=(message,defaultValue='')=>{
    const rules=DYNAMIC[currentLanguage]; let token=null, expected=null;
    const statusQuestion=String(message).includes('手动输入订单状态');
    if(rules && message.includes('输入“清空”')) {token='CLEAR';expected='清空';message=rules.confirmClear;}
    else if(rules && message.includes('输入“替换”')) {token='REPLACE';expected='替换';message=rules.confirmReplace;}
    else if(rules && message.includes('输入“撤销”')) {token='UNDO';expected='撤销';message=rules.confirmUndo;}
    else message=translateText(message);
    const result=promptNative(message,defaultValue);
    if(token && result?.trim().toUpperCase()===token) return expected;
    if(statusQuestion && result && currentLanguage!=='zh-CN') {
      for(const status of ['已完成','已取消','待付款','忽略']) if(result.trim().toLocaleLowerCase()===translateText(status).trim().toLocaleLowerCase()) return status;
    }
    return result;
  };
}
export async function setupLanguage(initial, onChange) {
  const pickers=[...document.querySelectorAll('[data-language-picker]')].map((picker)=>({picker,button:picker.querySelector('[data-language-button]'),menu:picker.querySelector('[data-language-menu]')})).filter((item)=>item.button&&item.menu);
  if(!pickers.length) return;
  for(const {menu} of pickers) menu.innerHTML=LANGUAGES.map((item)=>`<button type="button" class="language-option" role="menuitemradio" aria-checked="false" data-language="${item.code}" translate="no">${flag(item.flag)}<span lang="${item.code}" dir="${item.dir}">${item.name}</span><span class="language-check" aria-hidden="true">✓</span></button>`).join('');
  const close=()=>{for(const {button,menu} of pickers){menu.hidden=true;button.setAttribute('aria-expanded','false');}};
  let changeId=0;
  const set=async(code,persist=true)=>{
    const item=LANGUAGES.find((language)=>language.code===code)||LANGUAGES[0];
    const request=++changeId;
    try { await loadCatalog(item.code); } catch(error) { console.error(error); window.alert('Could not load the selected language. Please check website files and try again.'); return; }
    if(request!==changeId)return;
    currentLanguage=item.code; document.documentElement.lang=item.code; document.documentElement.dir=item.dir;
    for(const {button,menu} of pickers) {
      button.innerHTML=`${flag(item.flag)}<span lang="${item.code}" dir="${item.dir}">${item.name}</span><span class="language-chevron" aria-hidden="true">⌄</span>`;
      button.setAttribute('aria-label',item.code==='zh-CN'?'切换语言':DYNAMIC[item.code].change);
      for(const option of menu.querySelectorAll('[data-language]')) option.setAttribute('aria-checked',String(option.dataset.language===item.code));
    }
    applyTranslation(document.body); close(); if(persist&&onChange)onChange(item.code);
  };
  for(const {button,menu} of pickers) {
    button.addEventListener('click',()=>{const show=menu.hidden;close();menu.hidden=!show;button.setAttribute('aria-expanded',String(show));});
    button.addEventListener('keydown',(event)=>{if(event.key==='ArrowDown'){event.preventDefault();close();menu.hidden=false;button.setAttribute('aria-expanded','true');menu.querySelector('[aria-checked="true"]')?.focus();}});
    menu.addEventListener('click',(event)=>{const option=event.target.closest('[data-language]');if(option)set(option.dataset.language).then(()=>button.focus());});
    menu.addEventListener('keydown',(event)=>{if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;event.preventDefault();const options=[...menu.querySelectorAll('[data-language]')];let index=options.indexOf(document.activeElement);index=event.key==='Home'?0:event.key==='End'?options.length-1:(index+(event.key==='ArrowDown'?1:-1)+options.length)%options.length;options[index]?.focus();});
  }
  document.addEventListener('click',(event)=>{if(!pickers.some(({picker})=>picker.contains(event.target)))close();});
  document.addEventListener('keydown',(event)=>{const open=pickers.find(({menu})=>!menu.hidden);if(event.key==='Escape'&&open){close();open.button.focus();}});
  setupDialogs();
  let scheduled=false;
  const observer=new MutationObserver(()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;applyTranslation(document.body);});});
  observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['placeholder','aria-label','title']});
  await set(isLanguage(initial)?initial:'zh-CN',false);
}
