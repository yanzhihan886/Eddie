# 卖家利润助手

这是一个静态网站。上传此目录内的文件到 GitHub 仓库根目录，其中 index.html、styles.css、js、flags 和 vendor 必须保持同一层级。

## 本地运行

在本目录执行 `python -m http.server 8769`，打开 http://127.0.0.1:8769/。建议使用 HTTP 服务而不是双击 HTML。

## GitHub Pages

在仓库 Settings → Pages 中选择从分支部署，选择存放网站文件的分支及 `/ (root)`。部署是否可用以平台实际状态为准。

数据存储于当前网址和浏览器的 IndexedDB，不会在不同设备或网址间自动同步。换网址前请先从原网站导出备份。

当前版本仍在优化：全站翻译、完整 RTL、移动端和新手引导的浏览器完整流程尚未全部验收。
