import { findCost, formatFen, formatQuantity, multiplyFenByMilli } from "./domain.mjs";
import { buildProfitInsights } from "./insights.mjs";
import { translateGeneratedIssue, translateText } from "./language.mjs";

let MONEY_FORMAT = '¥#,##0.00;[Red]-¥#,##0.00';
let reportCurrency = 'CNY';
const INTEGER_FORMAT = '#,##0';
const QUANTITY_FORMAT = '#,##0.###';
const PERCENT_FORMAT = '0.0%';

function exportEngine() {
  const engine = globalThis.XLSX_STYLE || (typeof window === "undefined" ? globalThis.XLSX : null);
  if (!engine) throw new Error("Excel 报告组件未加载，请检查网络文件后刷新重试。数据没有改变。");
  return engine;
}

const PALETTE = {
  title: { font: { name: "Microsoft YaHei", sz: 18, bold: true, color: { rgb: "FFFFFF" } }, fill: { fgColor: { rgb: "105C4C" } }, alignment: { vertical: "center", horizontal: "left" } },
  subtitle: { font: { name: "Microsoft YaHei", sz: 10, color: { rgb: "476458" } }, fill: { fgColor: { rgb: "EAF5EF" } }, alignment: { vertical: "center", wrapText: true } },
  section: { font: { name: "Microsoft YaHei", sz: 12, bold: true, color: { rgb: "FFFFFF" } }, fill: { fgColor: { rgb: "167B63" } }, alignment: { vertical: "center" } },
  header: { font: { name: "Microsoft YaHei", sz: 10, bold: true, color: { rgb: "275447" } }, fill: { fgColor: { rgb: "E2F1E9" } }, alignment: { vertical: "center", wrapText: true } },
  body: { font: { name: "Microsoft YaHei", sz: 10, color: { rgb: "233C32" } }, alignment: { vertical: "center", wrapText: true } },
  alternate: { font: { name: "Microsoft YaHei", sz: 10, color: { rgb: "233C32" } }, fill: { fgColor: { rgb: "F5FAF7" } }, alignment: { vertical: "center", wrapText: true } },
  warning: { font: { name: "Microsoft YaHei", sz: 11, bold: true, color: { rgb: "8A5616" } }, fill: { fgColor: { rgb: "FFF2D8" } }, alignment: { vertical: "center", wrapText: true } },
  loss: { font: { name: "Microsoft YaHei", sz: 16, bold: true, color: { rgb: "A82E34" } }, fill: { fgColor: { rgb: "FDECEB" } }, alignment: { vertical: "center", wrapText: true } },
  profit: { font: { name: "Microsoft YaHei", sz: 16, bold: true, color: { rgb: "126F54" } }, fill: { fgColor: { rgb: "EAF7EF" } }, alignment: { vertical: "center", wrapText: true } },
  metric: { font: { name: "Microsoft YaHei", sz: 12, bold: true, color: { rgb: "126F54" } }, fill: { fgColor: { rgb: "F0F8F3" } }, alignment: { vertical: "center", horizontal: "right" } },
};

function styleRow(sheet, row, lastColumn, style) {
  const engine = exportEngine();
  for (let col = 0; col <= lastColumn; col += 1) {
    const key = engine.utils.encode_cell({ r: row, c: col });
    const cell = sheet[key] || (sheet[key] = { t: "s", v: "" });
    cell.s = cell.z ? { ...style, numFmt: cell.z } : style;
  }
}

function safeText(value) {
  const text = String(value ?? "");
  return /^[=+@\-]/.test(text) ? `'${text}` : text;
}

function yuan(fen) { return Number(fen || 0) / 100; }
function quantity(milli) { return Number(formatQuantity(milli)); }
function clean(value) { return value === null || value === undefined ? "" : safeText(value); }
function inRange(value, start, end) { return value >= start && value <= end; }
function issueLabel(value) {
  return ({ unknown_order_status: "订单状态无法识别", missing_cost: "商品缺少成本", fee_settlement_mismatch: "到账金额与估算不一致", duplicate_record: "发现重复记录" })[value] || value || "其他问题";
}
function reportLabel(value) {
  return ({ orders: "订单表", refunds: "退款表", fees: "平台扣费表", costs: "商品成本表", expenses: "其他支出表", settlements: "实际到账表" })[value] || value || "其他表格";
}
function statusLabel(value) {
  return ({ open: "待处理", review: "待复核", resolved: "已处理", imported: "已导入", partial: "部分导入", failed: "未完成", warning: "提醒", error: "错误" })[value] || value || "";
}

function addTableSheet(wb, name, title, note, headers, rows, widths, numberColumns = {}) {
  const XLSX = exportEngine();
  const sheet = XLSX.utils.aoa_to_sheet([
    [safeText(title)],
    [safeText(note)],
    [],
    headers,
    ...(rows.length ? rows : [["当前范围没有记录"]]),
  ]);
  const lastColumn = Math.max(0, headers.length - 1);
  sheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: lastColumn } }, { s: { r: 1, c: 0 }, e: { r: 1, c: lastColumn } }];
  sheet["!cols"] = headers.map((_, index) => ({ wch: widths?.[index] || 18 }));
  sheet["!rows"] = [{ hpt: 25 }, { hpt: 34 }, { hpt: 8 }, { hpt: 22 }];
  sheet["!autofilter"] = { ref: XLSX.utils.encode_range({ s: { r: 3, c: 0 }, e: { r: Math.max(3, rows.length + 3), c: lastColumn } }) };
  sheet["!freeze"] = { xSplit: 0, ySplit: 4, topLeftCell: "A5", activePane: "bottomLeft", state: "frozen" };
  sheet["!views"] = [{ showGridLines: false }];
  for (const [column, format] of Object.entries(numberColumns)) {
    const col = Number(column);
    for (let row = 4; row < 4 + rows.length; row += 1) {
      const cell = sheet[XLSX.utils.encode_cell({ r: row, c: col })];
      if (cell && typeof cell.v === "number") cell.z = format;
    }
  }
  styleRow(sheet, 0, lastColumn, PALETTE.title);
  styleRow(sheet, 1, lastColumn, PALETTE.subtitle);
  styleRow(sheet, 3, lastColumn, PALETTE.header);
  // Styling very large exports cell-by-cell can exhaust browser memory.
  if (rows.length <= 10000) for (let row = 4; row < 4 + Math.max(1, rows.length); row += 1) styleRow(sheet, row, lastColumn, row % 2 ? PALETTE.alternate : PALETTE.body);
  XLSX.utils.book_append_sheet(wb, sheet, name);
}

function createOverviewSheet(wb, summary, selectedStoreName, insights) {
  const XLSX = exportEngine();
  const today = new Date();
  const todayText = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const monthLabel = summary.start === `${todayText.slice(0, 7)}-01` && summary.end === todayText ? "本月" : "本期";
  const hasPeriodActivity = summary.grossSalesFen || summary.refundFen || summary.costFen || summary.feeFen || summary.expenseFen;
  const conclusion = !hasPeriodActivity
    ? `${monthLabel}暂时没有可计入的销售金额`
    : !summary.complete ? `${monthLabel}暂时无法确认赚亏；已知项目相减后为 ${moneyLabel(summary.knownProfitFen)}`
    : summary.knownProfitFen < 0 ? `${monthLabel}预计亏了 ${moneyLabel(Math.abs(summary.knownProfitFen))}`
      : summary.knownProfitFen > 0 ? `${monthLabel}预计赚了 ${moneyLabel(summary.knownProfitFen)}` : `${monthLabel}暂时打平`;
  const lossTableRows = insights.lossProducts.length
    ? insights.lossProducts.map((row) => [clean(row.productName || row.skuId), clean(row.skuId), quantity(row.quantityMilli), yuan(Math.abs(row.profitFen)), clean(row.reason), clean(row.suggestion)])
    : [["已匹配项目暂未发现亏损；缺成本或未分配费用可能改变结论", "", "", "", "", ""]];
  const uncertainTableRows = insights.uncertainProducts.length
    ? insights.uncertainProducts.map((row) => [clean(row.productName || row.skuId), clean(row.skuId), quantity(row.quantityMilli), yuan(row.salesFen), "缺少进货成本", "补填成本后再判断"])
    : [["没有缺少成本的商品", "", "", "", "", ""]];
  const amountRows = [
    ["商品销售额", yuan(summary.grossSalesFen), "本期已成交订单的商品金额。"],
    ["减：已确认退款", yuan(summary.refundFen), "按退款完成日期统计。"],
    ["净销售额", yuan(summary.netSalesFen), "商品销售额减去已确认退款。"],
    ["减：已匹配商品成本", yuan(summary.costFen), "只扣除已填写且在下单日期有效的商品成本。"],
    ["减：平台扣费", yuan(summary.feeFen), "按费用发生日期统计。"],
    ["减：其他经营支出", yuan(summary.expenseFen), "例如推广费、包装费等已录入支出。"],
    ["预计利润", yuan(summary.knownProfitFen), "商品销售额减去退款、商品成本、平台扣费和其他支出；资料不全时可能偏高。"],
    ["预计利润率", summary.profitMargin === null ? "—" : summary.profitMargin, "预计利润除以净销售额。"],
  ];
  const noteRows = [
    ["店铺范围", safeText(selectedStoreName)],
    ["统计日期", `${summary.start} 至 ${summary.end}`],
    ["订单处理", `${summary.orderCount} 笔已识别成交；${summary.cancelledCount} 笔已取消未计入；${summary.unknownCount} 笔状态未识别未计入。`],
    ["售出数量", `${quantity(summary.itemCountMilli)} 件`],
    ["实际到账", `${moneyLabel(summary.settlementFen)}（单独列示，只用于核对，不重复计入预计利润）`],
    ["数据提醒", summary.missingInputs.length ? summary.missingInputs.join("；") : "当前导入范围未发现明显缺项；这不代表平台账单完整。"],
    ["成本提醒", summary.missingCosts.length ? `${summary.missingCosts.length} 个商品未填写成本，预计利润可能偏高。` : "本期商品均已匹配成本。"],
    ["未归属商品", `${insights.unallocated.count} 条退款或费用合计 ${moneyLabel(insights.unallocatedFen)} 未能明确对应本期单个商品；已计入店铺利润，未计入商品利润。`],
    ["报告说明", "根据当前浏览器里已导入的数据生成；补充或修改数据后，请重新下载。此报告是经营参考，不是会计或税务结论。"],
  ];
  const aoa = [
    ["本期经营结论"],
    [`${safeText(selectedStoreName)}  ·  ${summary.start} 至 ${summary.end}`],
    [],
    [conclusion],
    [`已知项目利润率 ${summary.profitMargin === null ? "暂无法计算" : `${(summary.profitMargin * 100).toFixed(1)}%`}。按已导入数据估算，平台到账不等于利润。${summary.missingInputs.length ? ` 资料不完整：${summary.missingInputs.join("；")}。` : ""}`],
    [],
    ["商品销售额", yuan(summary.grossSalesFen), "总支出（含退款）", yuan(summary.costFen + summary.feeFen + summary.expenseFen + summary.refundFen), "利润率", summary.profitMargin === null ? "—" : summary.profitMargin],
    ["计入订单", summary.orderCount, "售出商品", quantity(summary.itemCountMilli), "实际到账", yuan(summary.settlementFen)],
    [],
    [`亏钱商品清单 · ${insights.lossCount} 件 · 合计亏 ${moneyLabel(insights.totalLossFen)}`],
    [`只计入能明确匹配单个商品的退款和费用；另有 ${insights.unallocated.count} 条无法归属商品。`],
    ["商品名称", "商品编号", "售出数量", "预计亏损（元）", "可能原因", "建议处理"],
    ...lossTableRows,
    [],
    [`暂时不能判断 · ${insights.uncertainProducts.length} 件商品缺少成本`],
    ["商品名称", "商品编号", "售出数量", "商品销售额（元）", "目前缺什么", "建议处理"],
    ...uncertainTableRows,
    [],
    ["利润是怎么算出来的"],
    ["项目", "金额（元）", "简单说明"],
    ...amountRows,
    [],
    ["这份报告怎么看"],
    ...noteRows,
  ];
  const lossStart = 12;
  const uncertainHeading = 13 + lossTableRows.length;
  const uncertainHeader = uncertainHeading + 1;
  const uncertainStart = uncertainHeader + 1;
  const breakdownHeading = uncertainStart + uncertainTableRows.length + 1;
  const breakdownHeader = breakdownHeading + 1;
  const breakdownStart = breakdownHeader + 1;
  const noteHeading = breakdownStart + amountRows.length + 1;
  const noteStart = noteHeading + 1;
  const sheet = XLSX.utils.aoa_to_sheet(aoa);
  sheet["!merges"] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 5 } }, { s: { r: 1, c: 0 }, e: { r: 1, c: 5 } },
    { s: { r: 3, c: 0 }, e: { r: 3, c: 5 } }, { s: { r: 4, c: 0 }, e: { r: 4, c: 5 } },
    { s: { r: 9, c: 0 }, e: { r: 9, c: 5 } }, { s: { r: 10, c: 0 }, e: { r: 10, c: 5 } },
    { s: { r: uncertainHeading, c: 0 }, e: { r: uncertainHeading, c: 5 } },
    { s: { r: breakdownHeading, c: 0 }, e: { r: breakdownHeading, c: 5 } },
    { s: { r: noteHeading, c: 0 }, e: { r: noteHeading, c: 5 } },
    { s: { r: breakdownHeader, c: 2 }, e: { r: breakdownHeader, c: 5 } },
    ...amountRows.map((_, index) => ({ s: { r: breakdownStart + index, c: 2 }, e: { r: breakdownStart + index, c: 5 } })),
    ...noteRows.map((_, index) => ({ s: { r: noteStart + index, c: 1 }, e: { r: noteStart + index, c: 5 } })),
    ...(!insights.lossCount ? [{ s: { r: lossStart, c: 0 }, e: { r: lossStart, c: 5 } }] : []),
    ...(!insights.uncertainProducts.length ? [{ s: { r: uncertainStart, c: 0 }, e: { r: uncertainStart, c: 5 } }] : []),
  ];
  sheet["!cols"] = [{ wch: 25 }, { wch: 17 }, { wch: 14 }, { wch: 17 }, { wch: 26 }, { wch: 42 }];
  sheet["!rows"] = Array.from({ length: aoa.length }, () => ({ hpt: 23 }));
  sheet["!rows"][0] = { hpt: 34 }; sheet["!rows"][2] = { hpt: 9 }; sheet["!rows"][3] = { hpt: 40 }; sheet["!rows"][4] = { hpt: 42 };
  sheet["!rows"][8] = { hpt: 10 }; sheet["!rows"][9] = { hpt: 26 }; sheet["!rows"][10] = { hpt: 30 };
  sheet["!rows"][uncertainHeading] = { hpt: 26 }; sheet["!rows"][breakdownHeading] = { hpt: 26 }; sheet["!rows"][noteHeading] = { hpt: 26 };
  sheet["!views"] = [{ showGridLines: false }];
  for (const cell of ["B7", "D7", "F8"]) if (sheet[cell]) sheet[cell].z = MONEY_FORMAT;
  if (sheet.F7 && typeof sheet.F7.v === "number") sheet.F7.z = PERCENT_FORMAT;
  if (sheet.B8 && typeof sheet.B8.v === "number") sheet.B8.z = INTEGER_FORMAT;
  if (sheet.D8 && typeof sheet.D8.v === "number") sheet.D8.z = QUANTITY_FORMAT;
  for (let row = lossStart; row < lossStart + lossTableRows.length; row += 1) {
    if (sheet[`C${row + 1}`] && typeof sheet[`C${row + 1}`].v === "number") sheet[`C${row + 1}`].z = QUANTITY_FORMAT;
    if (sheet[`D${row + 1}`] && typeof sheet[`D${row + 1}`].v === "number") sheet[`D${row + 1}`].z = MONEY_FORMAT;
  }
  for (let row = uncertainStart; row < uncertainStart + uncertainTableRows.length; row += 1) {
    if (sheet[`C${row + 1}`] && typeof sheet[`C${row + 1}`].v === "number") sheet[`C${row + 1}`].z = QUANTITY_FORMAT;
    if (sheet[`D${row + 1}`] && typeof sheet[`D${row + 1}`].v === "number") sheet[`D${row + 1}`].z = MONEY_FORMAT;
  }
  for (let row = breakdownStart; row < breakdownStart + amountRows.length; row += 1) {
    const cell = sheet[`B${row + 1}`];
    if (cell && typeof cell.v === "number") cell.z = row === breakdownStart + amountRows.length - 1 ? PERCENT_FORMAT : MONEY_FORMAT;
  }
  for (let row = 0; row < aoa.length; row += 1) styleRow(sheet, row, 5, row % 2 ? PALETTE.alternate : PALETTE.body);
  styleRow(sheet, 0, 5, PALETTE.title);
  styleRow(sheet, 1, 5, PALETTE.subtitle);
  styleRow(sheet, 3, 5, !summary.complete ? PALETTE.warning : summary.knownProfitFen < 0 ? PALETTE.loss : PALETTE.profit);
  styleRow(sheet, 4, 5, summary.missingInputs.length ? PALETTE.warning : PALETTE.subtitle);
  for (const row of [9, uncertainHeading, breakdownHeading, noteHeading]) styleRow(sheet, row, 5, PALETTE.section);
  for (const row of [11, uncertainHeader, breakdownHeader]) styleRow(sheet, row, 5, PALETTE.header);
  for (const row of [6, 7]) { styleRow(sheet, row, 5, PALETTE.header); for (const col of [1, 3, 5]) { const cell = sheet[XLSX.utils.encode_cell({ r: row, c: col })]; if (cell) cell.s = cell.z ? { ...PALETTE.metric, numFmt: cell.z } : PALETTE.metric; } }
  for (let row = lossStart; row < lossStart + lossTableRows.length; row += 1) { sheet["!rows"][row] = { hpt: 38 }; if (insights.lossCount) { const cell = sheet[XLSX.utils.encode_cell({ r: row, c: 3 })]; if (cell) cell.s = { ...PALETTE.body, font: { name: "Microsoft YaHei", sz: 11, bold: true, color: { rgb: "A82E34" } }, numFmt: cell.z }; } }
  for (let row = uncertainStart; row < uncertainStart + uncertainTableRows.length; row += 1) sheet["!rows"][row] = { hpt: 32 };
  for (let row = noteStart; row < noteStart + noteRows.length; row += 1) sheet["!rows"][row] = { hpt: 32 };
  XLSX.utils.book_append_sheet(wb, sheet, "先看这里");
}

function moneyLabel(fen) { return formatFen(fen, reportCurrency); }

function dailyRows(data, summary) {
  const days = new Map();
  const cursor = new Date(`${summary.start}T00:00:00Z`);
  const end = new Date(`${summary.end}T00:00:00Z`);
  while (cursor <= end) {
    const day = cursor.toISOString().slice(0, 10);
    days.set(day, { date: day, orderIds: new Set(), quantityMilli: 0, salesFen: 0, refundFen: 0, costFen: 0, feeFen: 0, expenseFen: 0 });
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  const orders = data.orders.filter((row) => summary.storeIds.includes(row.storeId) && row.statusClass === "valid" && inRange(row.orderedAt, summary.start, summary.end));
  const orderById = new Map(orders.map((row) => [row.id, row]));
  for (const item of data.orderItems) {
    const order = orderById.get(item.orderId);
    if (!order) continue;
    const day = days.get(order.orderedAt);
    if (!day) continue;
    day.orderIds.add(order.id);
    day.quantityMilli += item.quantityMilli || 0;
    day.salesFen += item.amountFen || 0;
    const cost = findCost(data.productCosts, item.storeId, item.skuId, order.orderedAt);
    if (cost) day.costFen += multiplyFenByMilli(cost.unitCostFen, item.quantityMilli);
  }
  for (const refund of data.refunds) if (refund.confirmed && summary.storeIds.includes(refund.storeId) && days.has(refund.completedAt)) days.get(refund.completedAt).refundFen += refund.amountFen || 0;
  for (const fee of data.platformFees) if (summary.storeIds.includes(fee.storeId) && days.has(fee.feeDate)) days.get(fee.feeDate).feeFen += fee.amountFen || 0;
  for (const expense of data.otherExpenses) if (summary.storeIds.includes(expense.storeId) && days.has(expense.expenseDate)) days.get(expense.expenseDate).expenseFen += expense.amountFen || 0;
  const rows = [...days.values()].map((row) => {
    const profitFen = row.salesFen - row.refundFen - row.costFen - row.feeFen - row.expenseFen;
    return [row.date, row.orderIds.size, quantity(row.quantityMilli), yuan(row.salesFen), yuan(row.refundFen), yuan(row.costFen), yuan(row.feeFen), yuan(row.expenseFen), yuan(profitFen), row.salesFen - row.refundFen ? profitFen / (row.salesFen - row.refundFen) : "—"];
  });
  rows.push(["本期合计", summary.orderCount, quantity(summary.itemCountMilli), yuan(summary.grossSalesFen), yuan(summary.refundFen), yuan(summary.costFen), yuan(summary.feeFen), yuan(summary.expenseFen), yuan(summary.knownProfitFen), summary.profitMargin === null ? "—" : summary.profitMargin]);
  return rows;
}

function productRows(insights) {
  return insights.products.map((row) => [clean(row.productName), clean(row.skuId), quantity(row.quantityMilli), yuan(row.salesFen), row.missingCost ? "未填写" : yuan(row.costFen), yuan(row.allocatedDeductionsFen), row.missingCost ? "暂不能判断" : yuan(row.profitFen), row.missingCost || row.margin === null ? "—" : row.margin, row.missingCost ? "缺少成本，暂无法判断" : "仅含明确匹配费用，公共费用未分摊"]);
}

function orderRows(data, summary) {
  const stores = new Map(data.stores.map((row) => [row.id, row]));
  const orders = data.orders.filter((row) => summary.storeIds.includes(row.storeId) && inRange(row.orderedAt, summary.start, summary.end));
  const itemsByOrder = new Map();
  for (const item of data.orderItems) {
    const list = itemsByOrder.get(item.orderId) || [];
    list.push(item);
    itemsByOrder.set(item.orderId, list);
  }
  const rows = [];
  for (const order of orders) {
    const items = itemsByOrder.get(order.id) || [null];
    for (const item of items) rows.push([
      order.orderedAt, clean(stores.get(order.storeId)?.name), clean(order.platformOrderId), clean(order.orderStatus), order.statusClass === "valid" ? "计入" : "未计入",
      clean(item?.productName), clean(item?.skuId), item ? quantity(item.quantityMilli) : "", item ? yuan(item.amountFen) : "",
    ]);
  }
  return rows;
}

function moneyRecordRows(data, summary) {
  const storeName = new Map(data.stores.map((row) => [row.id, row.name]));
  const rows = [];
  for (const row of data.refunds) if (summary.storeIds.includes(row.storeId) && inRange(row.completedAt, summary.start, summary.end)) rows.push([row.completedAt, clean(storeName.get(row.storeId)), "退款", clean(row.platformRefundId || "退款记录"), clean(row.platformOrderId), yuan(row.amountFen), row.confirmed ? "已确认，计入利润估算" : "未确认，不计入利润估算"]);
  for (const row of data.platformFees) if (summary.storeIds.includes(row.storeId) && inRange(row.feeDate, summary.start, summary.end)) rows.push([row.feeDate, clean(storeName.get(row.storeId)), "平台扣费", clean(row.feeType), clean(row.platformOrderId), yuan(row.amountFen), "计入利润估算"]);
  for (const row of data.otherExpenses) if (summary.storeIds.includes(row.storeId) && inRange(row.expenseDate, summary.start, summary.end)) rows.push([row.expenseDate, clean(storeName.get(row.storeId)), "其他支出", clean(row.expenseType), clean(row.platformOrderId), yuan(row.amountFen), clean(row.note || row.allocationMethod || "计入利润估算")]);
  for (const row of data.settlements) if (summary.storeIds.includes(row.storeId) && inRange(row.settlementDate, summary.start, summary.end)) rows.push([row.settlementDate, clean(storeName.get(row.storeId)), "实际到账", clean(row.settlementStatus), clean(row.platformOrderId), yuan(row.amountFen), row.confirmed ? "已确认；仅供核对到账" : "未确认；仅供核对到账"]);
  return rows.sort((a, b) => String(a[0]).localeCompare(String(b[0])));
}

const SHEET_NAMES = {
  en: ['Summary','Daily','Products','Orders','Refunds and fees','Product costs','Review','Imports'],
  fr: ['Résumé','Journalier','Produits','Commandes','Remboursements et frais','Coûts des produits','À vérifier','Imports'],
  ru: ['Итоги','По дням','Товары','Заказы','Возвраты и расходы','Себестоимость','Проверка','Импорт'],
  es: ['Resumen','Diario','Productos','Pedidos','Reembolsos y gastos','Costes de productos','Por revisar','Importaciones'],
  ar: ['الملخص','اليومي','المنتجات','الطلبات','الاسترداد والرسوم','تكاليف المنتجات','للمراجعة','الواردات'],
};

function localizeWorkbook(wb, language, summary, insights, data) {
  if (!SHEET_NAMES[language]) return;
  const XLSX = exportEngine();
  const translateCell = (sheet, row, col) => {
    const cell = sheet[XLSX.utils.encode_cell({ r: row, c: col })];
    if (cell && cell.t === 's' && cell.v) cell.v = translateText(cell.v, language);
  };
  const originalNames = [...wb.SheetNames];
  const lossRows = Math.max(1, insights.lossProducts.length);
  const uncertainRows = Math.max(1, insights.uncertainProducts.length);
  const uncertainHeading = 13 + lossRows, uncertainHeader = uncertainHeading + 1, uncertainStart = uncertainHeader + 1;
  const breakdownHeading = uncertainStart + uncertainRows + 1, breakdownHeader = breakdownHeading + 1, breakdownStart = breakdownHeader + 1;
  const noteHeading = breakdownStart + 8 + 1, noteStart = noteHeading + 1;
  const demoIds = new Set(data.stores.filter((store) => store.demo).map((store) => store.id));
  for (let index = 0; index < originalNames.length; index += 1) {
    const name = originalNames[index], sheet = wb.Sheets[name];
    const range = XLSX.utils.decode_range(sheet['!ref']);
    if (index === 0) {
      for (const [row,col] of [[0,0],[3,0],[6,0],[6,2],[6,4],[7,0],[7,2],[7,4],[9,0],[10,0],[uncertainHeading,0],[breakdownHeading,0],[noteHeading,0]]) translateCell(sheet,row,col);
      const caution = summary.missingInputs.length ? ` ${translateText('资料不完整，暂不能确认赚亏',language)}` : '';
      if (sheet.A5) sheet.A5.v = `${translateText('已知项目利润率',language)}: ${summary.profitMargin === null ? '—' : `${(summary.profitMargin*100).toFixed(1)}%`}. ${translateText('根据已导入的订单、退款和费用估算；平台到账不等于利润。',language)}${caution}`;
      for (const row of [11, uncertainHeader, breakdownHeader]) for (let col=0;col<=5;col+=1) translateCell(sheet,row,col);
      for (let row=12;row<12+lossRows;row+=1) { if (!insights.lossCount) translateCell(sheet,row,0); else { if(demoIds.has(insights.lossProducts[row-12]?.storeId)) translateCell(sheet,row,0); translateCell(sheet,row,4); translateCell(sheet,row,5); } }
      for (let row=uncertainStart;row<uncertainStart+uncertainRows;row+=1) { if (!insights.uncertainProducts.length) translateCell(sheet,row,0); else { if(demoIds.has(insights.uncertainProducts[row-uncertainStart]?.storeId)) translateCell(sheet,row,0); translateCell(sheet,row,4); translateCell(sheet,row,5); } }
      for (let row=breakdownStart;row<breakdownStart+8;row+=1) { translateCell(sheet,row,0); translateCell(sheet,row,2); }
      for (let row=noteStart;row<=range.e.r;row+=1) { translateCell(sheet,row,0); if(row!==noteStart) translateCell(sheet,row,1); }
    } else {
      translateCell(sheet,0,0); translateCell(sheet,1,0);
      for (let col=0;col<=range.e.c;col+=1) translateCell(sheet,3,col);
      const systemColumns = { '商品表现':[8], '订单明细':[4], '退款费用到账':[2], '需要留意':[1,2,3], '导入记录':[1,9] }[name] || [];
      for (let row=4;row<=range.e.r;row+=1) {
        if(name==='商品表现' && demoIds.has(insights.products[row-4]?.storeId)) translateCell(sheet,row,0);
        if(name==='需要留意') { const cell=sheet[XLSX.utils.encode_cell({r:row,c:5})]; if(cell?.t==='s')cell.v=translateGeneratedIssue(cell.v,language); }
        if(name==='退款费用到账') { const kind=sheet[XLSX.utils.encode_cell({r:row,c:2})]?.v; if(['退款','平台扣费','实际到账'].includes(kind)) translateCell(sheet,row,6); }
        for(const col of systemColumns) translateCell(sheet,row,col);
      }
    }
    if (language === 'ar') for (const [key,cell] of Object.entries(sheet)) if(!key.startsWith('!') && cell && cell.t === 's' && cell.s) cell.s={...cell.s,alignment:{...(cell.s.alignment||{}),horizontal:'right'}};
    const translatedName = SHEET_NAMES[language][index];
    delete wb.Sheets[name]; wb.Sheets[translatedName] = sheet; wb.SheetNames[index] = translatedName;
  }
  wb.Props = { Title: translateText('卖家利润助手经营报告',language), Subject: translateText('按当前筛选范围生成的本地经营结果',language), Author: translateText('卖家利润助手（本地生成）',language) };
}

export function createWorkbook(data, summary, selectedStoreName, marginThresholdPercent = 10, language = 'zh-CN', currency = 'CNY') {
  const selectedCurrencies = new Set(data.stores.filter(store => summary.storeIds.includes(store.id)).map(store => store.currency || 'CNY'));
  if (selectedCurrencies.size > 1 || (selectedCurrencies.size === 1 && !selectedCurrencies.has(currency))) throw new Error('报告只能包含同一币种，且币种必须与店铺一致。');
  reportCurrency = currency;
  MONEY_FORMAT = currency === 'CNY' ? '¥#,##0.00;[Red]-¥#,##0.00' : `"${currency} "#,##0.00;[Red]-"${currency} "#,##0.00`;
  const XLSX = exportEngine();
  const wb = XLSX.utils.book_new();
  wb.Props = { Title: "卖家利润助手经营报告", Subject: "按当前筛选范围生成的本地经营结果", Author: "卖家利润助手（本地生成）" };
  const insights = buildProfitInsights(data, summary, marginThresholdPercent);
  createOverviewSheet(wb, summary, selectedStoreName, insights);

  addTableSheet(wb, "每日经营", "每日经营情况", "销售、订单和成本按下单日期统计；退款按完成日期、费用按发生日期统计。利润是已导入数据估算。", ["日期", "成交订单", "售出数量", "商品销售额", "退款", "匹配成本", "平台扣费", "其他支出", "预计利润", "预计利润率"], dailyRows(data, summary), [14, 12, 12, 16, 14, 14, 14, 14, 16, 14], { 2: QUANTITY_FORMAT, 3: MONEY_FORMAT, 4: MONEY_FORMAT, 5: MONEY_FORMAT, 6: MONEY_FORMAT, 7: MONEY_FORMAT, 8: MONEY_FORMAT, 9: PERCENT_FORMAT });
  addTableSheet(wb, "商品表现", "商品表现排行", `只计入明确匹配商品的退款和费用；${insights.unallocated.count} 条无法归属商品的款项未分摊。缺成本时暂不能判断。`, ["商品名称", "商品编号", "售出数量", "商品销售额", "已匹配成本", "已匹配退款及费用", "已知项目利润", "已知项目利润率", "数据情况"], productRows(insights), [28, 18, 12, 16, 16, 18, 18, 14, 28], { 2: QUANTITY_FORMAT, 3: MONEY_FORMAT, 4: MONEY_FORMAT, 5: MONEY_FORMAT, 6: MONEY_FORMAT, 7: PERCENT_FORMAT });
  addTableSheet(wb, "订单明细", "订单和商品明细", "订单状态为“未计入”的记录不会计入本期销售。金额为导入的商品实付金额。", ["下单日期", "店铺名称", "订单编号", "订单状态", "统计处理", "商品名称", "商品编号", "商品数量", "商品金额"], orderRows(data, summary), [14, 24, 22, 18, 14, 30, 18, 12, 16], { 7: QUANTITY_FORMAT, 8: MONEY_FORMAT });
  addTableSheet(wb, "退款费用到账", "退款、费用和实际到账", "实际到账单独列示，仅供和平台账单核对，不会与预计利润重复相加。", ["日期", "店铺名称", "记录类型", "项目", "订单编号", "金额", "说明"], moneyRecordRows(data, summary), [14, 24, 16, 24, 22, 16, 32], { 5: MONEY_FORMAT });

  const stores = new Map(data.stores.map((row) => [row.id, row.name]));
  const costs = data.productCosts.filter((row) => summary.storeIds.includes(row.storeId) && row.effectiveFrom <= summary.end && (!row.effectiveTo || row.effectiveTo >= summary.start));
  addTableSheet(wb, "商品成本", "商品成本记录", "只展示生效日期与本期有重叠的成本记录；同一商品可能有多条不同日期的成本。", ["店铺名称", "商品名称", "商品编号", "单位成本", "生效日期", "截止日期", "来源"], costs.map((row) => [clean(stores.get(row.storeId)), clean(row.productName), clean(row.skuId), yuan(row.unitCostFen), clean(row.effectiveFrom), clean(row.effectiveTo), clean(row.costSource || "手动维护")]), [24, 30, 18, 16, 14, 14, 20], { 3: MONEY_FORMAT });
  const issues = data.issues.filter((row) => summary.storeIds.includes(row.storeId) && row.status !== "resolved");
  addTableSheet(wb, "需要留意", "需要留意的问题", "列出当前未处理的问题，不受日期范围限制；处理状态可在网站的“异常核对”页面查看。", ["店铺名称", "问题", "程度", "处理状态", "发现时间", "情况说明", "处理备注"], issues.map((row) => [clean(stores.get(row.storeId)), safeText(issueLabel(row.issueType)), safeText(statusLabel(row.severity)), safeText(statusLabel(row.status)), clean(row.createdAt), clean(row.description), clean(row.resolutionNote)]), [24, 24, 14, 14, 22, 60, 36]);
  const batches = data.importBatches.filter((row) => summary.storeIds.includes(row.storeId) && row.coverageStart <= summary.end && row.coverageEnd >= summary.start);
  addTableSheet(wb, "导入记录", "本期相关的导入记录", "展示覆盖本期日期范围的导入批次，帮助确认报告依据哪些文件生成。", ["店铺名称", "表格类型", "文件名", "导入时间", "文件行数", "新增记录", "未通过", "重复", "冲突", "导入结果"], batches.map((row) => [clean(stores.get(row.storeId)), safeText(reportLabel(row.reportType)), clean(row.originalFilename), clean(row.importedAt), Number(row.rowCount || 0), Number(row.acceptedCount || 0), Number(row.rejectedCount || 0), Number(row.duplicateCount || 0), Number(row.conflictCount || 0), safeText(statusLabel(row.status))]), [24, 18, 36, 22, 12, 12, 12, 12, 12, 16], { 4: INTEGER_FORMAT, 5: INTEGER_FORMAT, 6: INTEGER_FORMAT, 7: INTEGER_FORMAT, 8: INTEGER_FORMAT });
  localizeWorkbook(wb, language, summary, insights, data);
  if (currency !== 'CNY') {
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const uncertainHeader = 14 + Math.max(1, insights.lossProducts.length);
    const breakdownHeader = uncertainHeader + Math.max(1, insights.uncertainProducts.length) + 3;
    const labels = {
      'zh-CN':['预计亏损','商品销售额','金额'], en:['Estimated loss','Product sales','Amount'], fr:['Perte estimée','Ventes des produits','Montant'],
      ru:['Расчётный убыток','Продажи товаров','Сумма'], es:['Pérdida estimada','Ventas de productos','Importe'], ar:['الخسارة المقدرة','مبيعات المنتجات','المبلغ'],
    }[language] || ['Estimated loss','Product sales','Amount'];
    for (const [address, label] of [[`D12`,labels[0]],[`D${uncertainHeader + 1}`,labels[1]],[`B${breakdownHeader + 1}`,labels[2]]]) if (sheet[address]) sheet[address].v = `${label} (${currency})`;
  }
  return wb;
}

export function downloadWorkbook(data, summary, selectedStoreName, marginThresholdPercent = 10, language = 'zh-CN', currency = 'CNY') {
  const XLSX = exportEngine();
  const workbook = createWorkbook(data, summary, selectedStoreName, marginThresholdPercent, language, currency);
  const stamp = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  XLSX.writeFile(workbook, language === 'zh-CN' ? `卖家利润助手_经营报告_${stamp}.xlsx` : `seller-profit-report_${stamp}.xlsx`, { compression: true });
}
